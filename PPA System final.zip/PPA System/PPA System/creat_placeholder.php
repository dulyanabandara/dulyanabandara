<?php
// Create a simple placeholder image if it doesn't exist
$placeholder_path = 'images/default-placeholder.jpg';

if (!file_exists($placeholder_path)) {
    // Create a 400x400 image
    $width = 400;
    $height = 400;
    $img = imagecreatetruecolor($width, $height);
    
    // Set background color (light blue)
    $bg_color = imagecolorallocate($img, 225, 243, 254); // #E1F3FE
    imagefill($img, 0, 0, $bg_color);
    
    // Set text color (dark blue)
    $text_color = imagecolorallocate($img, 44, 122, 160); // #2C7AA0
    
    // Add text
    $text = "No Image Available";
    $font_size = 5;
    
    // Get text dimensions - convert to integers to avoid float precision warning
    $text_width = (int)(imagefontwidth($font_size) * strlen($text));
    $text_height = (int)imagefontheight($font_size);
    
    // Calculate center position
    $x = (int)(($width - $text_width) / 2);
    $y = (int)(($height - $text_height) / 2);
    
    imagestring($img, $font_size, $x, $y, $text, $text_color);
    
    // Save the image
    imagejpeg($img, $placeholder_path, 90);
    imagedestroy($img);
    
    echo "Placeholder image created successfully!<br>";
    echo "Image saved to: " . $placeholder_path;
} else {
    echo "Placeholder image already exists at: " . $placeholder_path;
}
?>