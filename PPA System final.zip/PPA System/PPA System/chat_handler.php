<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Database configuration for chat
$chat_host = 'localhost';
$chat_user = 'root';
$chat_pass = '';
$chat_db = 'perfect_laundry';

$conn = mysqli_connect($chat_host, $chat_user, $chat_pass, $chat_db);

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed']);
    exit;
}

// Create chat_messages table if not exists
$create_table = "CREATE TABLE IF NOT EXISTS chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    session_id VARCHAR(100) NOT NULL,
    sender ENUM('user', 'admin') NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_created (created_at)
)";

mysqli_query($conn, $create_table);

// Get request data
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';
    
    if ($action === 'send') {
        // User sends message
        $session_id = mysqli_real_escape_string($conn, $input['session_id']);
        $message = mysqli_real_escape_string($conn, $input['message']);
        $sender = mysqli_real_escape_string($conn, $input['sender']);
        
        $query = "INSERT INTO chat_messages (session_id, sender, message, is_read) 
                  VALUES ('$session_id', '$sender', '$message', 0)";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['success' => true, 'message' => 'Message sent']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send message']);
        }
    }
    elseif ($action === 'send_admin') {
        // Admin sends message
        $session_id = mysqli_real_escape_string($conn, $input['session_id']);
        $message = mysqli_real_escape_string($conn, $input['message']);
        $sender = 'admin';
        
        $query = "INSERT INTO chat_messages (session_id, sender, message, is_read) 
                  VALUES ('$session_id', '$sender', '$message', 1)";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['success' => true, 'message' => 'Reply sent']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send reply']);
        }
    }
    elseif ($action === 'typing') {
        // Update typing status (store in session or temp table)
        $session_id = mysqli_real_escape_string($conn, $input['session_id']);
        $is_typing = $input['is_typing'] ? 1 : 0;
        
        // Create temp table for typing status if not exists
        $create_typing = "CREATE TABLE IF NOT EXISTS chat_typing (
            session_id VARCHAR(100) PRIMARY KEY,
            is_typing BOOLEAN DEFAULT FALSE,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        mysqli_query($conn, $create_typing);
        
        $upsert = "INSERT INTO chat_typing (session_id, is_typing) 
                   VALUES ('$session_id', $is_typing)
                   ON DUPLICATE KEY UPDATE is_typing = $is_typing";
        mysqli_query($conn, $upsert);
        
        echo json_encode(['success' => true]);
    }
    elseif ($action === 'mark_read') {
        // Mark messages as read
        $session_id = mysqli_real_escape_string($conn, $input['session_id']);
        $query = "UPDATE chat_messages SET is_read = 1 WHERE session_id = '$session_id' AND sender = 'user'";
        mysqli_query($conn, $query);
        echo json_encode(['success' => true]);
    }
}
elseif ($method === 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'get') {
        // Get messages for user
        $session_id = mysqli_real_escape_string($conn, $_GET['session_id']);
        
        $query = "SELECT sender, message, DATE_FORMAT(created_at, '%h:%i %p') as time 
                  FROM chat_messages 
                  WHERE session_id = '$session_id' 
                  ORDER BY created_at ASC";
        $result = mysqli_query($conn, $query);
        
        $messages = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $messages[] = $row;
        }
        
        echo json_encode(['success' => true, 'messages' => $messages]);
    }
    elseif ($action === 'poll') {
        // Poll for new messages for user
        $session_id = mysqli_real_escape_string($conn, $_GET['session_id']);
        
        // Get last message timestamp from request
        $last_check = $_GET['last_check'] ?? date('Y-m-d H:i:s', strtotime('-5 seconds'));
        
        // Get new messages
        $query = "SELECT sender, message, DATE_FORMAT(created_at, '%h:%i %p') as time 
                  FROM chat_messages 
                  WHERE session_id = '$session_id' AND created_at > '$last_check'
                  ORDER BY created_at ASC";
        $result = mysqli_query($conn, $query);
        
        $new_messages = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $new_messages[] = $row;
        }
        
        // Get unread count
        $unread_query = "SELECT COUNT(*) as count FROM chat_messages 
                         WHERE session_id = '$session_id' AND is_read = 0 AND sender = 'admin'";
        $unread_result = mysqli_query($conn, $unread_query);
        $unread_count = mysqli_fetch_assoc($unread_result)['count'];
        
        // Get typing status
        $typing_query = "SELECT is_typing FROM chat_typing WHERE session_id = '$session_id'";
        $typing_result = mysqli_query($conn, $typing_query);
        $admin_typing = ($typing_result && mysqli_num_rows($typing_result) > 0) ? 
                        mysqli_fetch_assoc($typing_result)['is_typing'] : false;
        
        echo json_encode([
            'success' => true, 
            'new_messages' => $new_messages,
            'unread_count' => $unread_count,
            'admin_typing' => (bool)$admin_typing
        ]);
    }
    elseif ($action === 'get_admin') {
        // Get messages for admin with session info
        $session_id = mysqli_real_escape_string($conn, $_GET['session_id']);
        
        $query = "SELECT sender, message, DATE_FORMAT(created_at, '%h:%i %p') as time 
                  FROM chat_messages 
                  WHERE session_id = '$session_id' 
                  ORDER BY created_at ASC";
        $result = mysqli_query($conn, $query);
        
        $messages = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $messages[] = $row;
        }
        
        // Get unread count for this session
        $unread_query = "SELECT COUNT(*) as count FROM chat_messages 
                         WHERE session_id = '$session_id' AND is_read = 0 AND sender = 'user'";
        $unread_result = mysqli_query($conn, $unread_query);
        $unread_count = mysqli_fetch_assoc($unread_result)['count'];
        
        echo json_encode([
            'success' => true, 
            'messages' => $messages,
            'unread_count' => $unread_count
        ]);
    }
    elseif ($action === 'typing_status') {
        // Get typing status for admin
        $session_id = mysqli_real_escape_string($conn, $_GET['session_id']);
        
        $query = "SELECT is_typing FROM chat_typing WHERE session_id = '$session_id'";
        $result = mysqli_query($conn, $query);
        
        $is_typing = ($result && mysqli_num_rows($result) > 0) ? 
                     (bool)mysqli_fetch_assoc($result)['is_typing'] : false;
        
        echo json_encode(['success' => true, 'is_typing' => $is_typing]);
    }
}

mysqli_close($conn);
?>