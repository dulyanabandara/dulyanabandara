<?php
// logout.php - Clear session and redirect
session_start();

// Destroy all session data
session_unset();
session_destroy();

// Also clear session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Return JSON for AJAX logout, or redirect for normal logout
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    // AJAX request
    echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
} else {
    // Normal request - redirect to home page
    header("Location: home.php");
    exit();
}
?>