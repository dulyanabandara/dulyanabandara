<?php
// update_visit_laundry.php - Update visit laundry order (Admin only)
session_start();
require_once 'visit_db.php';

// Check if user is admin
$is_admin = false;
if (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin') {
    $is_admin = true;
}

if (!$is_admin) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$order_id = mysqli_real_escape_string($conn, $data['order_id'] ?? '');

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'Order ID required']);
    exit();
}

try {
    // Get current order for logging
    $current_sql = "SELECT * FROM visit_laundry_orders WHERE order_id = '$order_id'";
    $current_result = mysqli_query($conn, $current_sql);
    $current_order = mysqli_fetch_assoc($current_result);
    
    if (!$current_order) {
        echo json_encode(['success' => false, 'error' => 'Order not found']);
        exit();
    }
    
    // Build update query
    $update_fields = [];
    $log_entries = [];
    
    $updatable_fields = [
        'customer_name', 'phone', 'email', 'visit_date', 'service_speed',
        'weight', 'package_price', 'total_price', 'status', 'payment_status', 'notes'
    ];
    
    foreach ($updatable_fields as $field) {
        if (isset($data[$field])) {
            $old_value = $current_order[$field];
            $new_value = $data[$field];
            
            // Skip if values are the same
            if ($old_value != $new_value) {
                // For visit_date, format properly for database
                if ($field === 'visit_date' && !empty($new_value)) {
                    // Convert from datetime-local format to MySQL datetime
                    $new_value_formatted = date('Y-m-d H:i:s', strtotime($new_value));
                    $old_value_formatted = $old_value ? date('Y-m-d H:i:s', strtotime($old_value)) : '';
                    $update_fields[] = "$field = '$new_value_formatted'";
                    $log_entries[] = "$field changed from '$old_value_formatted' to '$new_value_formatted'";
                } 
                // For numeric fields that might be empty
                elseif (($field === 'weight' || $field === 'package_price' || $field === 'total_price') && ($new_value === '' || $new_value === null)) {
                    $update_fields[] = "$field = NULL";
                    $log_entries[] = "$field changed from '$old_value' to NULL";
                }
                else {
                    $escaped_value = mysqli_real_escape_string($conn, $new_value);
                    $update_fields[] = "$field = '$escaped_value'";
                    $log_entries[] = "$field changed from '$old_value' to '$new_value'";
                }
            }
        }
    }
    
    if (empty($update_fields)) {
        echo json_encode(['success' => false, 'error' => 'No changes to update']);
        exit();
    }
    
    $sql = "UPDATE visit_laundry_orders SET " . implode(', ', $update_fields) . " WHERE order_id = '$order_id'";
    
    if (mysqli_query($conn, $sql)) {
        // Log changes - FIXED: Using 'order_id' instead of 'booking_id' to match your table schema
        if (!empty($log_entries)) {
            $log_message = implode(', ', $log_entries);
            $escaped_log_message = mysqli_real_escape_string($conn, $log_message);
            $changed_by = isset($_SESSION['username']) ? $_SESSION['username'] : 'admin';
            $escaped_changed_by = mysqli_real_escape_string($conn, $changed_by);
            
            $log_sql = "INSERT INTO visit_laundry_logs (order_id, action, old_value, new_value, changed_by) 
                        VALUES ('$order_id', 'Updated', '$escaped_log_message', 'Updated', '$escaped_changed_by')";
            
            if (!mysqli_query($conn, $log_sql)) {
                // Log error but don't fail the main update
                error_log("Failed to insert log: " . mysqli_error($conn));
            }
        }
        
        echo json_encode(['success' => true, 'message' => 'Booking updated successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>