<?php
// config_visit.php - Configuration for Visit Laundry System
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection (using same database but separate tables)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Perfect_laundry"; // Same database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Set charset
$conn->set_charset("utf8mb4");

// Function to generate order ID for visit orders
function generateVisitOrderId($conn) {
    $result = $conn->query("SELECT MAX(CAST(SUBSTRING(order_id, 4) AS UNSIGNED)) as last_num FROM visit_orders");
    $row = $result->fetch_assoc();
    $lastNum = $row['last_num'] ? $row['last_num'] : 0;
    return 'VIS' . str_pad($lastNum + 1, 6, '0', STR_PAD_LEFT);
}
?>