<?php
session_start();
header('Content-Type: application/json');
require_once 'config_review.php';

$response = ['success' => false, 'message' => 'Unknown error'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_type = $_POST['type'] ?? 'summary';
    $date_from = mysqli_real_escape_string($conn_review, $_POST['date_from'] ?? '');
    $date_to = mysqli_real_escape_string($conn_review, $_POST['date_to'] ?? '');
    $rating_filter = intval($_POST['rating'] ?? 0);
    $status_filter = $_POST['status'] ?? 'all';
    
    // Build WHERE clause
    $where_conditions = [];
    $where_conditions[] = "created_at >= '$date_from'";
    $where_conditions[] = "created_at <= '$date_to 23:59:59'";
    
    if ($rating_filter > 0) {
        $where_conditions[] = "rating = $rating_filter";
    }
    
    if ($status_filter !== 'all') {
        $where_conditions[] = "status = '$status_filter'";
    }
    
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
    
    // Get data
    $total_query = "SELECT COUNT(*) as total FROM feedback $where_clause";
    $total_result = mysqli_query($conn_review, $total_query);
    $total = mysqli_fetch_assoc($total_result)['total'];
    
    $avg_query = "SELECT AVG(rating) as avg_rating FROM feedback $where_clause AND rating IS NOT NULL";
    $avg_result = mysqli_query($conn_review, $avg_query);
    $avg_rating = round(mysqli_fetch_assoc($avg_result)['avg_rating'], 1);
    
    // Rating distribution
    $rating_distribution = [];
    for ($i = 1; $i <= 5; $i++) {
        $dist_query = "SELECT COUNT(*) as count FROM feedback $where_clause AND rating = $i";
        $dist_result = mysqli_query($conn_review, $dist_query);
        $rating_distribution[$i] = mysqli_fetch_assoc($dist_result)['count'];
    }
    
    // Get all reviews for detailed report
    $reviews_query = "SELECT * FROM feedback $where_clause ORDER BY created_at DESC";
    $reviews_result = mysqli_query($conn_review, $reviews_query);
    
    $filename = "review_report_" . date('Y-m-d') . "_" . time();
    
    if ($report_type === 'summary') {
        // Generate Summary Report (HTML for printing/PDF)
        $content = generateSummaryReport($date_from, $date_to, $total, $avg_rating, $rating_distribution, $status_filter, $rating_filter);
        $response = ['success' => true, 'content' => $content, 'filename' => $filename . '.html', 'type' => 'html'];
    } 
    elseif ($report_type === 'detailed') {
        // Generate Detailed Report (CSV)
        $content = generateDetailedCSV($reviews_result);
        $response = ['success' => true, 'content' => $content, 'filename' => $filename . '.csv', 'type' => 'csv'];
    }
    elseif ($report_type === 'rating') {
        // Generate Rating Analysis Report (HTML)
        $content = generateRatingAnalysisReport($date_from, $date_to, $total, $avg_rating, $rating_distribution, $reviews_result);
        $response = ['success' => true, 'content' => $content, 'filename' => $filename . '_rating_analysis.html', 'type' => 'html'];
    }
}

function generateSummaryReport($date_from, $date_to, $total, $avg_rating, $rating_distribution, $status_filter, $rating_filter) {
    $status_text = $status_filter === 'all' ? 'All Status' : ucfirst($status_filter);
    $rating_text = $rating_filter > 0 ? $rating_filter . ' Stars Only' : 'All Ratings';
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Perfect Laundry - Review Summary Report</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            body {
                font-family: "Poppins", "Segoe UI", Arial, sans-serif;
                background: #f5f5f5;
                padding: 40px;
                color: #333;
            }
            .report-container {
                max-width: 900px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            .report-header {
                background: linear-gradient(135deg, #1a2a3a, #0d1c2a);
                color: white;
                padding: 30px;
                text-align: center;
            }
            .report-header h1 {
                font-size: 28px;
                margin-bottom: 10px;
            }
            .report-header h1 i {
                margin-right: 10px;
            }
            .report-header p {
                opacity: 0.8;
                font-size: 14px;
            }
            .report-date {
                background: rgba(255,255,255,0.1);
                display: inline-block;
                padding: 5px 15px;
                border-radius: 20px;
                margin-top: 15px;
                font-size: 12px;
            }
            .report-body {
                padding: 30px;
            }
            .stats-grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
                margin-bottom: 30px;
            }
            .stat-card {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 20px;
                text-align: center;
                border: 1px solid #e0e0e0;
            }
            .stat-card .number {
                font-size: 36px;
                font-weight: 700;
                background: linear-gradient(135deg, #27AE60, #6FCF97);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }
            .stat-card .label {
                color: #666;
                font-size: 14px;
                margin-top: 5px;
            }
            .rating-section {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 20px;
                margin-bottom: 30px;
            }
            .rating-section h3 {
                margin-bottom: 20px;
                color: #1a2a3a;
            }
            .rating-bar {
                display: flex;
                align-items: center;
                margin-bottom: 12px;
            }
            .rating-label {
                width: 60px;
                font-weight: 600;
            }
            .rating-bar-fill {
                flex: 1;
                height: 25px;
                background: #e0e0e0;
                border-radius: 12px;
                overflow: hidden;
                margin: 0 10px;
            }
            .rating-bar-fill span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #F59E0B, #FFB800);
                border-radius: 12px;
                transition: width 0.5s;
            }
            .rating-count {
                width: 50px;
                font-size: 14px;
                color: #666;
            }
            .filter-info {
                background: #e8f5e9;
                border-radius: 10px;
                padding: 15px;
                margin-top: 20px;
                font-size: 13px;
                color: #2e7d32;
            }
            .report-footer {
                background: #f8f9fa;
                padding: 20px 30px;
                text-align: center;
                border-top: 1px solid #e0e0e0;
                font-size: 12px;
                color: #999;
            }
            @media print {
                body {
                    padding: 0;
                    background: white;
                }
                .report-container {
                    box-shadow: none;
                }
                .no-print {
                    display: none;
                }
            }
        </style>
    </head>
    <body>
        <div class="report-container">
            <div class="report-header">
                <h1><i class="fas fa-chart-line"></i> Perfect Laundry</h1>
                <h2>Customer Review Summary Report</h2>
                <div class="report-date">Period: ' . date('F j, Y', strtotime($date_from)) . ' - ' . date('F j, Y', strtotime($date_to)) . '</div>
            </div>
            <div class="report-body">
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="number">' . number_format($total) . '</div>
                        <div class="label">Total Reviews</div>
                    </div>
                    <div class="stat-card">
                        <div class="number">' . number_format($avg_rating, 1) . ' / 5.0</div>
                        <div class="label">Average Rating</div>
                    </div>
                </div>
                
                <div class="rating-section">
                    <h3>Rating Distribution</h3>';
                    
    for ($i = 5; $i >= 1; $i--) {
        $percentage = $total > 0 ? ($rating_distribution[$i] / $total) * 100 : 0;
        $stars = str_repeat('★', $i) . str_repeat('☆', 5 - $i);
        $html .= '
                    <div class="rating-bar">
                        <div class="rating-label">' . $stars . '</div>
                        <div class="rating-bar-fill">
                            <span style="width: ' . $percentage . '%"></span>
                        </div>
                        <div class="rating-count">' . number_format($rating_distribution[$i]) . ' (' . number_format($percentage, 1) . '%)</div>
                    </div>';
    }
    
    $html .= '
                </div>
                
                <div class="filter-info">
                    <strong>Filters Applied:</strong><br>
                    • Status: ' . $status_text . '<br>
                    • Rating: ' . $rating_text . '
                </div>
            </div>
            <div class="report-footer">
                Generated on ' . date('F j, Y g:i A') . ' | Perfect Laundry Review System
            </div>
        </div>
        <div class="no-print" style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()" style="padding: 10px 20px; background: #27AE60; color: white; border: none; border-radius: 8px; cursor: pointer;">Print / Save as PDF</button>
        </div>
        <script>
            document.querySelector(".no-print button")?.addEventListener("click", () => window.print());
        </script>
    </body>
    </html>';
    
    return $html;
}

function generateDetailedCSV($reviews_result) {
    $csv = "ID,Customer Name,Email,Phone,Rating,Review Message,Service Type,Status,Admin Reply,Date Submitted\n";
    
    while ($row = mysqli_fetch_assoc($reviews_result)) {
        $csv .= '"' . $row['id'] . '",';
        $csv .= '"' . addslashes($row['customer_name']) . '",';
        $csv .= '"' . $row['customer_email'] . '",';
        $csv .= '"' . ($row['phone'] ?? '') . '",';
        $csv .= ($row['rating'] ?? 'N/A') . ',';
        $csv .= '"' . addslashes(str_replace(["\n", "\r"], ' ', $row['message'])) . '",';
        $csv .= '"' . ($row['service_type'] ?? 'N/A') . '",';
        $csv .= '"' . $row['status'] . '",';
        $csv .= '"' . addslashes($row['admin_reply'] ?? '') . '",';
        $csv .= '"' . $row['created_at'] . "\"\n";
    }
    
    return $csv;
}

function generateRatingAnalysisReport($date_from, $date_to, $total, $avg_rating, $rating_distribution, $reviews_result) {
    // Calculate percentages
    $percentages = [];
    for ($i = 1; $i <= 5; $i++) {
        $percentages[$i] = $total > 0 ? round(($rating_distribution[$i] / $total) * 100, 1) : 0;
    }
    
    // Calculate sentiment
    $positive = $rating_distribution[5] + $rating_distribution[4];
    $neutral = $rating_distribution[3];
    $negative = $rating_distribution[2] + $rating_distribution[1];
    $positive_percent = $total > 0 ? round(($positive / $total) * 100, 1) : 0;
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Perfect Laundry - Rating Analysis Report</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: "Poppins", "Segoe UI", Arial, sans-serif;
                background: #f5f5f5;
                padding: 40px;
                color: #333;
            }
            .report-container {
                max-width: 1000px;
                margin: 0 auto;
                background: white;
                border-radius: 20px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            .report-header {
                background: linear-gradient(135deg, #1a2a3a, #0d1c2a);
                color: white;
                padding: 30px;
                text-align: center;
            }
            .report-header h1 { font-size: 28px; margin-bottom: 10px; }
            .report-header p { opacity: 0.8; font-size: 14px; }
            .report-date {
                background: rgba(255,255,255,0.1);
                display: inline-block;
                padding: 5px 15px;
                border-radius: 20px;
                margin-top: 15px;
                font-size: 12px;
            }
            .report-body { padding: 30px; }
            .kpi-grid {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
                margin-bottom: 30px;
            }
            .kpi-card {
                background: linear-gradient(135deg, #f8f9fa, #fff);
                border-radius: 15px;
                padding: 20px;
                text-align: center;
                border: 1px solid #e0e0e0;
            }
            .kpi-card .value {
                font-size: 42px;
                font-weight: 700;
            }
            .kpi-card .label { color: #666; font-size: 14px; margin-top: 5px; }
            .kpi-card.positive .value { color: #27AE60; }
            .kpi-card.neutral .value { color: #F59E0B; }
            .kpi-card.negative .value { color: #EF4444; }
            
            .chart-container {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 20px;
                margin-bottom: 30px;
            }
            .chart-title { font-size: 18px; margin-bottom: 20px; color: #1a2a3a; }
            .bar-item {
                display: flex;
                align-items: center;
                margin-bottom: 15px;
            }
            .bar-label {
                width: 80px;
                font-weight: 600;
            }
            .bar-fill {
                flex: 1;
                height: 35px;
                background: #e0e0e0;
                border-radius: 8px;
                overflow: hidden;
                margin: 0 15px;
            }
            .bar-fill span {
                display: block;
                height: 100%;
                background: linear-gradient(90deg, #27AE60, #6FCF97);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: flex-end;
                padding-right: 10px;
                color: white;
                font-size: 12px;
                font-weight: 500;
            }
            .bar-percent {
                width: 60px;
                font-weight: 500;
            }
            
            .review-list {
                background: #f8f9fa;
                border-radius: 15px;
                padding: 20px;
            }
            .review-item {
                border-bottom: 1px solid #e0e0e0;
                padding: 15px 0;
            }
            .review-item:last-child { border-bottom: none; }
            .review-header {
                display: flex;
                justify-content: space-between;
                margin-bottom: 8px;
            }
            .review-name { font-weight: 600; }
            .review-stars { color: #FFB800; font-size: 12px; }
            .review-message { color: #666; font-size: 13px; line-height: 1.5; }
            .report-footer {
                background: #f8f9fa;
                padding: 20px;
                text-align: center;
                border-top: 1px solid #e0e0e0;
                font-size: 12px;
                color: #999;
            }
            @media print {
                body { padding: 0; background: white; }
                .report-container { box-shadow: none; }
                .no-print { display: none; }
            }
        </style>
    </head>
    <body>
        <div class="report-container">
            <div class="report-header">
                <h1><i class="fas fa-chart-simple"></i> Rating Analysis Report</h1>
                <p>Customer Sentiment & Rating Distribution Analysis</p>
                <div class="report-date">Period: ' . date('F j, Y', strtotime($date_from)) . ' - ' . date('F j, Y', strtotime($date_to)) . '</div>
            </div>
            <div class="report-body">
                <div class="kpi-grid">
                    <div class="kpi-card positive">
                        <div class="value">' . $positive_percent . '%</div>
                        <div class="label">Positive Sentiment (4-5 Stars)</div>
                    </div>
                    <div class="kpi-card neutral">
                        <div class="value">' . number_format($avg_rating, 1) . '</div>
                        <div class="label">Average Rating</div>
                    </div>
                    <div class="kpi-card">
                        <div class="value">' . number_format($total) . '</div>
                        <div class="label">Total Reviews</div>
                    </div>
                </div>
                
                <div class="chart-container">
                    <div class="chart-title">Rating Distribution</div>';
    
    for ($i = 5; $i >= 1; $i--) {
        $stars = str_repeat('★', $i) . str_repeat('☆', 5 - $i);
        $html .= '
                    <div class="bar-item">
                        <div class="bar-label">' . $stars . '</div>
                        <div class="bar-fill">
                            <span style="width: ' . $percentages[$i] . '%">' . $percentages[$i] . '%</span>
                        </div>
                        <div class="bar-percent">' . number_format($rating_distribution[$i]) . ' reviews</div>
                    </div>';
    }
    
    $html .= '
                </div>
                
                <div class="review-list">
                    <div class="chart-title">Recent Customer Reviews</div>';
    
    $count = 0;
    while ($row = mysqli_fetch_assoc($reviews_result) && $count < 10) {
        $stars = str_repeat('★', intval($row['rating'])) . str_repeat('☆', 5 - intval($row['rating']));
        $html .= '
                    <div class="review-item">
                        <div class="review-header">
                            <span class="review-name">' . htmlspecialchars($row['customer_name']) . '</span>
                            <span class="review-stars">' . $stars . '</span>
                        </div>
                        <div class="review-message">"' . htmlspecialchars(substr($row['message'], 0, 150)) . (strlen($row['message']) > 150 ? '...' : '') . '"</div>
                    </div>';
        $count++;
    }
    
    $html .= '
                    ' . ($count == 0 ? '<p style="text-align: center; color: #999;">No reviews found for this period</p>' : '') . '
                </div>
            </div>
            <div class="report-footer">
                Generated on ' . date('F j, Y g:i A') . ' | Perfect Laundry Review System
            </div>
        </div>
        <div class="no-print" style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()" style="padding: 10px 20px; background: #27AE60; color: white; border: none; border-radius: 8px; cursor: pointer;">Print / Save as PDF</button>
        </div>
    </body>
    </html>';
    
    return $html;
}

echo json_encode($response);
?>