<?php
// Start session
session_start();

// Check if admin is logged in (optional but recommended)
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}

// Include database configuration
require_once 'config_customers.php';

// Get filter and search parameters
$filter = isset($_GET['filter']) ? mysqli_real_escape_string($conn, $_GET['filter']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Build query conditions (only customers, not admins)
$where_conditions = ["(role='Customer' OR role='customer' OR role IS NULL)"];

if (!empty($search)) {
    $where_conditions[] = "(full_name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%')";
}

if (!empty($filter) && $filter != 'All') {
    // Check if status column exists
    $status_exists = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0;
    if ($status_exists) {
        $where_conditions[] = "status = '$filter'";
    }
}

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get all customers (no limit for export)
$query = "SELECT id, full_name, email, phone, 
          COALESCE(status, 'Active') as status, 
          DATE_FORMAT(created_at, '%Y-%m-%d') as joined_date,
          COALESCE(address, '') as address
          FROM users $where_clause ORDER BY id DESC";

$result = mysqli_query($conn, $query);

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="customers_export_' . date('Y-m-d') . '.csv"');

// Create output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel compatibility
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Add column headers
fputcsv($output, [
    'ID',
    'Full Name',
    'Email Address',
    'Phone Number',
    'Status',
    'Joined Date',
    'Address'
]);

// Add data rows
while ($row = mysqli_fetch_assoc($result)) {
    fputcsv($output, [
        $row['id'],
        $row['full_name'],
        $row['email'],
        $row['phone'],
        $row['status'],
        $row['joined_date'],
        $row['address']
    ]);
}

// Close the output stream
fclose($output);
exit;
?>