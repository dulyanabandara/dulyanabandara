<?php
// Include database config for reviews
require_once 'config_review.php';

// Get statistics for display
$total_reviews = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT COUNT(*) as count FROM feedback WHERE type='review' AND status='approved'"))['count'] ?? 0;
$avg_rating_result = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT AVG(rating) as avg FROM feedback WHERE type='review' AND rating IS NOT NULL AND status='approved'"));
$avg_rating = isset($avg_rating_result['avg']) && $avg_rating_result['avg'] !== null ? round((float)$avg_rating_result['avg'], 1) : 0;

// Fetch approved reviews for carousel
$reviews_query = "SELECT customer_name, rating, message, service_type, DATE_FORMAT(created_at, '%M %d, %Y') as formatted_date 
                  FROM feedback 
                  WHERE type='review' AND status='approved' AND rating IS NOT NULL 
                  ORDER BY created_at DESC 
                  LIMIT 10";
$reviews_result = mysqli_query($conn_review, $reviews_query);
$reviews = [];
while ($row = mysqli_fetch_assoc($reviews_result)) {
    $reviews[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfect Laundry - Contact Us</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Swiper JS for Carousel -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
    <style>
        /* Contact page specific styles */
        .contact-header {
            padding: 150px 0 60px;
            text-align: center;
        }
        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin: 50px 0;
        }
        .contact-info-card {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 30px;
            border: 1px solid rgba(255,255,255,0.8);
            box-shadow: var(--shadow-md);
            transition: transform 0.3s;
        }
        .contact-info-card:hover {
            transform: translateY(-5px);
        }
        .info-item {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            align-items: flex-start;
            transition: transform 0.3s;
        }
        .info-item:hover {
            transform: translateX(5px);
        }
        .info-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient-green);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: all 0.3s;
        }
        .info-item:hover .info-icon {
            transform: scale(1.1);
            border-radius: 50%;
        }
        .info-icon i {
            font-size: 1.5rem;
            color: white;
        }
        .info-text h4 {
            font-size: 1.2rem;
            margin-bottom: 5px;
            color: var(--text-dark);
        }
        .info-text p, .info-text a {
            color: var(--text-soft);
            text-decoration: none;
            line-height: 1.6;
        }
        .info-text a:hover {
            color: var(--luminous-green-dark);
        }
        .map-placeholder {
            border-radius: 30px;
            overflow: hidden;
            box-shadow: var(--shadow-lg);
            height: 300px;
            background: linear-gradient(135deg, #1a2a3a, #0d1c2a);
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255,255,255,0.8);
            position: relative;
            transition: all 0.3s;
        }
        .map-placeholder:hover {
            transform: scale(1.02);
        }
        .map-placeholder iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
        .form-card {
            background: rgba(255,255,255,0.6);
            backdrop-filter: blur(10px);
            padding: 40px;
            border-radius: 30px;
            border: 1px solid rgba(255,255,255,0.8);
            box-shadow: var(--shadow-md);
            transition: transform 0.3s;
        }
        .form-card:hover {
            transform: translateY(-5px);
        }
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid rgba(255,255,255,0.9);
            border-radius: 50px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(5px);
            transition: all 0.3s;
        }
        .form-group textarea {
            border-radius: 25px;
            resize: vertical;
        }
        .form-group select {
            cursor: pointer;
        }
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--luminous-green);
            box-shadow: 0 0 0 3px rgba(111,207,151,0.2);
            transform: translateY(-2px);
        }
        
        /* Floating label effect */
        .form-group.floating {
            position: relative;
        }
        .form-group.floating input:focus + label,
        .form-group.floating input:not(:placeholder-shown) + label {
            transform: translateY(-30px);
            font-size: 12px;
            opacity: 1;
        }
        
        .btn-submit {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 50px;
            background: var(--gradient-green);
            color: white;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: all 0.3s;
            box-shadow: var(--shadow-colored);
            position: relative;
            overflow: hidden;
        }
        .btn-submit::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255,255,255,0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        .btn-submit:hover::before {
            width: 300px;
            height: 300px;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 35px rgba(39,174,96,0.4);
        }
        
        /* Loading spinner */
        .btn-submit:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        
        .fa-spin {
            animation: fa-spin 1s infinite linear;
        }
        
        @keyframes fa-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Toast notification */
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--gradient-green);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1001;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        /* Review Carousel Styles - NEW FEATURE */
        .testimonial-carousel-section {
            margin: 80px 0;
            padding: 60px 0;
            background: rgba(111,207,151,0.05);
            border-radius: 50px;
        }
        
        .testimonial-card {
            background: rgba(255,255,255,0.8);
            backdrop-filter: blur(10px);
            border-radius: 30px;
            padding: 30px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.9);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            transition: all 0.3s;
            margin: 20px 10px;
        }
        
        .testimonial-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 30px 60px rgba(0,0,0,0.15);
        }
        
        .testimonial-avatar {
            width: 70px;
            height: 70px;
            background: var(--gradient-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 28px;
            color: white;
            font-weight: bold;
        }
        
        .testimonial-name {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 5px;
        }
        
        .testimonial-stars {
            color: #FFB800;
            margin: 10px 0;
            font-size: 14px;
        }
        
        .testimonial-text {
            color: var(--text-soft);
            font-size: 0.9rem;
            line-height: 1.6;
            margin: 15px 0;
            font-style: italic;
        }
        
        .testimonial-service {
            display: inline-block;
            background: rgba(111,207,151,0.2);
            padding: 5px 15px;
            border-radius: 50px;
            font-size: 12px;
            color: var(--luminous-green-dark);
            margin-top: 10px;
        }
        
        .testimonial-date {
            font-size: 11px;
            color: var(--text-muted);
            margin-top: 10px;
        }
        
        .swiper-button-next,
        .swiper-button-prev {
            color: var(--luminous-green);
            background: rgba(255,255,255,0.8);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            backdrop-filter: blur(5px);
        }
        
        .swiper-button-next:after,
        .swiper-button-prev:after {
            font-size: 18px;
        }
        
        .swiper-pagination-bullet-active {
            background: var(--luminous-green);
        }
        
        /* Quick Contact Floating Button */
        .quick-contact-btn {
            position: fixed;
            bottom: 30px;
            left: 30px;
            width: 55px;
            height: 55px;
            background: var(--gradient-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 5px 20px rgba(39,174,96,0.4);
            transition: all 0.3s;
            z-index: 999;
            border: none;
            color: white;
            font-size: 24px;
        }
        
        .quick-contact-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(39,174,96,0.6);
        }
        
        .quick-contact-panel {
            position: fixed;
            bottom: 100px;
            left: 30px;
            width: 280px;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            transform: translateX(-120%);
            transition: transform 0.3s;
            z-index: 998;
            border: 1px solid rgba(255,255,255,0.8);
        }
        
        .quick-contact-panel.active {
            transform: translateX(0);
        }
        
        .quick-contact-panel h4 {
            margin-bottom: 15px;
            color: var(--text-dark);
        }
        
        .quick-contact-panel a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 0;
            color: var(--text-soft);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .quick-contact-panel a:hover {
            color: var(--luminous-green);
            transform: translateX(5px);
        }
        
        .quick-contact-panel i {
            width: 25px;
        }
        
        @media (max-width: 768px) {
            .contact-grid {
                grid-template-columns: 1fr;
            }
            .testimonial-card {
                margin: 10px;
            }
            .quick-contact-btn {
                bottom: 20px;
                left: 20px;
                width: 45px;
                height: 45px;
                font-size: 20px;
            }
            .quick-contact-panel {
                bottom: 80px;
                left: 20px;
                width: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Particle Background -->
    <div id="particles-js"></div>

    <div class="container">
        <!-- Navigation Bar -->
        <nav class="navbar">
            <div class="nav-container">
                <div class="nav-logo">
                    <img src="https://via.placeholder.com/50x50/4CAF50/FFFFFF?text=PL" alt="Perfect Laundry Logo" class="logo-img">
                    <span class="logo-text">Perfect<span class="logo-highlight">Laundry</span></span>
                </div>
                
                <ul class="nav-menu" id="navMenu">
                    <li class="nav-item"><a href="home.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="pricing.php" class="nav-link">Services</a></li>
                    <li class="nav-item"><a href="BookOnline.html" class="nav-link">Book Online</a></li>
                    <li class="nav-item"><a href="about.html" class="nav-link">About Us</a></li>
                    <li class="nav-item"><a href="contact.php" class="nav-link active">Contact Us</a></li>
                </ul>
                
                <div class="nav-buttons">
                    <a href="login.html" class="btn-login"><i class="fas fa-user-circle"></i> Log In</a>
                    <div class="hamburger" id="hamburger">
                        <span class="bar"></span>
                        <span class="bar"></span>
                        <span class="bar"></span>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Contact Header -->
        <section class="contact-header" data-aos="fade-up">
            <span class="section-subtitle">GET IN TOUCH</span>
            <h1 class="section-title">We'd Love To Hear <span class="gradient-text">From You</span></h1>
            <p class="section-description" style="max-width: 600px; margin: 0 auto;">
                Have a question, need a quote, or just want to say hello? Reach out to us anytime.
            </p>
        </section>

        <!-- Contact Grid: Info + Form -->
        <div class="contact-grid">
            <!-- Left side: contact info -->
            <div data-aos="fade-right">
                <div class="contact-info-card">
                    <h2 class="delivery-title" style="font-size: 2rem; margin-bottom: 30px;">Contact <span class="gradient-text">Information</span></h2>
                    
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="info-text">
                            <h4>Visit Us</h4>
                            <p>123, Main Street, Tangalle<br>Sri Lanka</p>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-phone-alt"></i></div>
                        <div class="info-text">
                            <h4>Call Us</h4>
                            <p>+94 77 123 4567<br>+94 47 123 4567</p>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-envelope"></i></div>
                        <div class="info-text">
                            <h4>Email Us</h4>
                            <p><a href="mailto:info@perfectlaundry.lk">info@perfectlaundry.lk</a><br><a href="mailto:support@perfectlaundry.lk">support@perfectlaundry.lk</a></p>
                        </div>
                    </div>

                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-clock"></i></div>
                        <div class="info-text">
                            <h4>Working Hours</h4>
                            <p>Monday - Sunday: 7:00 AM – 9:00 PM<br>Pickup & delivery available 24/7</p>
                        </div>
                    </div>
                </div>

                <!-- Live Map -->
                <div class="map-placeholder" data-aos="zoom-in" style="margin-top: 30px;">
                    <iframe 
                        src="https://maps.google.com/maps?q=Tangalle%2C%20Sri%20Lanka&t=&z=13&ie=UTF8&iwloc=&output=embed"
                        allowfullscreen>
                    </iframe>
                </div>
            </div>

            <!-- Right side: contact form -->
            <div class="form-card" data-aos="fade-left">
                <h2 class="delivery-title" style="font-size: 2rem; margin-bottom: 30px;">Send Us A <span class="gradient-text">Message</span></h2>
                <form id="contactForm">
                    <div class="form-group">
                        <input type="text" id="name" name="name" placeholder="Your Full Name" required>
                    </div>
                    <div class="form-group">
                        <input type="email" id="email" name="email" placeholder="Email Address" required>
                    </div>
                    <div class="form-group">
                        <input type="tel" id="phone" name="phone" placeholder="Phone Number (optional)">
                    </div>
                    <div class="form-group">
                        <textarea id="message" name="message" rows="5" placeholder="How can we help you?" required></textarea>
                    </div>
                    <button type="submit" class="btn-submit" id="submitBtn">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>
        </div>

        <!-- ========== NEW FEATURE: TESTIMONIAL CAROUSEL ========== -->
        <?php if (!empty($reviews)): ?>
        <section class="testimonial-carousel-section" data-aos="fade-up">
            <div class="section-header">
                <span class="section-subtitle">❤️ WHAT OUR CUSTOMERS SAY ❤️</span>
                <h2 class="section-title">Real Stories From <span class="gradient-text">Happy Customers</span></h2>
                <p class="section-description">Don't just take our word for it - hear from people who trust us with their laundry</p>
                <?php if ($total_reviews > 0): ?>
                <div style="margin-top: 15px; text-align: center;">
                    <span style="background: rgba(111,207,151,0.2); padding: 8px 20px; border-radius: 50px; font-size: 14px;">
                        <i class="fas fa-star" style="color: #FFB800;"></i>
                        <?php echo $avg_rating; ?>/5 Average Rating • 
                        <i class="fas fa-users"></i> <?php echo $total_reviews; ?>+ Reviews
                    </span>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="swiper testimonialSwiper" style="padding: 30px 20px;">
                <div class="swiper-wrapper">
                    <?php foreach ($reviews as $review): ?>
                    <div class="swiper-slide">
                        <div class="testimonial-card">
                            <div class="testimonial-avatar">
                                <?php echo strtoupper(substr($review['customer_name'], 0, 2)); ?>
                            </div>
                            <div class="testimonial-name"><?php echo htmlspecialchars($review['customer_name']); ?></div>
                            <div class="testimonial-stars">
                                <?php 
                                $rating = intval($review['rating']);
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $rating) {
                                        echo '<i class="fas fa-star"></i>';
                                    } else {
                                        echo '<i class="far fa-star"></i>';
                                    }
                                }
                                ?>
                            </div>
                            <div class="testimonial-text">
                                "<?php echo htmlspecialchars(substr($review['message'], 0, 120)); ?><?php echo strlen($review['message']) > 120 ? '...' : ''; ?>"
                            </div>
                            <div class="testimonial-service">
                                <i class="fas fa-tag"></i> <?php echo htmlspecialchars($review['service_type'] ?? 'Laundry Service'); ?>
                            </div>
                            <div class="testimonial-date">
                                <i class="far fa-calendar-alt"></i> <?php echo $review['formatted_date']; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <!-- Navigation Arrows -->
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </section>
        <?php endif; ?>

        <!-- ========== REVIEW SUBMISSION SECTION ========== -->
        <section class="review-section" data-aos="fade-up" style="margin: 60px 0;">
            <div class="section-header">
                <span class="section-subtitle">⭐ SHARE YOUR EXPERIENCE ⭐</span>
                <h2 class="section-title">Rate Our <span class="gradient-text">Service</span></h2>
                <p class="section-description">We value your feedback! Tell us about your laundry experience.</p>
            </div>
            
            <div class="review-form-container" style="max-width: 600px; margin: 0 auto;">
                <div class="review-card" style="background: rgba(255,255,255,0.7); backdrop-filter: blur(10px); border-radius: 30px; padding: 40px; border: 1px solid rgba(255,255,255,0.8);">
                    <form id="customerReviewForm">
                        <div class="form-group">
                            <input type="text" id="review_name" placeholder="Your Full Name" required style="width: 100%; padding: 15px; border-radius: 25px; border: 2px solid rgba(255,255,255,0.9); background: rgba(255,255,255,0.7);">
                        </div>
                        
                        <div class="form-group">
                            <input type="email" id="review_email" placeholder="Your Email Address" required style="width: 100%; padding: 15px; border-radius: 25px; border: 2px solid rgba(255,255,255,0.9); background: rgba(255,255,255,0.7);">
                        </div>
                        
                        <div class="form-group">
                            <select id="review_service" required style="width: 100%; padding: 15px; border-radius: 25px; border: 2px solid rgba(255,255,255,0.9); background: rgba(255,255,255,0.7);">
                                <option value="">Select Service Used</option>
                                <option value="Dry Cleaning">Dry Cleaning</option>
                                <option value="Wash & Fold">Wash & Fold</option>
                                <option value="Steam Iron">Steam Iron</option>
                                <option value="Stain Removal">Stain Removal</option>
                                <option value="Premium Care">Premium Care</option>
                            </select>
                        </div>
                        
                        <div class="form-group" style="text-align: center;">
                            <label style="display: block; margin-bottom: 10px; font-weight: 500;">Your Rating</label>
                            <div class="review-rating-stars" style="display: flex; gap: 15px; justify-content: center; margin: 15px 0;">
                                <i class="far fa-star review-star" data-rating="1" style="font-size: 35px; cursor: pointer; transition: all 0.2s;"></i>
                                <i class="far fa-star review-star" data-rating="2" style="font-size: 35px; cursor: pointer; transition: all 0.2s;"></i>
                                <i class="far fa-star review-star" data-rating="3" style="font-size: 35px; cursor: pointer; transition: all 0.2s;"></i>
                                <i class="far fa-star review-star" data-rating="4" style="font-size: 35px; cursor: pointer; transition: all 0.2s;"></i>
                                <i class="far fa-star review-star" data-rating="5" style="font-size: 35px; cursor: pointer; transition: all 0.2s;"></i>
                            </div>
                            <input type="hidden" id="review_rating" value="0">
                        </div>
                        
                        <div class="form-group">
                            <textarea id="review_comment" rows="4" placeholder="Share your experience..." required style="width: 100%; padding: 15px; border-radius: 25px; border: 2px solid rgba(255,255,255,0.9); background: rgba(255,255,255,0.7); resize: vertical;"></textarea>
                        </div>
                        
                        <button type="submit" id="submitReviewBtn" class="btn-submit" style="width: 100%;">
                            <i class="fas fa-star"></i> Submit Review
                        </button>
                    </form>
                    <div id="reviewFormMessage" style="margin-top: 20px; text-align: center; display: none; padding: 10px; border-radius: 15px;"></div>
                </div>
            </div>
        </section>

        <!-- Quick Contact Floating Button (NEW EXTRA FEATURE) -->
        <button class="quick-contact-btn" id="quickContactBtn">
            <i class="fas fa-headset"></i>
        </button>
        
        <div class="quick-contact-panel" id="quickContactPanel">
            <h4><i class="fas fa-headset"></i> Quick Support</h4>
            <a href="tel:+94771234567"><i class="fas fa-phone"></i> Call: +94 77 123 4567</a>
            <a href="https://wa.me/94771234567" target="_blank"><i class="fab fa-whatsapp"></i> WhatsApp Us</a>
            <a href="mailto:support@perfectlaundry.lk"><i class="fas fa-envelope"></i> Email Support</a>
            <a href="#"><i class="fas fa-clock"></i> 24/7 Customer Support</a>
        </div>

        <style>
            .review-star:hover,
            .review-star.active {
                color: #FFB800 !important;
                transform: scale(1.1);
            }
            .review-star {
                color: #ccc;
                transition: all 0.2s;
            }
        </style>
        
        <!-- Footer -->
        <footer class="footer">
            <div class="footer-content">
                <div class="footer-section" data-aos="fade-up">
                    <div class="footer-logo">
                        <img src="https://via.placeholder.com/40x40/4CAF50/FFFFFF?text=PL" alt="Perfect Laundry Logo">
                        <span>PerfectLaundry</span>
                    </div>
                    <p class="footer-description">
                        Revolutionizing laundry services with technology and care. Your clothes deserve the best!
                    </p>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>

                <div class="footer-section" data-aos="fade-up" data-aos-delay="100">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="home.html"><i class="fas fa-chevron-right"></i> Home</a></li>
                        <li><a href="#services"><i class="fas fa-chevron-right"></i> Services</a></li>
                        <li><a href="#book-online"><i class="fas fa-chevron-right"></i> Book Online</a></li>
                        <li><a href="about.html"><i class="fas fa-chevron-right"></i> About Us</a></li>
                        <li><a href="contact.php"><i class="fas fa-chevron-right"></i> Contact Us</a></li>
                    </ul>
                </div>

                <div class="footer-section" data-aos="fade-up" data-aos-delay="200">
                    <h4>Our Services</h4>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Dry Cleaning</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Wash & Fold</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Steam Iron</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Stain Removal</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Premium Care</a></li>
                    </ul>
                </div>

                <div class="footer-section" data-aos="fade-up" data-aos-delay="300">
                    <h4>Contact Info</h4>
                    <ul class="contact-info">
                        <li><i class="fas fa-map-marker-alt"></i> 123, Main Street, Tangalle</li>
                        <li><i class="fas fa-phone"></i> +94 77 123 4567</li>
                        <li><i class="fas fa-envelope"></i> info@perfectlaundry.lk</li>
                        <li><i class="fas fa-clock"></i> Mon-Sun: 7:00 AM - 9:00 PM</li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; 2026 Perfect Laundry. All rights reserved. | Designed by Team Infynet</p>
                    <div class="footer-bottom-links">
                        <a href="#">Privacy Policy</a>
                        <a href="#">Terms of Service</a>
                        <a href="#">FAQ</a>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Back to Top Button -->
    <button id="backToTop" class="back-to-top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <!-- Scripts -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="script.js"></script>
    
    <script>
        // Initialize AOS
        AOS.init({
            duration: 800,
            once: true
        });
        
        // Initialize Swiper Carousel (NEW FEATURE)
        const swiper = new Swiper('.testimonialSwiper', {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            breakpoints: {
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            },
        });
        
        // Quick Contact Panel (NEW EXTRA FEATURE)
        const quickContactBtn = document.getElementById('quickContactBtn');
        const quickContactPanel = document.getElementById('quickContactPanel');
        
        quickContactBtn.addEventListener('click', function() {
            quickContactPanel.classList.toggle('active');
        });
        
        // Close panel when clicking outside
        document.addEventListener('click', function(event) {
            if (!quickContactBtn.contains(event.target) && !quickContactPanel.contains(event.target)) {
                quickContactPanel.classList.remove('active');
            }
        });
        
        // Toast notification function
        function showToast(message, isError = false) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.style.background = isError ? 'linear-gradient(135deg, #EF4444, #DC2626)' : 'linear-gradient(135deg, #6FCF97, #27AE60)';
            toast.innerHTML = `<i class="fas ${isError ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i> ${message}`;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }
        
        // ========== CONTACT FORM SUBMISSION ==========
        const contactForm = document.getElementById('contactForm');

        if (contactForm) {
            contactForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = {
                    name: document.getElementById('name').value,
                    email: document.getElementById('email').value,
                    phone: document.getElementById('phone').value,
                    message: document.getElementById('message').value
                };
                
                if (!formData.name || !formData.email || !formData.message) {
                    showToast('Please fill in all required fields (Name, Email, and Message)', true);
                    return;
                }
                
                const submitBtn = document.getElementById('submitBtn');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
                submitBtn.disabled = true;
                
                try {
                    const response = await fetch('submit_contact.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formData)
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        showToast(data.message);
                        contactForm.reset();
                    } else {
                        showToast(data.message, true);
                    }
                } catch(error) {
                    showToast('Failed to send message. Please try again.', true);
                } finally {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
            });
        }
        
        // ========== REVIEW FORM STARS FUNCTIONALITY ==========
        const reviewStars = document.querySelectorAll('.review-star');
        const reviewRatingInput = document.getElementById('review_rating');

        reviewStars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = parseInt(this.dataset.rating);
                reviewRatingInput.value = rating;
                
                reviewStars.forEach((s, index) => {
                    if(index < rating) {
                        s.classList.add('active');
                        s.classList.remove('far');
                        s.classList.add('fas');
                    } else {
                        s.classList.remove('active');
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
            
            star.addEventListener('mouseenter', function() {
                const rating = parseInt(this.dataset.rating);
                reviewStars.forEach((s, index) => {
                    if(index < rating) {
                        s.classList.add('fas');
                        s.classList.remove('far');
                    } else {
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
            
            star.addEventListener('mouseleave', function() {
                const currentRating = parseInt(reviewRatingInput.value);
                reviewStars.forEach((s, index) => {
                    if(index < currentRating) {
                        s.classList.add('fas');
                        s.classList.remove('far');
                    } else {
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
        });

        // ========== REVIEW FORM SUBMISSION ==========
        document.getElementById('customerReviewForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const rating = parseInt(document.getElementById('review_rating').value);
            if(rating === 0) {
                showToast('Please select a rating (1-5 stars)', true);
                return;
            }
            
            const formData = {
                customer_name: document.getElementById('review_name').value,
                customer_email: document.getElementById('review_email').value,
                rating: rating,
                comment: document.getElementById('review_comment').value,
                service_type: document.getElementById('review_service').value,
                phone: ''
            };
            
            const submitBtn = document.getElementById('submitReviewBtn');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            submitBtn.disabled = true;
            
            try {
                const response = await fetch('submit_review.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
                
                const data = await response.json();
                const messageDiv = document.getElementById('reviewFormMessage');
                
                if(data.success) {
                    messageDiv.style.display = 'block';
                    messageDiv.style.background = 'rgba(111,207,151,0.2)';
                    messageDiv.style.color = '#27AE60';
                    messageDiv.innerHTML = '✅ ' + data.message;
                    this.reset();
                    reviewRatingInput.value = 0;
                    reviewStars.forEach(s => {
                        s.classList.remove('active', 'fas');
                        s.classList.add('far');
                    });
                    
                    // Refresh page after 2 seconds to show new review in carousel
                    setTimeout(() => location.reload(), 2000);
                } else {
                    messageDiv.style.display = 'block';
                    messageDiv.style.background = 'rgba(239,68,68,0.2)';
                    messageDiv.style.color = '#EF4444';
                    messageDiv.innerHTML = '❌ ' + data.message;
                }
                
                setTimeout(() => {
                    messageDiv.style.display = 'none';
                }, 5000);
                
            } catch(error) {
                showToast('Failed to submit review. Please try again.', true);
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });
        
        // Particles background initialization
        if (typeof particlesJS !== 'undefined') {
            particlesJS('particles-js', {
                particles: {
                    number: { value: 80, density: { enable: true, value_area: 800 } },
                    color: { value: '#6FCF97' },
                    shape: { type: 'circle' },
                    opacity: { value: 0.5, random: false },
                    size: { value: 3, random: true },
                    line_linked: { enable: true, distance: 150, color: '#6FCF97', opacity: 0.4, width: 1 },
                    move: { enable: true, speed: 2, direction: 'none', random: false, straight: false, out_mode: 'out' }
                },
                interactivity: {
                    detect_on: 'canvas',
                    events: { onhover: { enable: true, mode: 'repulse' }, onclick: { enable: true, mode: 'push' } }
                },
                retina_detect: true
            });
        }
    </script>
</body>
</html>