<?php
// get_visit_laundry.php - Fetch visit laundry orders
session_start();
require_once 'visit_db.php';

$order_id = isset($_GET['order_id']) ? mysqli_real_escape_string($conn, $_GET['order_id']) : null;
$user_id = isset($_GET['user_id']) ? mysqli_real_escape_string($conn, $_GET['user_id']) : null;
$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : null;
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : null;
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : null;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : null;

try {
    if ($order_id) {
        // Get single order by ID
        $sql = "SELECT * FROM visit_laundry_orders WHERE order_id = '$order_id'";
        $result = mysqli_query($conn, $sql);
        $order = mysqli_fetch_assoc($result);
        
        if ($order) {
            // Get order items
            $items_sql = "SELECT * FROM visit_laundry_items WHERE order_id = '$order_id'";
            $items_result = mysqli_query($conn, $items_sql);
            $items = [];
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
            $order['items'] = $items;
            
            echo json_encode(['success' => true, 'order' => $order]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Order not found']);
        }
    } else {
        // Build query with filters
        $conditions = [];
        
        // Add user_id filter if provided (for account page)
        if ($user_id) {
            $conditions[] = "user_id = '$user_id'";
        }
        
        if ($status && $status !== 'all') {
            $conditions[] = "status = '$status'";
        }
        if ($date_from) {
            $conditions[] = "DATE(visit_date) >= '$date_from'";
        }
        if ($date_to) {
            $conditions[] = "DATE(visit_date) <= '$date_to'";
        }
        if ($search) {
            $conditions[] = "(customer_name LIKE '%$search%' OR phone LIKE '%$search%' OR order_id LIKE '%$search%')";
        }
        
        $where_clause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
        $sql = "SELECT * FROM visit_laundry_orders $where_clause ORDER BY visit_date DESC, created_at DESC";
        $result = mysqli_query($conn, $sql);
        
        $orders = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $orders[] = $row;
        }
        
        echo json_encode(['success' => true, 'orders' => $orders]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>