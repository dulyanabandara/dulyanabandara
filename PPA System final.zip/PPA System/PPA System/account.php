<?php
session_start();

// Security check: If no user ID in session, redirect to login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

// Fetch session data
$user_id = $_SESSION['user_id'] ?? 0;
$user_name = $_SESSION['user_name'] ?? 'User';
$user_email = $_SESSION['email'] ?? 'Not provided';
$user_phone = $_SESSION['phone'] ?? 'Not provided';
$user_role = $_SESSION['role'] ?? 'Customer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>My Account | Perfect Laundry</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --sky-blue-1: #E1F3FE;
            --sky-blue-2: #B8E2F2;
            --sky-blue-3: #7FC9E6;
            --sky-blue-4: #4AA3D1;
            --sky-blue-5: #2C7AA0;
            --luminous-green: #6FCF97;
            --luminous-green-dark: #27AE60;
            --white: #FFFFFF;
            --light-gray: #F8FAFC;
            --text-dark: #1A2F3F;
            --text-soft: #2C3E50;
            --gradient-green: linear-gradient(135deg, #6FCF97, #27AE60);
            --shadow-sm: 0 4px 12px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 8px 24px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 16px 32px rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Inter', 'Poppins', sans-serif;
            background: linear-gradient(145deg, #E1F3FE 0%, #C5E6F7 100%);
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
            background: linear-gradient(-45deg, #e1f3fe, #b8e2f2, #9bd5e8, #7fc9e6);
            background-size: 400% 400%;
            animation: gradientFlow 15s ease infinite;
        }

        @keyframes gradientFlow {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Floating Orbs */
        .orb {
            position: fixed;
            border-radius: 50%;
            filter: blur(80px);
            animation: floatOrb 25s infinite ease-in-out;
            z-index: -1;
        }
        .orb-1 { width: 400px; height: 400px; background: rgba(111, 207, 151, 0.3); top: -100px; right: -100px; }
        .orb-2 { width: 500px; height: 500px; background: rgba(74, 163, 209, 0.25); bottom: -150px; left: -150px; animation-delay: 5s; }
        .orb-3 { width: 300px; height: 300px; background: rgba(39, 174, 96, 0.2); top: 50%; left: 50%; transform: translate(-50%, -50%); animation-delay: 10s; }

        @keyframes floatOrb {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.05); }
            66% { transform: translate(-20px, 20px) scale(0.95); }
        }

        /* Floating Bubbles */
        .bubble {
            position: fixed;
            background: rgba(255,255,255,0.4);
            backdrop-filter: blur(3px);
            border-radius: 50%;
            animation: floatBubble 12s infinite ease-in-out;
            z-index: -1;
        }

        @keyframes floatBubble {
            0% { transform: translateY(100vh) scale(0); opacity: 0; }
            20% { opacity: 0.6; }
            100% { transform: translateY(-20vh) scale(1); opacity: 0; }
        }

        /* Navigation Bar */
        .navbar {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            width: calc(100% - 80px);
            max-width: 1320px;
            background: rgba(255, 255, 255, 0.7);
            backdrop-filter: blur(15px);
            border-radius: 60px;
            padding: 15px 30px;
            z-index: 1000;
            box-shadow: 0 8px 32px rgba(74, 163, 209, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.8);
            animation: slideDown 0.5s ease;
        }

        @keyframes slideDown {
            from { top: -100px; opacity: 0; }
            to { top: 20px; opacity: 1; }
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: var(--gradient-green);
            padding: 2px;
            animation: rotate 10s linear infinite;
            box-shadow: 0 0 20px rgba(111, 207, 151, 0.3);
        }

        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .logo-text {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        .logo-highlight {
            background: var(--gradient-green);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-left: 5px;
        }

        .nav-menu {
            display: flex;
            gap: 40px;
            list-style: none;
        }

        .nav-link {
            text-decoration: none;
            color: var(--text-dark);
            font-weight: 500;
            font-size: 1rem;
            position: relative;
            padding: 5px 0;
            transition: color 0.3s ease;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--gradient-green);
            transition: width 0.3s ease;
        }

        .nav-link:hover, .nav-link.active { color: var(--sky-blue-5); }
        .nav-link:hover::before, .nav-link.active::before { width: 100%; }

        .nav-buttons {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        /* User Profile Button */
        .user-profile {
            position: relative;
        }

        .profile-btn {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(111, 207, 151, 0.3);
            padding: 8px 16px;
            border-radius: 40px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.9rem;
            font-weight: 500;
            color: var(--text-dark);
            transition: all 0.3s ease;
        }

        .profile-btn:hover {
            background: rgba(111, 207, 151, 0.2);
            border-color: var(--luminous-green);
        }

        .profile-btn i:first-child {
            font-size: 1.2rem;
            color: var(--luminous-green);
        }

        .profile-name {
            font-weight: 600;
        }

        .profile-dropdown {
            position: absolute;
            top: 50px;
            right: 0;
            width: 220px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .profile-dropdown.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-header {
            padding: 20px;
            background: linear-gradient(135deg, #E1F3FE, #C5E6F7);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .dropdown-avatar i { font-size: 2.5rem; color: var(--luminous-green); }
        .dropdown-info strong { font-size: 1rem; color: var(--text-dark); display: block; }
        .dropdown-info span { font-size: 0.75rem; color: var(--text-soft); }
        .dropdown-divider { height: 1px; background: #E2E8F0; }
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: var(--text-dark);
            text-decoration: none;
            transition: all 0.2s;
        }
        .dropdown-item:hover { background: #F8FAFC; }
        .dropdown-item i { width: 20px; font-size: 1rem; color: var(--luminous-green); }
        .logout-item { color: #e74c3c; }
        .logout-item i { color: #e74c3c; }
        .logout-item:hover { background: #FEE2E2; }

        .hamburger { display: none; flex-direction: column; cursor: pointer; gap: 6px; }
        .bar { width: 25px; height: 3px; background: var(--gradient-green); border-radius: 3px; }

        @media (max-width: 992px) {
            .nav-menu { display: none; position: absolute; top: 80px; left: 20px; right: 20px; background: rgba(255, 255, 255, 0.98); backdrop-filter: blur(20px); border-radius: 30px; padding: 20px; flex-direction: column; text-align: center; box-shadow: var(--shadow-lg); }
            .nav-menu.active { display: flex; }
            .hamburger { display: flex; }
        }

        /* Main Container */
        .account-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 120px 30px 60px;
        }

        /* Welcome Banner */
        .welcome-banner {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 32px;
            padding: 30px 40px;
            margin-bottom: 35px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            box-shadow: var(--shadow-md);
            border: 1px solid rgba(255,255,255,0.6);
        }

        .welcome-text h1 {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, #1A2F3F, #27AE60);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }

        .welcome-text p { color: var(--text-soft); }
        .member-badge { background: var(--gradient-green); padding: 8px 20px; border-radius: 40px; color: white; font-weight: 600; font-size: 0.85rem; }

        /* Account Grid */
        .account-grid {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 30px;
        }

        /* Sidebar */
        .account-sidebar {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 28px;
            padding: 25px;
            height: fit-content;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(255,255,255,0.6);
        }

        .user-profile-sidebar {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(111,207,151,0.2);
            margin-bottom: 20px;
        }

        .user-avatar {
            width: 80px;
            height: 80px;
            background: var(--gradient-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 2rem;
            color: white;
        }

        .user-profile-sidebar h3 { font-size: 1.1rem; margin-bottom: 5px; }
        .user-profile-sidebar p { color: var(--text-soft); font-size: 0.8rem; word-break: break-all; }

        .sidebar-menu { list-style: none; }
        .sidebar-menu li { margin-bottom: 5px; }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: var(--text-soft);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
        }
        .sidebar-menu a i { width: 22px; color: var(--sky-blue-4); }
        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: var(--gradient-green);
            color: white;
        }
        .sidebar-menu a:hover i, .sidebar-menu a.active i { color: white; }

        /* Main Content */
        .account-content {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 28px;
            padding: 30px;
            box-shadow: var(--shadow-sm);
            border: 1px solid rgba(255,255,255,0.6);
        }

        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .content-header h2 { font-size: 1.5rem; font-weight: 700; color: var(--text-dark); }

        .btn-primary {
            background: var(--gradient-green);
            border: none;
            padding: 10px 24px;
            border-radius: 40px;
            font-weight: 600;
            color: white;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(39,174,96,0.3); }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(111,207,151,0.1);
            padding: 20px;
            border-radius: 20px;
            text-align: center;
            border: 1px solid rgba(111,207,151,0.2);
        }
        .stat-card i { font-size: 2rem; color: var(--luminous-green); margin-bottom: 10px; }
        .stat-card h3 { font-size: 1.8rem; color: var(--luminous-green-dark); margin-bottom: 5px; }
        .stat-card p { color: var(--text-soft); font-size: 0.8rem; }

        /* Orders Table */
        .orders-table-container {
            overflow-x: auto;
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        .orders-table th {
            text-align: left;
            padding: 15px 10px;
            color: var(--text-soft);
            font-weight: 600;
            border-bottom: 2px solid rgba(111,207,151,0.2);
        }
        .orders-table td {
            padding: 15px 10px;
            border-bottom: 1px solid rgba(111,207,151,0.1);
        }
        .status-badge {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 0.7rem;
            font-weight: 600;
            display: inline-block;
        }
        .status-pending { background: #FFF3E0; color: #E67E22; }
        .status-confirmed { background: #E0F7EA; color: #27AE60; }
        .status-processing { background: #E1F3FE; color: #2C7AA0; }
        .status-completed { background: #E0F7EA; color: #27AE60; }
        .order-type-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        .type-pickup { background: #E1F3FE; color: #2C7AA0; }
        .type-visit { background: #E0F7EA; color: #27AE60; }
        .order-link { color: var(--sky-blue-5); text-decoration: none; font-weight: 500; }

        /* Profile Form */
        .profile-form { max-width: 500px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.85rem; font-weight: 500; margin-bottom: 5px; color: var(--text-dark); }
        .form-control {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid rgba(111,207,151,0.2);
            border-radius: 12px;
            font-size: 0.95rem;
            transition: all 0.3s;
            background: white;
        }
        .form-control:focus { outline: none; border-color: var(--luminous-green); box-shadow: 0 0 0 3px rgba(111,207,151,0.1); }
        .btn-save { background: var(--gradient-green); color: white; border: none; padding: 12px 30px; border-radius: 40px; font-weight: 600; cursor: pointer; margin-top: 10px; }

        /* Content Sections */
        .content-section { display: none; animation: fadeIn 0.3s ease; }
        .content-section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        /* Loading & Empty States */
        .loading-state { text-align: center; padding: 40px; }
        .empty-state { text-align: center; padding: 40px; color: var(--text-soft); }
        .empty-state i { font-size: 3rem; margin-bottom: 15px; opacity: 0.5; }

        @media (max-width: 768px) {
            .account-grid { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: 1fr; }
            .welcome-banner { padding: 20px; }
            .account-container { padding: 100px 20px 40px; }
        }
    </style>
</head>
<body>

<div class="animated-bg"></div>
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>
<div class="orb orb-3"></div>
<div id="bubblesContainer"></div>

<!-- Navigation Bar -->
<nav class="navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <img src="home page images/logo.png" alt="Perfect Laundry Logo" class="logo-img">
            <span class="logo-text">Perfect<span class="logo-highlight">Laundry</span></span>
        </div>
        
        <ul class="nav-menu" id="navMenu">
            <li class="nav-item"><a href="home.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="pricing.html" class="nav-link">Services</a></li>
            <li class="nav-item"><a href="BookOnline.html" class="nav-link">Book Online</a></li>
            <li class="nav-item"><a href="about.html" class="nav-link">About Us</a></li>
            <li class="nav-item"><a href="contact.html" class="nav-link">Contact Us</a></li>
        </ul>
        
        <div class="nav-buttons">
            <div class="user-profile">
                <button class="profile-btn" id="profileBtn">
                    <i class="fas fa-user-circle"></i>
                    <span class="profile-name"><?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?></span>
                    <i class="fas fa-chevron-down"></i>
                </button>
                <div class="profile-dropdown" id="profileDropdown">
                    <div class="dropdown-header">
                        <div class="dropdown-avatar"><i class="fas fa-user-circle"></i></div>
                        <div class="dropdown-info">
                            <strong><?php echo htmlspecialchars($user_name); ?></strong>
                            <span><?php echo htmlspecialchars($user_email); ?></span>
                        </div>
                    </div>
                    <div class="dropdown-divider"></div>
                    <a href="account.php" class="dropdown-item">
                        <i class="fas fa-user-cog"></i>
                        <span>My Account</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#" onclick="logout(); return false;" class="dropdown-item logout-item">
                        <i class="fas fa-sign-out-alt"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
            <div class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </div>
</nav>

<div class="account-container">
    <!-- Welcome Banner -->
    <div class="welcome-banner" data-aos="fade-up">
        <div class="welcome-text">
            <h1>Welcome back, <?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?>! 👋</h1>
            <p>Manage your account, track orders, and enjoy seamless laundry service.</p>
        </div>
        <div class="member-badge">
            <i class="fas fa-star"></i> <?php echo htmlspecialchars($user_role); ?> Member
        </div>
    </div>

    <div class="account-grid">
        <!-- Sidebar -->
        <aside class="account-sidebar" data-aos="fade-right">
            <div class="user-profile-sidebar">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h3><?php echo htmlspecialchars($user_name); ?></h3>
                <p><?php echo htmlspecialchars($user_email); ?></p>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="#" class="active" onclick="showSection('dashboard'); return false;"><i class="fas fa-th-large"></i> Dashboard</a></li>
                <li><a href="#" onclick="showSection('orders'); return false;"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
                <li><a href="#" onclick="showSection('profile'); return false;"><i class="fas fa-user-edit"></i> Profile Settings</a></li>
            </ul>
        </aside>

        <!-- Main Content -->
        <main class="account-content" data-aos="fade-left">
            <!-- Dashboard Section -->
            <div id="dashboard" class="content-section active">
                <div class="content-header">
                    <h2>Dashboard</h2>
                    <a href="BookOnline.html" class="btn-primary">
                        <i class="fas fa-plus"></i> New Order
                    </a>
                </div>

                <div class="stats-grid" id="statsGrid">
                    <div class="stat-card">
                        <i class="fas fa-shopping-bag"></i>
                        <h3 id="totalOrders">0</h3>
                        <p>Total Orders</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-clock"></i>
                        <h3 id="pendingOrders">0</h3>
                        <p>Pending Price</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-check-circle"></i>
                        <h3 id="confirmedOrders">0</h3>
                        <p>Price Confirmed</p>
                    </div>
                </div>

                <h3 style="margin-bottom: 15px;">📋 Recent Orders</h3>
                <div id="recentOrdersContainer" class="orders-table-container">
                    <div class="loading-state"><i class="fas fa-spinner fa-pulse"></i> Loading orders...</div>
                </div>
            </div>

            <!-- Orders Section -->
            <div id="orders" class="content-section">
                <div class="content-header">
                    <h2>All Orders</h2>
                    <div class="filter-tabs" style="display: flex; gap: 10px;">
                        <button class="btn-primary" style="padding: 6px 16px; font-size: 0.8rem;" onclick="filterOrders('all')">All</button>
                        <button class="btn-primary" style="padding: 6px 16px; font-size: 0.8rem; background: #2C7AA0;" onclick="filterOrders('pickup')">Pickup/Delivery</button>
                        <button class="btn-primary" style="padding: 6px 16px; font-size: 0.8rem; background: #27AE60;" onclick="filterOrders('visit')">Visit Laundry</button>
                    </div>
                </div>
                <div id="allOrdersContainer" class="orders-table-container">
                    <div class="loading-state"><i class="fas fa-spinner fa-pulse"></i> Loading orders...</div>
                </div>
            </div>

            <!-- Profile Section -->
            <div id="profile" class="content-section">
                <div class="content-header">
                    <h2>Profile Information</h2>
                </div>
                
                <form class="profile-form" id="profileForm">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" class="form-control" id="fullName" value="<?php echo htmlspecialchars($user_name); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($user_email); ?>" readonly>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" class="form-control" id="phone" value="<?php echo htmlspecialchars($user_phone); ?>">
                    </div>
                    
                    <button type="button" class="btn-save" onclick="updateProfile()">Update Profile</button>
                </form>
            </div>
        </main>
    </div>
</div>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init({ duration: 600, once: true });

    // API Base URL
    const API_BASE = 'http://localhost/PPA%20System/PPA%20System/';
    
    // Get current user from localStorage
    let currentUser = null;
    let allOrders = [];
    let currentOrderFilter = 'all';

    function getCurrentUser() {
        const stored = localStorage.getItem('perfect_laundry_user');
        if (stored) {
            currentUser = JSON.parse(stored);
        }
        return currentUser;
    }

    // Bubble generator
    function createBubbles() {
        const container = document.getElementById('bubblesContainer');
        if(!container) return;
        for(let i=0;i<40;i++) {
            const bubble = document.createElement('div');
            bubble.classList.add('bubble');
            const size = Math.random() * 80 + 20;
            bubble.style.width = size + 'px';
            bubble.style.height = size + 'px';
            bubble.style.left = Math.random() * 100 + '%';
            bubble.style.animationDelay = Math.random() * 15 + 's';
            bubble.style.animationDuration = Math.random() * 12 + 8 + 's';
            bubble.style.background = `rgba(255,255,255,${Math.random() * 0.3 + 0.2})`;
            container.appendChild(bubble);
        }
    }
    createBubbles();

    // Get status class for display
    function getStatusClass(status, orderType) {
        if (orderType === 'visit') {
            switch(status) {
                case 'Pending': return 'status-pending';
                case 'Confirmed': return 'status-confirmed';
                case 'Processing': return 'status-processing';
                case 'Completed': return 'status-completed';
                case 'Cancelled': return 'status-pending';
                default: return 'status-pending';
            }
        } else {
            switch(status) {
                case 'Pending Review': return 'status-pending';
                case 'Price Confirmed': return 'status-confirmed';
                case 'Ready for Delivery': return 'status-processing';
                case 'Delivered': return 'status-completed';
                case 'Cancelled': return 'status-pending';
                default: return 'status-pending';
            }
        }
    }

    // Get display status text
    function getDisplayStatus(status, orderType) {
        if (orderType === 'visit') {
            return status;
        } else {
            if (status === 'Pending Review') return 'Pending';
            if (status === 'Price Confirmed') return 'Confirmed';
            return status;
        }
    }

    // Fetch pickup/delivery orders
    async function fetchPickupOrders() {
        const user = getCurrentUser();
        if (!user) return [];
        
        try {
            const response = await fetch(`${API_BASE}get_orders.php?user_id=${user.id || user.user_id}`);
            const data = await response.json();
            if (data.success) {
                return data.orders.map(order => ({
                    ...order,
                    order_type_display: 'pickup',
                    display_status: getDisplayStatus(order.status, 'pickup'),
                    status_class: getStatusClass(order.status, 'pickup')
                }));
            }
            return [];
        } catch (error) {
            console.error('Error fetching pickup orders:', error);
            return [];
        }
    }

    // Fetch visit laundry orders
    async function fetchVisitOrders() {
        const user = getCurrentUser();
        if (!user) return [];
        
        try {
            const response = await fetch(`${API_BASE}get_visit_laundry.php?user_id=${user.id || user.user_id}`);
            const data = await response.json();
            if (data.success) {
                return data.orders.map(order => ({
                    ...order,
                    order_type_display: 'visit',
                    display_status: getDisplayStatus(order.status, 'visit'),
                    status_class: getStatusClass(order.status, 'visit'),
                    created_at: order.created_at,
                    total_price: order.total_price,
                    total_items: order.total_items
                }));
            }
            return [];
        } catch (error) {
            console.error('Error fetching visit orders:', error);
            return [];
        }
    }

    // Fetch all orders from both tables
    async function fetchAllOrders() {
        try {
            const [pickupOrders, visitOrders] = await Promise.all([
                fetchPickupOrders(),
                fetchVisitOrders()
            ]);
            
            // Combine and sort by date (newest first)
            allOrders = [...pickupOrders, ...visitOrders].sort((a, b) => {
                return new Date(b.created_at) - new Date(a.created_at);
            });
            
            updateStats();
            renderRecentOrders();
            renderAllOrders();
        } catch (error) {
            console.error('Error fetching orders:', error);
        }
    }

    function updateStats() {
        const total = allOrders.length;
        const pending = allOrders.filter(o => {
            if (o.order_type_display === 'visit') {
                return o.status === 'Pending';
            } else {
                return o.status === 'Pending Review';
            }
        }).length;
        const confirmed = allOrders.filter(o => {
            if (o.order_type_display === 'visit') {
                return o.status === 'Confirmed' || o.status === 'Processing';
            } else {
                return o.status === 'Price Confirmed';
            }
        }).length;
        
        document.getElementById('totalOrders').textContent = total;
        document.getElementById('pendingOrders').textContent = pending;
        document.getElementById('confirmedOrders').textContent = confirmed;
    }

    function renderRecentOrders() {
        const container = document.getElementById('recentOrdersContainer');
        const recent = allOrders.slice(0, 5);
        
        if (recent.length === 0) {
            container.innerHTML = `<div class="empty-state"><i class="fas fa-inbox"></i><p>No orders yet. <a href="BookOnline.html">Place your first order</a></p></div>`;
            return;
        }
        
        container.innerHTML = `
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    ${recent.map(order => `
                        <tr>
                            <td><strong>${order.order_id}</strong></td>
                            <td><span class="order-type-badge ${order.order_type_display === 'visit' ? 'type-visit' : 'type-pickup'}">${order.order_type_display === 'visit' ? '🏬 Visit' : '🚚 Pickup/Delivery'}</span></td>
                            <td>${new Date(order.created_at).toLocaleDateString()}</td>
                            <td>${order.total_items || 0} items</td>
                            <td>${order.total_price ? `LKR ${order.total_price}` : '—'}</td>
                            <td><span class="status-badge ${order.status_class}">${order.display_status}</span></td>
                            <td><a href="OrderConfirmation.html?id=${order.order_id}&type=${order.order_type_display}" class="order-link">View <i class="fas fa-arrow-right"></i></a></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    function renderAllOrders() {
        const container = document.getElementById('allOrdersContainer');
        let filtered = allOrders;
        
        if (currentOrderFilter === 'pickup') {
            filtered = allOrders.filter(o => o.order_type_display === 'pickup');
        } else if (currentOrderFilter === 'visit') {
            filtered = allOrders.filter(o => o.order_type_display === 'visit');
        }
        
        if (filtered.length === 0) {
            container.innerHTML = `<div class="empty-state"><i class="fas fa-inbox"></i><p>No orders found</p></div>`;
            return;
        }
        
        container.innerHTML = `
            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Type</th>
                        <th>Date</th>
                        <th>Service</th>
                        <th>Items</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    ${filtered.map(order => `
                        <tr>
                            <td><strong>${order.order_id}</strong></td>
                            <td><span class="order-type-badge ${order.order_type_display === 'visit' ? 'type-visit' : 'type-pickup'}">${order.order_type_display === 'visit' ? '🏬 Visit' : '🚚 Pickup/Delivery'}</span></td>
                            <td>${new Date(order.created_at).toLocaleDateString()}</td>
                            <td>${order.service_speed === 'express' ? '⚡ Express' : '📦 Normal'}</td>
                            <td>${order.total_items || 0}</td>
                            <td>${order.total_price ? `LKR ${order.total_price}` : 'Pending'}</td>
                            <td><span class="status-badge ${order.status_class}">${order.display_status}</span></td>
                            <td><a href="OrderConfirmation.html?id=${order.order_id}&type=${order.order_type_display}" class="order-link">View <i class="fas fa-arrow-right"></i></a></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    function filterOrders(filter) {
        currentOrderFilter = filter;
        renderAllOrders();
    }

    function updateProfile() {
        alert('Profile update feature coming soon!');
    }

    // Section Switching
    function showSection(sectionId) {
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionId).classList.add('active');
        
        document.querySelectorAll('.sidebar-menu a').forEach(link => {
            link.classList.remove('active');
        });
        event.currentTarget.classList.add('active');
    }

    // Profile Dropdown
    const profileBtn = document.getElementById('profileBtn');
    const profileDropdown = document.getElementById('profileDropdown');
    
    if (profileBtn) {
        profileBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            profileDropdown.classList.toggle('show');
        });
        
        document.addEventListener('click', (e) => {
            if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.classList.remove('show');
            }
        });
    }

    // Logout function
    async function logout() {
        localStorage.removeItem('perfect_laundry_user');
        localStorage.removeItem('perfect_laundry_session_token');
        window.location.href = 'home.php';
    }

    // Mobile Menu
    function initMobileMenu() {
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('navMenu');
        if(hamburger) {
            hamburger.addEventListener('click', () => {
                navMenu.classList.toggle('active');
            });
        }
    }

    // Check login
    function checkLogin() {
        const user = getCurrentUser();
        if (!user) {
            window.location.href = 'login.html';
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        initMobileMenu();
        checkLogin();
        fetchAllOrders();
    });
</script>
</body>
</html>