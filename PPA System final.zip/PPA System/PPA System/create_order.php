<?php
// create_order.php - Insert new order
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Get customer info
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$customer_name = mysqli_real_escape_string($conn, $data['customer_name'] ?? '');
$phone = mysqli_real_escape_string($conn, $data['phone'] ?? '');
$email = mysqli_real_escape_string($conn, $data['email'] ?? '');
$address = mysqli_real_escape_string($conn, $data['address'] ?? '');
$service_speed = mysqli_real_escape_string($conn, $data['service_speed'] ?? 'normal');
$delivery_option = mysqli_real_escape_string($conn, $data['delivery_option'] ?? 'pickup_only');
$order_type = mysqli_real_escape_string($conn, $data['order_type'] ?? 'pickup');
$total_items = intval($data['total_items'] ?? 0);
$delivery_distance = floatval($data['delivery_distance'] ?? 0);
$notes = mysqli_real_escape_string($conn, $data['notes'] ?? '');
$services_data = mysqli_real_escape_string($conn, json_encode($data['services_data'] ?? []));

// Validation
if (empty($customer_name) || empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Customer name and phone required']);
    exit();
}

// Function to calculate delivery charge
function calculateDeliveryCharge($distance, $deliveryOption) {
    $MIN_FARE = 150;
    $RATE_PER_KM = 85;
    
    if (!$distance || $distance <= 0) return 0;
    
    $charge = 0;
    if ($distance <= 1) {
        $charge = $MIN_FARE;
    } else {
        $charge = $MIN_FARE + (($distance - 1) * $RATE_PER_KM);
    }
    
    if ($deliveryOption === 'both') {
        $charge = $charge * 2;
    }
    
    return round($charge);
}

// Function to generate order ID
function generateOrderId($conn) {
    $result = mysqli_query($conn, "SELECT MAX(CAST(SUBSTRING(order_id, 3) AS UNSIGNED)) as last_num FROM orders");
    $row = mysqli_fetch_assoc($result);
    $lastNum = $row['last_num'] ? $row['last_num'] : 0;
    return 'PL' . str_pad($lastNum + 1, 6, '0', STR_PAD_LEFT);
}

try {
    // Calculate delivery charge
    $delivery_charge = 0;
    if ($delivery_option !== 'visit') {
        $delivery_charge = calculateDeliveryCharge($delivery_distance, $delivery_option);
    }
    
    // Generate order ID
    $order_id = generateOrderId($conn);
    
    // Insert order
    $sql = "INSERT INTO orders (
        order_id, user_id, customer_name, phone, email, address, 
        service_speed, delivery_option, order_type, total_items, 
        delivery_distance, delivery_charge, notes, services_data
    ) VALUES (
        '$order_id', '$user_id', '$customer_name', '$phone', '$email', '$address',
        '$service_speed', '$delivery_option', '$order_type', '$total_items',
        '$delivery_distance', '$delivery_charge', '$notes', '$services_data'
    )";
    
    if (mysqli_query($conn, $sql)) {
        // Insert order items if exists
        if (!empty($data['services_data'])) {
            $item_sql = "INSERT INTO order_items (order_id, service_type, item_name, quantity) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $item_sql);
            
            foreach ($data['services_data'] as $service) {
                $service_name = $service['service'] ?? '';
                if (!empty($service['items'])) {
                    foreach ($service['items'] as $item) {
                        $item_name = $item['name'] ?? '';
                        $quantity = intval($item['quantity'] ?? 1);
                        if (!empty($item_name)) {
                            mysqli_stmt_bind_param($stmt, 'sssi', $order_id, $service_name, $item_name, $quantity);
                            mysqli_stmt_execute($stmt);
                        }
                    }
                }
            }
            mysqli_stmt_close($stmt);
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Order placed successfully',
            'order_id' => $order_id,
            'delivery_charge' => $delivery_charge
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to place order: ' . mysqli_error($conn)]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Failed to place order: ' . $e->getMessage()]);
}

mysqli_close($conn);
?>