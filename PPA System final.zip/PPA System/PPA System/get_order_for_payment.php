<?php
// get_order_for_payment.php - Simplified for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "perfect_laundry";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : '';

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'No order ID provided']);
    exit();
}

// Get order details
$sql = "SELECT * FROM orders WHERE order_id = '$order_id'";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['success' => false, 'error' => 'Query failed: ' . $conn->error]);
    exit();
}

$order = $result->fetch_assoc();

if (!$order) {
    echo json_encode(['success' => false, 'error' => "Order $order_id not found"]);
    exit();
}

// Get order items
$items = [];
$items_sql = "SELECT service_type, item_name, quantity FROM order_items WHERE order_id = '$order_id'";
$items_result = $conn->query($items_sql);
if ($items_result) {
    while ($item = $items_result->fetch_assoc()) {
        $items[] = $item;
    }
}
$order['items'] = $items;

// Convert to proper numbers
$order['total_price'] = floatval($order['total_price']);
$order['package_price'] = floatval($order['package_price']);
$order['delivery_charge'] = floatval($order['delivery_charge']);

echo json_encode(['success' => true, 'order' => $order]);

$conn->close();
?>