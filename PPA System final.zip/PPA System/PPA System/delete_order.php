<?php
// delete_order.php - Delete order (Admin only)
session_start();
require_once 'db.php';

// Check if user is admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE' && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$order_id = mysqli_real_escape_string($conn, $data['order_id'] ?? ($_GET['order_id'] ?? ''));

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'Order ID required']);
    exit();
}

try {
    // Check if order exists
    $check_sql = "SELECT order_id FROM orders WHERE order_id = '$order_id'";
    $result = mysqli_query($conn, $check_sql);
    if (!mysqli_num_rows($result)) {
        echo json_encode(['success' => false, 'error' => 'Order not found']);
        exit();
    }
    
    // Delete order (cascade will delete related items and logs if foreign keys exist)
    $sql = "DELETE FROM orders WHERE order_id = '$order_id'";
    
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['success' => true, 'message' => 'Order deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>