<?php
// process_payment.php - Process payment and update order
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

$data = json_decode(file_get_contents('php://input'), true);

$order_id = mysqli_real_escape_string($conn, $data['order_id'] ?? '');
$payment_method = mysqli_real_escape_string($conn, $data['payment_method'] ?? 'card');

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'Order ID required']);
    exit();
}

// Check if payment_status column exists
$check_column = "SHOW COLUMNS FROM orders LIKE 'payment_status'";
$column_result = mysqli_query($conn, $check_column);
if (mysqli_num_rows($column_result) == 0) {
    mysqli_query($conn, "ALTER TABLE orders ADD COLUMN payment_status ENUM('pending', 'awaiting_payment', 'paid', 'failed') DEFAULT 'pending'");
}

// Check if payment_method column exists
$check_method = "SHOW COLUMNS FROM orders LIKE 'payment_method'";
$method_result = mysqli_query($conn, $check_method);
if (mysqli_num_rows($method_result) == 0) {
    mysqli_query($conn, "ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT NULL");
}

// Verify order exists
$check_sql = "SELECT order_id, total_price, payment_status, customer_name, email, phone FROM orders WHERE order_id = '$order_id'";
$check_result = mysqli_query($conn, $check_sql);
$order = mysqli_fetch_assoc($check_result);

if (!$order) {
    echo json_encode(['success' => false, 'error' => 'Order not found']);
    exit();
}

if ($order['payment_status'] === 'paid') {
    echo json_encode(['success' => false, 'error' => 'Order already paid']);
    exit();
}

// For COD, payment_status remains 'pending' until delivery
// For Card, payment_status becomes 'paid' immediately
if ($payment_method === 'cod') {
    $new_payment_status = 'pending';
} else {
    $new_payment_status = 'paid';
}

// Update payment status
$update_sql = "UPDATE orders SET payment_status = '$new_payment_status', payment_method = '$payment_method' WHERE order_id = '$order_id'";

if (mysqli_query($conn, $update_sql)) {
    // Log payment
    $log_sql = "INSERT INTO delivery_logs (order_id, old_status, new_status, updated_by, notes, created_at) 
                VALUES ('$order_id', '{$order['payment_status']}', '$new_payment_status', 'customer', 'Payment method: $payment_method', NOW())";
    mysqli_query($conn, $log_sql);
    
    echo json_encode([
        'success' => true, 
        'message' => $payment_method === 'cod' ? 'COD order confirmed!' : 'Payment successful!',
        'order_id' => $order_id,
        'payment_method' => $payment_method
    ]);
} else {
    echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
}

mysqli_close($conn);
?>