<?php
// update_order.php - Update order status, price, weight
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

// For testing - temporarily disable admin check
// Comment this back in after testing
/*
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$order_id = mysqli_real_escape_string($conn, $data['order_id'] ?? '');

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'Order ID required']);
    exit();
}

try {
    // Get current order details for logging
    $sql = "SELECT status FROM orders WHERE order_id = '$order_id'";
    $result = mysqli_query($conn, $sql);
    $old_order = mysqli_fetch_assoc($result);
    $old_status = $old_order ? $old_order['status'] : null;
    
    // Build update query
    $update_fields = [];
    
    if (isset($data['weight'])) {
        $weight = floatval($data['weight']);
        $update_fields[] = "weight = '$weight'";
    }
    if (isset($data['package_price'])) {
        $package_price = floatval($data['package_price']);
        $update_fields[] = "package_price = '$package_price'";
    }
    if (isset($data['delivery_charge'])) {
        $delivery_charge = floatval($data['delivery_charge']);
        $update_fields[] = "delivery_charge = '$delivery_charge'";
    }
    if (isset($data['total_price'])) {
        $total_price = floatval($data['total_price']);
        $update_fields[] = "total_price = '$total_price'";
        $update_fields[] = "price_confirmed = 1";
    }
    if (isset($data['status'])) {
        $status = mysqli_real_escape_string($conn, $data['status']);
        $update_fields[] = "status = '$status'";
    }
    if (isset($data['expected_return_date'])) {
        $expected_date = mysqli_real_escape_string($conn, $data['expected_return_date']);
        $update_fields[] = "expected_return_date = " . ($expected_date ? "'$expected_date'" : "NULL");
    }
    if (isset($data['actual_return_date'])) {
        $actual_date = mysqli_real_escape_string($conn, $data['actual_return_date']);
        $update_fields[] = "actual_return_date = " . ($actual_date ? "'$actual_date'" : "NULL");
    }
    
    if (empty($update_fields)) {
        echo json_encode(['success' => false, 'error' => 'No fields to update']);
        exit();
    }
    
    $sql = "UPDATE orders SET " . implode(', ', $update_fields) . " WHERE order_id = '$order_id'";
    
    if (mysqli_query($conn, $sql)) {
        // Log status change if status changed
        if ($old_status && isset($data['status']) && $data['status'] != $old_status) {
            $log_sql = "INSERT INTO delivery_logs (order_id, old_status, new_status, updated_by, created_at) 
                        VALUES ('$order_id', '$old_status', '{$data['status']}', 'admin', NOW())";
            mysqli_query($conn, $log_sql);
        }
        
        echo json_encode(['success' => true, 'message' => 'Order updated successfully']);
    } else {
        echo json_encode(['success' => false, 'error' => mysqli_error($conn)]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>