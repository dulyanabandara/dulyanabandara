<?php
// generate_visit_report.php - Generate report data for visit laundry
session_start();
require_once 'visit_db.php';

header('Content-Type: application/json');

// Check if user is admin
$is_admin = false;
if (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin') {
    $is_admin = true;
}

if (!$is_admin) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}

$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
$report_type = isset($_GET['report_type']) ? mysqli_real_escape_string($conn, $_GET['report_type']) : 'orders';

try {
    $where_conditions = [];
    
    if ($date_from && $date_to) {
        $where_conditions[] = "DATE(created_at) BETWEEN '$date_from' AND '$date_to'";
    } elseif ($date_from) {
        $where_conditions[] = "DATE(created_at) >= '$date_from'";
    } elseif ($date_to) {
        $where_conditions[] = "DATE(created_at) <= '$date_to'";
    }
    
    if ($status !== 'all') {
        $where_conditions[] = "status = '$status'";
    }
    
    $where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
    
    // Fetch orders
    $sql = "SELECT * FROM visit_laundry_orders $where_clause ORDER BY created_at DESC";
    $result = mysqli_query($conn, $sql);
    
    $orders = [];
    $total_revenue = 0;
    $completed_orders = 0;
    $cancelled_orders = 0;
    $status_counts = [
        'Pending' => 0,
        'Confirmed' => 0,
        'Processing' => 0,
        'Ready' => 0,
        'Completed' => 0,
        'Cancelled' => 0
    ];
    
    while ($row = mysqli_fetch_assoc($result)) {
        // Decode services data
        if ($row['services_data']) {
            $row['items'] = json_decode($row['services_data'], true);
        }
        
        $orders[] = $row;
        
        // Calculate revenue
        if ($row['total_price'] && $row['total_price'] > 0) {
            $total_revenue += floatval($row['total_price']);
        }
        
        // Count by status
        if (isset($status_counts[$row['status']])) {
            $status_counts[$row['status']]++;
        }
        
        if ($row['status'] === 'Completed') {
            $completed_orders++;
        } elseif ($row['status'] === 'Cancelled') {
            $cancelled_orders++;
        }
    }
    
    $avg_order_value = count($orders) > 0 ? round($total_revenue / count($orders), 2) : 0;
    
    $response = [
        'success' => true,
        'data' => $orders,
        'summary' => [
            'total_orders' => count($orders),
            'total_revenue' => number_format($total_revenue, 2),
            'avg_order_value' => number_format($avg_order_value, 2),
            'completed_orders' => $completed_orders,
            'cancelled_orders' => $cancelled_orders,
            'status_counts' => $status_counts
        ]
    ];
    
    echo json_encode($response);
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>