<?php
session_start();
require_once 'config_customers.php';

header('Content-Type: application/json');

// Get filter and search parameters
$filter = isset($_GET['filter']) ? mysqli_real_escape_string($conn, $_GET['filter']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Build query conditions
$where_conditions = ["(role='Customer' OR role='customer' OR role IS NULL)"];

if (!empty($search)) {
    $where_conditions[] = "(full_name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%')";
}

if (!empty($filter) && $filter != 'All') {
    $status_exists = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0;
    if ($status_exists) {
        $where_conditions[] = "status = '$filter'";
    }
}

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get customers
$query = "SELECT id, full_name, email FROM users $where_clause ORDER BY full_name ASC";
$result = mysqli_query($conn, $query);

$customers = [];
while ($row = mysqli_fetch_assoc($result)) {
    $customers[] = [
        'id' => $row['id'],
        'name' => $row['full_name'],
        'email' => $row['email']
    ];
}

echo json_encode([
    'success' => true,
    'customers' => $customers,
    'count' => count($customers)
]);
?>