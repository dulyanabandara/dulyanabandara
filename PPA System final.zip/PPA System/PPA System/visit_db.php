<?php
// visit_db.php - Database connection for Visit Laundry system
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "perfect_laundry";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]));
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");

// Function to generate order ID - CHECKS BOTH TABLES (SAME LOGIC AS config.php)
function generateVisitOrderId($conn) {
    // Get the max order ID from BOTH tables (orders and visit_laundry_orders)
    $sql = "SELECT MAX(CAST(SUBSTRING(order_id, 3) AS UNSIGNED)) as last_num FROM (
                SELECT order_id FROM orders 
                UNION ALL 
                SELECT order_id FROM visit_laundry_orders
            ) as combined_orders";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $lastNum = $row['last_num'] ? $row['last_num'] : 0;
    return 'PL' . str_pad($lastNum + 1, 6, '0', STR_PAD_LEFT);
}
?>