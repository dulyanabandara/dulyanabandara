<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Check for fixed admin credentials
    if (($email === 'PLAdmin' || $email === 'admin@perfectlaundry.com') && $password === 'PLAdmin@123') {
        $userData = [
            'user_id' => 'ADMIN000001',
            'id' => 'ADMIN',
            'full_name' => 'Administrator',
            'email' => $email,
            'phone' => '0771234567',
            'role' => 'Admin'
        ];
        $session_token = bin2hex(random_bytes(32));
        
        $_SESSION['user_id'] = 'ADMIN';
        $_SESSION['user_name'] = 'Administrator';
        $_SESSION['role'] = 'Admin';
        $_SESSION['logged_in'] = true;
        
        echo "<!DOCTYPE html>
        <html>
        <head>
            <script>
                localStorage.setItem('perfect_laundry_user', '" . json_encode($userData) . "');
                localStorage.setItem('perfect_laundry_session_token', '" . $session_token . "');
                window.location.href = 'admin-dashboard.html';
            </script>
        </head>
        <body>
            <p>Redirecting to admin dashboard...</p>
        </body>
        </html>";
        exit();
    }

    // Regular user login
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        if (password_verify($password, $row['password'])) {
            // Generate user_id format for consistency
            $user_id = 'USR' . str_pad($row['id'], 6, '0', STR_PAD_LEFT);
            
            $userData = [
                'user_id' => $user_id,
                'id' => $row['id'],
                'full_name' => $row['full_name'],
                'email' => $row['email'],
                'phone' => $row['phone'],
                'role' => $row['role']
            ];
            $session_token = bin2hex(random_bytes(32));
            
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['full_name'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['logged_in'] = true;
            
            $redirectPage = ($row['role'] == 'Admin') ? 'admin-dashboard.html' : 'home.php';
            
            echo "<!DOCTYPE html>
            <html>
            <head>
                <script>
                    localStorage.setItem('perfect_laundry_user', '" . json_encode($userData) . "');
                    localStorage.setItem('perfect_laundry_session_token', '" . $session_token . "');
                    window.location.href = '" . $redirectPage . "';
                </script>
            </head>
            <body>
                <p>Login successful! Redirecting...</p>
            </body>
            </html>";
            exit();
        } else {
            echo "<script>alert('Invalid Password!'); window.location.href='login.html';</script>";
        }
    } else {
        echo "<script>alert('No account found with that email!'); window.location.href='login.html';</script>";
    }
}

mysqli_close($conn);
?>