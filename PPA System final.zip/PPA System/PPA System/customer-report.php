<?php
session_start();
require_once 'config_customers.php';

// Get filter and search parameters
$filter = isset($_GET['filter']) ? mysqli_real_escape_string($conn, $_GET['filter']) : '';
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// Build query conditions
$where_conditions = ["(role='Customer' OR role='customer' OR role IS NULL)"];

if (!empty($search)) {
    $where_conditions[] = "(full_name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%')";
}

if (!empty($filter) && $filter != 'All') {
    $status_exists = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0;
    if ($status_exists) {
        $where_conditions[] = "status = '$filter'";
    }
}

$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get statistics
$total_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users $where_clause"))['count'];

// Count active customers
$active_customers_query = "SELECT COUNT(*) as count FROM users $where_clause";
if (mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0) {
    $active_customers_query .= " AND status='Active'";
} else {
    $active_customers_query .= " AND 1=1";
}
$active_customers = mysqli_fetch_assoc(mysqli_query($conn, $active_customers_query))['count'];

// Count VIP customers
$vip_customers_query = "SELECT COUNT(*) as count FROM users $where_clause";
if (mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0) {
    $vip_customers_query .= " AND status='VIP'";
} else {
    $vip_customers_query .= " AND 1=0";
}
$vip_customers = mysqli_fetch_assoc(mysqli_query($conn, $vip_customers_query))['count'];

// Count inactive customers
$inactive_customers = $total_customers - $active_customers - $vip_customers;

// Count new this month
$new_this_month = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users $where_clause AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())"))['count'];

// Get customers data
$query = "SELECT * FROM users $where_clause ORDER BY id DESC";
$customers_result = mysqli_query($conn, $query);

// Get report generation date and time
$report_date = date('F d, Y');
$report_time = date('h:i A');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Report - Perfect Laundry</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f5f5;
            padding: 40px;
            color: #333;
        }

        .report-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        /* Report Header */
        .report-header {
            background: linear-gradient(135deg, #2C7AA0, #1E5A7A);
            color: white;
            padding: 30px 40px;
            text-align: center;
        }

        .report-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .report-header p {
            opacity: 0.8;
            font-size: 0.9rem;
        }

        .report-header .date {
            margin-top: 15px;
            font-size: 0.85rem;
            border-top: 1px solid rgba(255,255,255,0.3);
            padding-top: 15px;
            display: inline-block;
        }

        /* Report Content */
        .report-content {
            padding: 30px 40px;
        }

        /* Summary Section */
        .summary-section {
            margin-bottom: 30px;
        }

        .summary-section h2 {
            font-size: 1.3rem;
            color: #2C7AA0;
            border-left: 4px solid #6FCF97;
            padding-left: 15px;
            margin-bottom: 20px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            border: 1px solid #e0e0e0;
        }

        .stat-card i {
            font-size: 2rem;
            color: #6FCF97;
            margin-bottom: 10px;
        }

        .stat-card .number {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2C7AA0;
        }

        .stat-card .label {
            font-size: 0.85rem;
            color: #666;
            margin-top: 5px;
        }

        /* Filter Info */
        .filter-info {
            background: #f0f7fc;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            color: #555;
        }

        .filter-info i {
            margin-right: 8px;
            color: #6FCF97;
        }

        /* Customers Table */
        .customers-table {
            width: 100%;
            border-collapse: collapse;
        }

        .customers-table th {
            background: #f0f7fc;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: #2C7AA0;
            border-bottom: 2px solid #ddd;
        }

        .customers-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            color: #555;
        }

        .customers-table tr:hover td {
            background: #f9f9f9;
        }

        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
            display: inline-block;
        }

        .status-active {
            background: #E3F7E7;
            color: #27AE60;
        }

        .status-vip {
            background: #FFF3E0;
            color: #F59E0B;
        }

        .status-inactive {
            background: #FFE8E8;
            color: #EF4444;
        }

        /* Report Footer */
        .report-footer {
            background: #f8f9fa;
            padding: 20px 40px;
            text-align: center;
            font-size: 0.8rem;
            color: #888;
            border-top: 1px solid #e0e0e0;
        }

        /* Print Button */
        .print-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: linear-gradient(135deg, #2C7AA0, #1E5A7A);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 50px;
            cursor: pointer;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        }

        /* Print Styles */
        @media print {
            body {
                background: white;
                padding: 0;
            }
            .print-btn {
                display: none;
            }
            .report-container {
                box-shadow: none;
                border-radius: 0;
            }
            .report-header {
                background: #2C7AA0;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .stat-card {
                background: #f8f9fa;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            body {
                padding: 20px;
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .report-header, .report-content {
                padding: 20px;
            }
            .customers-table {
                font-size: 0.8rem;
            }
            .customers-table th, .customers-table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Report Header -->
        <div class="report-header">
            <h1>📊 Customer Summary Report</h1>
            <p>Perfect Laundry Management System</p>
            <div class="date">
                Generated on: <?php echo $report_date; ?> at <?php echo $report_time; ?>
            </div>
        </div>

        <!-- Report Content -->
        <div class="report-content">
            <!-- Summary Section -->
            <div class="summary-section">
                <h2><i class="fas fa-chart-line"></i> Summary Statistics</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <i class="fas fa-users"></i>
                        <div class="number"><?php echo number_format($total_customers); ?></div>
                        <div class="label">Total Customers</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-user-check"></i>
                        <div class="number"><?php echo number_format($active_customers); ?></div>
                        <div class="label">Active</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-user-slash"></i>
                        <div class="number"><?php echo number_format($inactive_customers); ?></div>
                        <div class="label">Inactive</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-crown"></i>
                        <div class="number"><?php echo number_format($vip_customers); ?></div>
                        <div class="label">VIP Customers</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-calendar-plus"></i>
                        <div class="number"><?php echo number_format($new_this_month); ?></div>
                        <div class="label">New This Month</div>
                    </div>
                </div>
            </div>

            <!-- Filter Information -->
            <?php if (!empty($search) || (!empty($filter) && $filter != 'All')): ?>
            <div class="filter-info">
                <i class="fas fa-filter"></i>
                <strong>Applied Filters:</strong>
                <?php if (!empty($search)): ?>
                    <span>Search: "<?php echo htmlspecialchars($search); ?>"</span>
                <?php endif; ?>
                <?php if (!empty($filter) && $filter != 'All'): ?>
                    <?php if (!empty($search)): echo " | "; endif; ?>
                    <span>Status: <?php echo $filter; ?></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Customers Table -->
            <div class="summary-section">
                <h2><i class="fas fa-list"></i> Customer List</h2>
                
                <?php if (mysqli_num_rows($customers_result) > 0): ?>
                <table class="customers-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Customer Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Joined Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sl = 1;
                        while ($row = mysqli_fetch_assoc($customers_result)): 
                            $status = isset($row['status']) ? $row['status'] : 'Active';
                            $status_class = '';
                            if ($status == 'Active') $status_class = 'status-active';
                            elseif ($status == 'VIP') $status_class = 'status-vip';
                            else $status_class = 'status-inactive';
                        ?>
                        <tr>
                            <td><?php echo $sl++; ?> </td>
                            <td><?php echo htmlspecialchars($row['full_name']); ?> </td>
                            <td><?php echo htmlspecialchars($row['email']); ?> </td>
                            <td><?php echo htmlspecialchars($row['phone']); ?> </td>
                            <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status; ?></span></td>
                            <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?> </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: #888;">
                        <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 10px;"></i>
                        <p>No customers found matching the criteria</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Report Footer -->
        <div class="report-footer">
            <p>This report is generated automatically by Perfect Laundry Management System</p>
            <p>© <?php echo date('Y'); ?> Perfect Laundry. All rights reserved.</p>
        </div>
    </div>

    <!-- Print Button -->
    <button class="print-btn" onclick="window.print()">
        <i class="fas fa-print"></i> Print / Save as PDF
    </button>

    <script>
        // Optional: Auto print (uncomment if needed)
        // window.onload = function() {
        //     setTimeout(() => window.print(), 500);
        // }
    </script>
</body>
</html>