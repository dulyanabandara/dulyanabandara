<?php
// config.php - Database configuration
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection using your existing code
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Perfect_laundry";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed: ' . $conn->connect_error]);
    exit();
}

// Set charset
$conn->set_charset("utf8mb4");

// Function to generate order ID - NOW CHECKS BOTH TABLES
function generateOrderId($conn) {
    // Get the max order ID from BOTH tables (orders and visit_laundry_orders)
    $sql = "SELECT MAX(CAST(SUBSTRING(order_id, 3) AS UNSIGNED)) as last_num FROM (
                SELECT order_id FROM orders 
                UNION ALL 
                SELECT order_id FROM visit_laundry_orders
            ) as combined_orders";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $lastNum = $row['last_num'] ? $row['last_num'] : 0;
    return 'PL' . str_pad($lastNum + 1, 6, '0', STR_PAD_LEFT);
}

// Function to calculate delivery charge
function calculateDeliveryCharge($distance, $deliveryOption) {
    $MIN_FARE = 150;
    $RATE_PER_KM = 85;
    
    if (!$distance || $distance <= 0) return 0;
    
    $charge = 0;
    if ($distance <= 1) {
        $charge = $MIN_FARE;
    } else {
        $charge = $MIN_FARE + (($distance - 1) * $RATE_PER_KM);
    }
    
    if ($deliveryOption === 'both') {
        $charge = $charge * 2;
    }
    
    return round($charge);
}

// Function to verify admin credentials
function isAdmin($username, $password) {
    // Fixed admin credentials
    if ($username === 'PLAdmin' && $password === 'PLAdmin@123') {
        return true;
    }
    return false;
}
?>