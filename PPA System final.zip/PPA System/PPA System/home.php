<?php
// 1. Start the session
session_start();

// 2. Check if user is logged in via session OR localStorage (for JavaScript)
$isLoggedIn = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;

// 3. Get the user's name from the session
$userName = $_SESSION['user_name'] ?? 'Account';

// 4. If session says not logged in but we have localStorage, let JavaScript handle it
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfect Laundry - Freshness Delivered to Your Doorstep</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="dull.css">
    <style>
        /* Add logout button style if not in dull.css */
        .logout-btn {
            background: rgba(231, 76, 60, 0.2);
            border: 1px solid #e74c3c;
            color: #e74c3c;
            padding: 8px 16px;
            border-radius: 30px;
            margin-left: 10px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #e74c3c;
            color: white;
        }
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        .user-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 45px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
            min-width: 180px;
            z-index: 100;
            overflow: hidden;
        }
        .user-menu a {
            display: block;
            padding: 12px 20px;
            color: #1A2F3F;
            text-decoration: none;
            transition: background 0.3s;
        }
        .user-menu a:hover {
            background: #f0f7fc;
        }
        .user-menu a i {
            margin-right: 10px;
            width: 20px;
        }
        .user-dropdown:hover .user-menu {
            display: block;
        }
    </style>
</head>
<body>
    <div id="particles-js"></div>
    
    <div class="container">
        <nav class="navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <img src="home page images/logo.png" alt="Perfect Laundry Logo" class="logo-img">
            <span class="logo-text">Perfect<span class="logo-highlight">Laundry</span></span>
        </div>
        
        <ul class="nav-menu" id="navMenu">
            <li class="nav-item"><a href="#home" class="nav-link active">Home</a></li>
            <li class="nav-item"><a href="pricing.php" class="nav-link">Services</a></li>
            <li class="nav-item"><a href="BookOnline.html" class="nav-link">Book Online</a></li>
            <li class="nav-item"><a href="about.html" class="nav-link">About Us</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contact Us</a></li>
        </ul>
        
        <div class="nav-buttons">
            <?php if ($isLoggedIn): ?>
                <div class="user-profile">
                    <button class="profile-btn" id="profileBtn">
                        <i class="fas fa-user-circle"></i>
                        <span class="profile-name"><?php echo htmlspecialchars(explode(' ', $userName)[0]); ?></span>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="profile-dropdown" id="profileDropdown">
                        <div class="dropdown-header">
                            <div class="dropdown-avatar">
                                <i class="fas fa-user-circle"></i>
                            </div>
                            <div class="dropdown-info">
                                <strong><?php echo htmlspecialchars($userName); ?></strong>
                                <span><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></span>
                            </div>
                        </div>
                        <a href="account.php" class="dropdown-item">
                            <i class="fas fa-user-edit"></i>
                            <span>My Account</span>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a href="#" onclick="logout(); return false;" class="dropdown-item logout-item">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <a href="login.html" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Log In
                </a>
                <a href="signup.html" class="btn-signup">
                    <i class="fas fa-user-plus"></i> Sign Up
                </a>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
        </div>
    </div>
</nav>

        <section id="home" class="hero-section">
            <div class="hero-content" data-aos="fade-right" data-aos-duration="1000">
                <h1 class="hero-title">
                    <span class="title-line">Freshness That</span>
                    <span class="title-line gradient-text">Lasts Longer</span>
                </h1>
                <p class="hero-description">
                    Experience the perfect blend of care and technology. We treat your clothes with love, 
                    delivering them back to you fresh, folded, and ready to wear.
                </p>
                <div class="hero-stats">
                    <div class="stat-item">
                        <span class="stat-number" id="happyClients">0</span>
                        <span class="stat-label">Happy Clients</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="clothesCleaned">0</span>
                        <span class="stat-label">Pcs Cleaned</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number" id="deliveryOnTime">0</span>
                        <span class="stat-label">On Time</span>
                    </div>
                </div>
                <div class="hero-buttons">
                    <a href="BookOnline.html" class="btn-primary">
                        <i class="fas fa-calendar-check"></i> Book Now
                        <span class="btn-glow"></span>
                    </a>
                    <a href="#services" class="btn-secondary">
                        <i class="fas fa-arrow-down"></i> Explore Services
                    </a>
                </div>
            </div>
            <div class="hero-image" data-aos="fade-left" data-aos-duration="1000">
                <div class="floating-card card-1">
                    <i class="fas fa-tshirt"></i>
                    <span>Premium Wash</span>
                </div>
                <div class="floating-card card-2">
                    <i class="fas fa-wind"></i>
                    <span>Dry & clean</span>
                </div>
                <div class="floating-card card-3">
                    <i class="fas fa-truck"></i>
                    <span>Pickup</span>
                </div>
                <div class="hero-image-wrapper">
                    <img src="home page images/logo.png" alt="Laundry Service" class="main-hero-image">
                    <div class="image-overlay"></div>
                </div>
            </div>
        </section>

        <section id="services" class="services-section">
            <div class="section-header" data-aos="zoom-in">
                <span class="section-subtitle">WHAT WE OFFER</span>
                <h2 class="section-title">Our <span class="gradient-text">Services</span></h2>
                <p class="section-description">view detailed information and pricing</p>
            </div>

            <div class="services-grid-home">
                <div class="services-row">
                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/killo wash.jpeg" alt="Kilo Wash">
                        </div>
                        <h3>Kilo Wash</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left">
                        <div class="service-image-wrapper">
                            <img src="home page images/press.jpeg" alt="Press">
                        </div>
                        <h3>Press</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left">
                        <div class="service-image-wrapper">
                            <img src="home page images/Dry clean.jpeg" alt="Dry Clean">
                        </div>
                        <h3>Dry Clean</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/bed.jpeg" alt="Bed Linen">
                        </div>
                        <h3>Bed Linen</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/shoes.jpeg" alt="Shoe Cleaning">
                        </div>
                        <h3>Shoe Cleaning</h3>
                    </div>
                </div>

                <div class="services-row">
                    <div class="service-image-card" data-aos="flip-left">
                        <div class="service-image-wrapper">
                            <img src="home page images/carpet.jpeg" alt="Carpets and Rugs">
                        </div>
                        <h3>Carpets & Rugs</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/stain.jpeg" alt="Stain Removal">
                        </div>
                        <h3>Stain Removal</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/Curtains.jpeg" alt="Curtain Cleaning">
                        </div>
                        <h3>Curtain Cleaning</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/covers.jpeg" alt="Car Seat Covers">
                        </div>
                        <h3>Car Seat Covers</h3>
                    </div>

                    <div class="service-image-card" data-aos="flip-left" >
                        <div class="service-image-wrapper">
                            <img src="home page images/bags.jpeg" alt="Bags">
                        </div>
                        <h3>Bags</h3>
                    </div>
                </div>
            </div>

            <div class="services-cta" data-aos="zoom-in-up">
                <a href="pricing.html" class="btn-primary btn-large">
                    <i class="fas fa-tags"></i> View All Services & Pricing
                    <span class="btn-glow"></span>
                </a>
            </div>
        </section>

 <!-- ========== DELIVERY SECTION ========== -->
        <section id="delivery" class="delivery-section">
            <div class="delivery-container">
                <!-- left side -->
                <div class="delivery-content" data-aos="fade-right">
                    <span class="delivery-badge"><i class="fas fa-bolt"></i> PICKUP / DELIVERY · SOUTHERN PROVINCE</span>
                    <h2 class="delivery-title">On‑demand <span class="gradient-text">Express</span> or normal</h2>

                    <!-- feature cards : normal / express / coverage -->
<!-- feature cards : normal / express / coverage -->
<div class="delivery-features">

    <!-- 24 Hour Service -->
    <div class="feature-card">
        <div class="feature-icon"><i class="fas fa-truck"></i></div>
        <h4>24-Hour Service</h4>
        <p>
            Service charge: <strong>1kg = 1000 LKR</strong><br>
            + Delivery charges (based on location distance).<br><br>
            Pickup and delivery arranged within 24 hours according to your washing schedule.
        </p>
    </div>

    <!-- Express Service -->
    <div class="feature-card">
        <div class="feature-icon"><i class="fas fa-rocket"></i></div>
        <h4>
            Express 6-7 Hours 
            <span class="express-tag">
                <i class="fas fa-stopwatch"></i> +200 LKR/kg
            </span>
        </h4>
        <p>
            Service charge: <strong>1kg = 1000 LKR</strong><br>
            + Delivery charges (based on location distance)<br>
            + <strong>Additional 200 LKR per kg</strong> express surcharge.<br><br>
            Guaranteed pickup-to-delivery within 6-7 hours (subject to route).
        </p>
    </div>

    <!-- Coverage -->
    <div class="feature-card">
        <div class="feature-icon"><i class="fas fa-map-marked-alt"></i></div>
        <h4>Southern Province Coverage</h4>
        <p>
            Galle, Matara, Hambantota, Tangalle and all surrounding coastal towns.
            Delivery charges vary based on distance.
        </p>
    </div>

</div>

                    <!-- MORE INFO BUTTON (triggers popup) -->
                    <button class="more-info-btn" id="moreInfoTrigger">
                        <i class="fas fa-file-contract"></i> Transport terms & details
                        <i class="fas fa-chevron-right" style="font-size:0.9rem;"></i>
                    </button>
                </div>

                <!-- right side stats (keep your layout) -->
                <!-- RIGHT SIDE VISUAL -->
<div class="delivery-visual" data-aos="fade-left">

    <div class="visual-card">

        <!-- Background glow -->
        <div class="visual-glow"></div>

        <!-- Image -->
        <img src="home page images/img1.png" class="visual-media" />

        <!-- Floating badge -->
        <div class="visual-badge">
            <i class="fas fa-bolt"></i>
            6-7 Hour Express Available
        </div>

    </div>

</div>
            </div>
        </section>

         <!-- ========== MODERN POPUP (all 12 points) ========== -->
    <div class="popup-overlay" id="transportPopup">
        <div class="popup-card">
            <div class="popup-header">
                <h3><i class="fas fa-truck-fast" style="margin-right: 10px;"></i> Transport terms & conditions</h3>
                <button class="close-popup" id="closePopupBtn"><i class="fas fa-times"></i></button>
            </div>
            <div class="popup-body">
            <div class="terms-grid">
                <!-- item 1 -->
                <div class="term-item"><strong><i class="fas fa-map-pin"></i> 1. Scope of Transport Service</strong><p>All Pickups & deliveries provided by our fleet. Service covers door‑step collection and drop‑off within Southern Province only.</p></div>
                <!-- 2 -->
                <div class="term-item"><strong><i class="fas fa-location-dot"></i> 2. Service Areas & Eligibility</strong><p>All cities in Southern Province: Galle, Matara, Hambantota, Tangalle, Ambalangoda, Weligama, etc. Remote estates may incur extra coordination.</p></div>
                <!-- 3 -->
                <div class="term-item"><strong><i class="fas fa-calendar-week"></i> 3. Operating Days & Service Continuity</strong><p>We operate 7 days a week, 8 AM-8 PM. Public holidays might have limited drivers, but we always try to cover.</p></div>
                <!-- 4 -->
                <div class="term-item"><strong><i class="fas fa-clock"></i> 4. Pickup & Delivery Timings</strong><p>All pickup and delivery times are estimated time windows, not fixed arrival times. Express service timelines begin only after garments are received and logged at our facility, not from the pickup request time. Delays caused by traffic, weather, road closures, access restrictions, or force majeure events may affect delivery schedules.</p></div>
                <!-- 5 -->
                <div class="term-item"><strong><i class="fas fa-user-check"></i> 5. Customer Availability & Driver Waiting</strong><p>Drivers wait max 10 minutes at pickup/delivery. If unattended beyond 10 minutes:
The trip will be marked as attempted
Pickup or delivery will be rescheduled
Additional transport charges may apply</p></div>
                <!-- 6 -->
                <div class="term-item"><strong><i class="fas fa-ban"></i> 6. Access Restrictions & Failed Attempts</strong><p>If the rider cannot complete the pickup or delivery because the customer is unavailable, the address is incorrect, access to the building is restricted, or security denies entry, the attempt will be marked as failed. Rescheduling will depend on operational availability </p></div>
                <!-- 7 -->
                <div class="term-item"><strong><i class="fas fa-hand"></i> 7. Handover Responsibility</strong><p>Items are handed over only to the person named on booking or verified code. We are not liable for unauthorised collection.</p></div>
                <!-- 8 -->
                <div class="term-item"><strong><i class="fas fa-box"></i> 8. Packaging & Item Condition</strong><p>Clothes must be bagged. Our driver may reject heavily soiled/wet items. We note pre‑existing damage.</p></div>
                 <!-- 9 -->
                <div class="term-item"><strong><i class="fas fa-flask"></i> 9. Express Service Disclaimer</strong><p>Express 6‑7h is subject to route availability & driver capacity. If not possible, we refund surcharge or convert to normal.</p></div>
                <!-- 10 + 11 combined because we love clarity -->
                <div class="term-item">
    <strong>
        <i class="fas fa-receipt"></i> 10. Transport Charges & Pricing
    </strong>
    <p>
        24-Hour Service: <strong>LKR 1000 per kg</strong> + delivery charges based on distance.<br><br>
        Express 6-7 Hour Service: <strong>LKR 1000 per kg</strong> + delivery charges based on distance 
        + <strong>LKR 200 per kg express surcharge</strong>.<br><br>
        Delivery fees vary depending on location and route conditions.
    </p>
</div>
                <div class="term-item"><strong><i class="fas fa-file-signature"></i> 11. Acceptance of Terms</strong><p>By booking a pickup/delivery you explicitly agree to all terms above. Management must approve any refunds (transport delays alone not sufficient).</p></div>
                <!-- additional note to match given text -->
                <div style="background: #E1F3FE; border-radius: 20px; padding: 12px; font-size:0.9rem; border: 1px dashed #2C7AA0;">
                    <i class="fas fa-info-circle" style="color:#2C7AA0;"></i> Transport delays alone do not constitute grounds for refunds unless approved by management.
                </div>
            </div>
            </div>
        </div>
    </div>
        <footer class="final-footer">
            <div class="final-container">
                <div class="final-row">
                    <div class="final-col">
                        <div class="final-brand">
                            <i class="fas fa-tshirt"></i>
                            <span>Perfect Laundry</span>
                        </div>
                        <p class="final-desc">Revolutionizing laundry services with technology and care.</p>
                    </div>

                    <div class="final-col">
                        <h4 class="final-title">Quick Links</h4>
                        <ul class="final-list">
                            <li><a href="home.php">Home</a></li>
                            <li><a href="pricing.html">Services</a></li>
                            <li><a href="BookOnline.html">Book Online</a></li>
                        </ul>
                    </div>

                    <div class="final-col">
                        <h4 class="final-title">Contact</h4>
                        <ul class="final-contact">
                            <li><i class="fas fa-map-marker-alt"></i> 123, Main Street, Tangalle</li>
                            <li><i class="fas fa-phone"></i> +94 77 123 4567</li>
                        </ul>
                    </div>
                </div>

                <div class="final-bottom">
                    <p>© 2026 Perfect Laundry. All rights reserved. | Designed by Team Infynet</p>
                </div>
            </div>
        </footer>

        <button id="backToTop" class="back-to-top">
            <i class="fas fa-arrow-up"></i>
        </button>

        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
        <script>
    AOS.init({ duration: 600, once: true });
    
    // Logout function - calls the logout.php endpoint
    async function logout() {
        try {
            // Clear localStorage first
            localStorage.removeItem('perfect_laundry_user');
            localStorage.removeItem('perfect_laundry_session_token');
            
            // Call logout.php to clear session
            const response = await fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            const result = await response.json();
            
            // Redirect to home page
            window.location.href = 'home.php';
            
        } catch (error) {
            console.error('Logout error:', error);
            // Fallback: just redirect
            window.location.href = 'home.php';
        }
    }
    
    // Alternative: Simple redirect logout (if AJAX fails)
    function logoutSimple() {
        localStorage.removeItem('perfect_laundry_user');
        localStorage.removeItem('perfect_laundry_session_token');
        window.location.href = 'logout.php';
    }
    
    // Check if user is logged in via localStorage and sync with PHP session if needed
    document.addEventListener('DOMContentLoaded', function() {
        const user = localStorage.getItem('perfect_laundry_user');
        if (user) {
            const userData = JSON.parse(user);
            console.log('Logged in as:', userData.full_name);
        }
    });
    


    
</script>
        <script src="dull.js"></script>
    </div>

    <script>
    // Profile dropdown toggle
    const profileBtn = document.getElementById('profileBtn');
    const profileDropdown = document.getElementById('profileDropdown');
    
    if (profileBtn) {
        profileBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            profileDropdown.classList.toggle('show');
            profileBtn.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.classList.remove('show');
                profileBtn.classList.remove('active');
            }
        });
    }
    
    // Logout function
    async function logout() {
        try {
            localStorage.removeItem('perfect_laundry_user');
            localStorage.removeItem('perfect_laundry_session_token');
            
            const response = await fetch('logout.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            window.location.href = 'home.php';
        } catch (error) {
            window.location.href = 'home.php';
        }
    }
</script>
</body>
</html>