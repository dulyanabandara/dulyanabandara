<?php
header('Content-Type: application/json');
require_once 'config_review.php';

$response = ['success' => false, 'message' => 'Unknown error'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $customer_name = mysqli_real_escape_string($conn_review, $data['customer_name'] ?? '');
    $customer_email = mysqli_real_escape_string($conn_review, $data['customer_email'] ?? '');
    $rating = intval($data['rating'] ?? 0);
    $comment = mysqli_real_escape_string($conn_review, $data['comment'] ?? '');
    $service_type = mysqli_real_escape_string($conn_review, $data['service_type'] ?? '');
    $phone = mysqli_real_escape_string($conn_review, $data['phone'] ?? '');
    
    if ($rating < 1 || $rating > 5) {
        $response = ['success' => false, 'message' => 'Please select a valid rating (1-5 stars)'];
        echo json_encode($response);
        exit;
    }
    
    $query = "INSERT INTO feedback (customer_name, customer_email, phone, rating, message, type, service_type, status, created_at) 
              VALUES ('$customer_name', '$customer_email', '$phone', $rating, '$comment', 'review', '$service_type', 'pending', NOW())";
    
    if (mysqli_query($conn_review, $query)) {
        $response = ['success' => true, 'message' => 'Thank you for your review! It will be reviewed by our admin.'];
    } else {
        $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
    }
}

echo json_encode($response);
?>