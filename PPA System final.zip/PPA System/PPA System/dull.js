// dull.js

// Initialize AOS Animation
AOS.init({
    duration: 800,
    once: true,
    offset: 100,
    easing: 'ease-in-out'
});

// Particle.js Configuration
particlesJS('particles-js', {
    particles: {
        number: {
            value: 80,
            density: {
                enable: true,
                value_area: 800
            }
        },
        color: {
            value: ['#4AA3D1', '#6FCF97', '#2C7AA0']
        },
        shape: {
            type: 'circle'
        },
        opacity: {
            value: 0.3,
            random: true,
            anim: {
                enable: true,
                speed: 1,
                opacity_min: 0.1,
                sync: false
            }
        },
        size: {
            value: 3,
            random: true,
            anim: {
                enable: true,
                speed: 2,
                size_min: 0.1,
                sync: false
            }
        },
        line_linked: {
            enable: true,
            distance: 150,
            color: '#7FC9E6',
            opacity: 0.2,
            width: 1
        },
        move: {
            enable: true,
            speed: 1,
            direction: 'none',
            random: true,
            straight: false,
            out_mode: 'out',
            bounce: false,
        }
    },
    interactivity: {
        detect_on: 'canvas',
        events: {
            onhover: {
                enable: true,
                mode: 'grab'
            },
            onclick: {
                enable: true,
                mode: 'push'
            },
            resize: true
        },
        modes: {
            grab: {
                distance: 140,
                line_linked: {
                    opacity: 0.3
                }
            },
            push: {
                particles_nb: 4
            }
        }
    },
    retina_detect: true
});

// Mobile Menu Toggle
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
}

// Active link highlighting (only for same-page anchors)
const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (window.pageYOffset >= sectionTop - 200) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        // Only add active class for same-page anchors (links starting with #)
        const href = link.getAttribute('href');
        if (href.startsWith('#') && href.slice(1) === current) {
            link.classList.add('active');
        }
    });
});

// Counter Animation for Statistics
function animateCounter(element, start, end, duration, suffix = '+') {
    let startTimestamp = null;
    
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = value + suffix;
        
        if (progress < 1) {
            window.requestAnimationFrame(step);
        } else {
            element.textContent = end + suffix;
        }
    };
    
    window.requestAnimationFrame(step);
}

// Intersection Observer for counters
const observerOptions = {
    threshold: 0.5,
    rootMargin: '0px'
};

const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const element = entry.target;
            
            if (element.id === 'happyClients') {
                animateCounter(element, 0, 5000, 2000);
            } else if (element.id === 'clothesCleaned') {
                animateCounter(element, 0, 50000, 2000);
            } else if (element.id === 'deliveryOnTime') {
                animateCounter(element, 0, 99, 2000, '%');
            } else if (element.id === 'deliverySpeed') {
                animateCounter(element, 0, 45, 2000, 'min');
            } else if (element.id === 'satisfiedCustomers') {
                animateCounter(element, 0, 4800, 2000);
            } else if (element.id === 'deliveryFleet') {
                animateCounter(element, 0, 25, 2000);
            } else if (element.id === 'rating') {
                animateCounter(element, 0, 4.9, 2000, '/5.0');
            }
            
            counterObserver.unobserve(element);
        }
    });
}, observerOptions);

// Observe all counter elements
document.querySelectorAll('[id$="Clients"], [id$="Cleaned"], [id$="OnTime"], [id$="Speed"], [id$="Customers"], [id$="Fleet"], [id$="rating"]').forEach(element => {
    counterObserver.observe(element);
});

// Back to Top Button
const backToTop = document.getElementById('backToTop');

if (backToTop) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTop.classList.add('show');
        } else {
            backToTop.classList.remove('show');
        }
    });

    backToTop.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Smooth scrolling for anchor links ONLY (links starting with #)
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar background change on scroll
const navbar = document.querySelector('.navbar');

if (navbar) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 50) {
            navbar.style.background = 'rgba(255, 255, 255, 0.8)';
            navbar.style.backdropFilter = 'blur(15px)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.7)';
            navbar.style.backdropFilter = 'blur(15px)';
        }
    });
}

// Loading animation
window.addEventListener('load', () => {
    const loading = document.createElement('div');
    loading.className = 'loading';
    loading.innerHTML = '<div class="loader"></div>';
    document.body.appendChild(loading);
    
    setTimeout(() => {
        loading.classList.add('fade-out');
        setTimeout(() => {
            loading.remove();
        }, 500);
    }, 1000);
});

// Scroll progress bar
const progressBar = document.createElement('div');
progressBar.className = 'scroll-progress';
document.body.appendChild(progressBar);

window.addEventListener('scroll', () => {
    const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = (window.scrollY / windowHeight) * 100;
    progressBar.style.width = scrolled + '%';
});

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const heroImage = document.querySelector('.hero-image-wrapper');
    const heroContent = document.querySelector('.hero-content');
    
    if (heroImage && heroContent) {
        heroImage.style.transform = `perspective(1000px) rotateY(-10deg) rotateX(5deg) translateY(${scrolled * 0.1}px)`;
        heroContent.style.transform = `translateY(${scrolled * 0.05}px)`;
    }
});

// Parallax tilt effect for visual card
const visualCard = document.querySelector(".visual-card");

if (visualCard) {
    visualCard.addEventListener("mousemove", (e) => {
        const rect = visualCard.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const rotateX = ((y / rect.height) - 0.5) * 10;
        const rotateY = ((x / rect.width) - 0.5) * -10;

        visualCard.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });

    visualCard.addEventListener("mouseleave", () => {
        visualCard.style.transform = "rotateX(0) rotateY(0)";
    });
}

// Book Now button click handler
document.querySelectorAll('.btn-primary').forEach(button => {
    button.addEventListener('click', function(e) {
        if (this.getAttribute('href') === '#book-online') {
            e.preventDefault();
            alert('Booking feature will be available soon! Please check back later.');
        }
    });
});

// View Pricing button click handler - redirect to services page
const pricingBtn = document.querySelector('.services-cta .btn-primary, .btn-large');
if (pricingBtn) {
    pricingBtn.addEventListener('click', function(e) {
        // Allow the link to work normally (it already points to services.html)
        console.log('Redirecting to services page...');
    });
}

// ========== POPUP LOGIC ==========
const popupOverlay = document.getElementById('transportPopup');
const moreBtn = document.getElementById('moreInfoTrigger');
const closeBtn = document.getElementById('closePopupBtn');

if (popupOverlay && moreBtn && closeBtn) {
    function openPopup() {
        popupOverlay.style.display = 'flex';
        // small delay to trigger scale animation
        setTimeout(() => popupOverlay.classList.add('show'), 10);
        document.body.style.overflow = 'hidden'; // prevent background scroll
    }

    function closePopup() {
        popupOverlay.classList.remove('show');
        // wait for animation before hiding
        setTimeout(() => {
            popupOverlay.style.display = 'none';
            document.body.style.overflow = '';
        }, 280);
    }

    moreBtn.addEventListener('click', openPopup);
    closeBtn.addEventListener('click', closePopup);

    // click outside to close
    popupOverlay.addEventListener('click', function(e) {
        if (e.target === popupOverlay) {
            closePopup();
        }
    });
}

// Style the scrollbar inside popup
const style = document.createElement('style');
style.innerHTML = `
    .popup-card::-webkit-scrollbar { width: 6px; }
    .popup-card::-webkit-scrollbar-track { background: rgba(0,0,0,0.02); border-radius: 10px; }
    .popup-card::-webkit-scrollbar-thumb { background: #6FCF97; border-radius: 10px; }
`;
document.head.appendChild(style);

// Prevent default for any dummy anchor
document.querySelectorAll('a[href="#"]').forEach(a => {
    a.addEventListener('click', (e) => e.preventDefault());
});

// Login button click handler - ONLY for homepage, not for login page
const loginBtn = document.querySelector('.btn-login');
if (loginBtn) {
    // Check if we're NOT on the login page
    if (!window.location.href.includes('login.html')) {
        loginBtn.addEventListener('click', function(e) {
            // Allow the default link behavior (go to login.html)
            // Don't prevent default and don't show alert
            console.log('Redirecting to login page...');
        });
    }
}

// Console welcome message
console.log('%c🚀 Perfect Laundry Website', 'font-size: 20px; color: #6FCF97; font-weight: bold;');
console.log('%cDeveloped by Team Infynet', 'font-size: 16px; color: #4AA3D1;');
console.log('© 2026 Perfect Laundry. All rights reserved.');