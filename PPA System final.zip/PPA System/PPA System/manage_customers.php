<?php
// Start session if needed
session_start();

// Include database configuration
require_once 'config_customers.php';

// Handle AJAX requests for add, update, delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    $action = $_POST['action'];
    $response = ['success' => false, 'message' => 'Unknown error'];
    
    if ($action === 'add') {
        $full_name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        $role = 'Customer'; // Default role for new customers
        
        // Generate a default password (you can change this)
        $default_password = password_hash('password123', PASSWORD_DEFAULT);
        
        $query = "INSERT INTO users (full_name, email, phone, password, role, status, address, created_at) 
                  VALUES ('$full_name', '$email', '$phone', '$default_password', '$role', '$status', '$address', NOW())";
        
        if (mysqli_query($conn, $query)) {
            $response = ['success' => true, 'message' => 'Customer added successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)];
        }
    }
    elseif ($action === 'update') {
        $id = intval($_POST['id']);
        $full_name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
        
        $query = "UPDATE users SET 
                  full_name='$full_name', 
                  email='$email', 
                  phone='$phone', 
                  status='$status',
                  address='$address'
                  WHERE id=$id";
        
        if (mysqli_query($conn, $query)) {
            $response = ['success' => true, 'message' => 'Customer updated successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)];
        }
    }
    elseif ($action === 'delete') {
        $id = intval($_POST['id']);
        
        $query = "DELETE FROM users WHERE id=$id";
        
        if (mysqli_query($conn, $query)) {
            $response = ['success' => true, 'message' => 'Customer deleted successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)];
        }
    }
    elseif ($action === 'get_customer') {
        $id = intval($_POST['id']);
        $query = "SELECT * FROM users WHERE id=$id";
        $result = mysqli_query($conn, $query);
        
        if ($row = mysqli_fetch_assoc($result)) {
            $response = ['success' => true, 'customer' => $row];
        } else {
            $response = ['success' => false, 'message' => 'Customer not found'];
        }
    }
    
    echo json_encode($response);
    exit;
}

// Get statistics from users table
$total_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE role='Customer' OR role='customer' OR role IS NULL"))['count'];

// Count active customers (if status column exists, otherwise count all)
$active_customers_query = "SELECT COUNT(*) as count FROM users WHERE (role='Customer' OR role='customer' OR role IS NULL)";
if (mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0) {
    $active_customers_query .= " AND status='Active'";
}
$active_customers = mysqli_fetch_assoc(mysqli_query($conn, $active_customers_query))['count'];

// Count VIP customers
$vip_customers_query = "SELECT COUNT(*) as count FROM users WHERE (role='Customer' OR role='customer' OR role IS NULL)";
if (mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0) {
    $vip_customers_query .= " AND status='VIP'";
} else {
    $vip_customers_query .= " AND 1=0"; // If no status column, VIP count is 0
}
$vip_customers = mysqli_fetch_assoc(mysqli_query($conn, $vip_customers_query))['count'];

// Count new this month
$new_this_month = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())"))['count'];

// Get pagination parameters
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$filter = isset($_GET['filter']) ? mysqli_real_escape_string($conn, $_GET['filter']) : '';

// Build query with filters (only customers, not admins)
$where_conditions = ["(role='Customer' OR role='customer' OR role IS NULL)"];
if (!empty($search)) {
    $where_conditions[] = "(full_name LIKE '%$search%' OR email LIKE '%$search%' OR phone LIKE '%$search%')";
}
if (!empty($filter) && $filter != 'All') {
    // Check if status column exists
    $status_exists = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'status'")->num_rows > 0;
    if ($status_exists && $filter != 'All') {
        $where_conditions[] = "status = '$filter'";
    }
}
$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Get total records for pagination
$total_query = "SELECT COUNT(*) as count FROM users $where_clause";
$total_result = mysqli_query($conn, $total_query);
$total_records = mysqli_fetch_assoc($total_result)['count'];
$total_pages = ceil($total_records / $limit);

// Get users data
$query = "SELECT * FROM users $where_clause ORDER BY id DESC LIMIT $offset, $limit";
$customers_result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Customers - Perfect Laundry Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-dark: #0A1929;
            --bg-dark-light: #102a41;
            --bg-dark-lighter: #1a3f5c;
            --accent-green: #6FCF97;
            --accent-green-dark: #27AE60;
            --accent-blue: #2C7AA0;
            --text-light: #FFFFFF;
            --text-muted: #94A3B8;
            --border-color: #1E3A5F;
            --gradient-green: linear-gradient(135deg, #6FCF97, #27AE60);
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A1929 0%, #102a41 50%, #1a3f5c 100%);
            color: var(--text-light);
            min-height: 100vh;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 280px;
            background: rgba(10, 38, 71, 0.8);
            backdrop-filter: blur(15px);
            padding: 30px 0;
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
        }

        .sidebar-header {
            text-align: center;
            margin-bottom: 40px;
            padding: 0 25px;
        }

        .sidebar-header h2 {
            font-size: 26px;
            background: var(--gradient-green);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }

        .sidebar-header p {
            color: var(--text-muted);
            font-size: 14px;
        }

        .sidebar-nav ul {
            list-style: none;
        }

        .sidebar-nav ul li {
            margin-bottom: 5px;
        }

        .sidebar-nav ul li a {
            display: flex;
            align-items: center;
            padding: 12px 25px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.3s ease;
            margin: 0 10px;
            border-radius: 12px;
        }

        .sidebar-nav ul li a i {
            width: 22px;
            margin-right: 12px;
            color: var(--accent-green);
        }

        .sidebar-nav ul li a:hover,
        .sidebar-nav ul li a.active {
            background: var(--gradient-green);
            color: white;
        }

        .sidebar-nav ul li a:hover i,
        .sidebar-nav ul li a.active i {
            color: white;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        /* Top Header */
        .top-header {
            background: rgba(16, 42, 65, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px 30px;
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .header-title h1 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .header-title p {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .admin-avatar {
            width: 45px;
            height: 45px;
            background: var(--gradient-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(16, 42, 65, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .stat-info h3 {
            font-size: 0.9rem;
            color: var(--text-muted);
            font-weight: 400;
            margin-bottom: 5px;
        }

        .stat-info h2 {
            font-size: 2rem;
            color: var(--accent-green);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient-green);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }

        /* Filters */
        .filters-section {
            background: rgba(16, 42, 65, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(255, 255, 255, 0.05);
            padding: 10px 20px;
            border-radius: 50px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            flex: 1;
            max-width: 400px;
        }

        .search-box i {
            color: var(--text-muted);
        }

        .search-box input {
            background: transparent;
            border: none;
            outline: none;
            color: white;
            width: 100%;
            font-family: 'Poppins', sans-serif;
        }

        .search-box input::placeholder {
            color: var(--text-muted);
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-muted);
            padding: 8px 20px;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-btn:hover,
        .filter-btn.active {
            background: var(--gradient-green);
            color: white;
        }

        .btn-primary {
            background: var(--gradient-green);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            font-family: 'Poppins', sans-serif;
        }

        /* Export Button Style - NEW */
        .btn-export {
            background: linear-gradient(135deg, #2C7AA0, #1E5A7A);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s ease;
        }

        .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(44, 122, 160, 0.4);
        }

        /* Customers Table */
        .table-container {
            background: rgba(16, 42, 65, 0.5);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            overflow-x: auto;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .table-header h3 {
            font-size: 1.2rem;
        }

        .table-controls {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .show-entries select {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            margin-left: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th {
            text-align: left;
            padding: 15px 10px;
            color: var(--accent-green);
            font-weight: 600;
            font-size: 0.9rem;
            border-bottom: 2px solid rgba(255, 255, 255, 0.1);
        }

        table td {
            padding: 15px 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            color: var(--text-muted);
        }

        table tr:hover td {
            background: rgba(255, 255, 255, 0.02);
        }

        .customer-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .customer-avatar {
            width: 40px;
            height: 40px;
            background: var(--gradient-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            color: white;
        }

        .customer-name {
            color: white;
            font-weight: 500;
        }

        .customer-email {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .badge {
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 500;
            display: inline-block;
        }

        .badge-active {
            background: rgba(111, 207, 151, 0.2);
            color: var(--accent-green);
        }

        .badge-inactive {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
        }

        .badge-vip {
            background: rgba(255, 215, 0, 0.2);
            color: gold;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-muted);
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .action-btn:hover {
            background: var(--gradient-green);
            color: white;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 25px;
        }

        .pagination-info {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .pagination-controls {
            display: flex;
            gap: 5px;
        }

        .page-btn {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-muted);
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .page-btn:hover,
        .page-btn.active {
            background: var(--gradient-green);
            color: white;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--bg-dark-light);
            border-radius: 20px;
            padding: 30px;
            width: 90%;
            max-width: 500px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .modal-header h3 {
            font-size: 1.4rem;
        }

        .close-btn {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 1.5rem;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-family: 'Poppins', sans-serif;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--accent-green);
        }

        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn-save {
            flex: 1;
            background: var(--gradient-green);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
        }

        .btn-cancel {
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-muted);
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
        }

        /* Loading indicator */
        .loading {
            opacity: 0.5;
            pointer-events: none;
        }

        /* Toast notification */
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--gradient-green);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1001;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
            }
            
            .sidebar-header p,
            .sidebar-nav ul li a span {
                display: none;
            }
            
            .sidebar-nav ul li a {
                justify-content: center;
                padding: 15px;
            }
            
            .sidebar-nav ul li a i {
                margin: 0;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .filters-section {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box {
                max-width: 100%;
            }
        }
        /* Email Modal Styles - NEW */
.btn-email {
    background: linear-gradient(135deg, #F59E0B, #D97706);
    color: white;
    border: none;
    padding: 10px 25px;
    border-radius: 50px;
    cursor: pointer;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
}

.btn-email:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(245, 158, 11, 0.4);
}

.email-modal-content {
    max-width: 600px;
}

.email-modal-content textarea {
    width: 100%;
    padding: 12px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    color: white;
    font-family: 'Poppins', sans-serif;
    resize: vertical;
}

.email-modal-content textarea:focus {
    outline: none;
    border-color: var(--accent-green);
}

.customer-select {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 8px;
    padding: 12px;
    color: white;
    width: 100%;
    margin-bottom: 15px;
}

.customer-list {
    max-height: 200px;
    overflow-y: auto;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 15px;
}

.customer-list label {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px;
    cursor: pointer;
    border-radius: 5px;
}

.customer-list label:hover {
    background: rgba(255, 255, 255, 0.05);
}

.customer-list input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: var(--accent-green);
}

.select-all {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    margin-bottom: 10px;
    font-weight: 500;
}

.email-status {
    margin-top: 15px;
    padding: 10px;
    border-radius: 8px;
    display: none;
}

.email-status.success {
    background: rgba(111, 207, 151, 0.2);
    color: var(--accent-green);
    display: block;
}

.email-status.error {
    background: rgba(239, 68, 68, 0.2);
    color: #EF4444;
    display: block;
}

.email-status.loading {
    background: rgba(255, 215, 0, 0.2);
    color: #F59E0B;
    display: block;
}
/* Report Button Style - NEW */
.btn-report {
    background: linear-gradient(135deg, #8B5CF6, #7C3AED);
    color: white;
    border: none;
    padding: 10px 25px;
    border-radius: 50px;
    cursor: pointer;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s ease;
}

.btn-report:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(139, 92, 246, 0.4);
}
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Perfect Laundry</h2>
                <p>Admin Panel</p>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="admin-dashboard.html"><i class="fas fa-chart-pie"></i><span> Dashboard</span></a></li>
                    <li><a href="manage_products.php"><i class="fas fa-box"></i><span> Manage Products</span></a></li>
                    <li><a href="visit_admin.html"><i class="fas fa-shopping-cart"></i><span> Manage Orders</span></a></li>
                    <li><a href="manage_customers.php" class="active"><i class="fas fa-users"></i><span> Manage Customers</span></a></li>
                    <li><a href="DeliveryAdmin.html"><i class="fas fa-clock"></i><span> Delivery Status</span></a></li>
                    <li><a href="manage_reviews.php"><i class="fas fa-star"></i><span> Manage Reviews</span></a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i><span> Settings</span></a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span> Logout</span></a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Header -->
            <div class="top-header">
                <div class="header-title">
                    <h1>Manage Customers</h1>
                    <p>View and manage all customer accounts</p>
                </div>
                <div class="admin-profile">
                    <div class="admin-avatar">A</div>
                    <div>
                        <div style="font-weight: 500;">Admin User</div>
                        <div style="font-size: 0.8rem; color: var(--text-muted);">Super Admin</div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Total Customers</h3>
                        <h2><?php echo number_format($total_customers); ?></h2>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Active</h3>
                        <h2><?php echo number_format($active_customers); ?></h2>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>New This Month</h3>
                        <h2><?php echo number_format($new_this_month); ?></h2>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-user-plus"></i>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>VIP Customers</h3>
                        <h2><?php echo number_format($vip_customers); ?></h2>
                    </div>
                    <div class="stat-icon">
                        <i class="fas fa-crown"></i>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-section">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Search customers by name, email, phone..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-buttons">
                    <button class="filter-btn <?php echo $filter == '' || $filter == 'All' ? 'active' : ''; ?>" data-filter="All">All</button>
                    <button class="filter-btn <?php echo $filter == 'Active' ? 'active' : ''; ?>" data-filter="Active">Active</button>
                    <button class="filter-btn <?php echo $filter == 'Inactive' ? 'active' : ''; ?>" data-filter="Inactive">Inactive</button>
                    <button class="filter-btn <?php echo $filter == 'VIP' ? 'active' : ''; ?>" data-filter="VIP">VIP</button>
                </div>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
    <button class="btn-report" onclick="generateReport()">
        <i class="fas fa-chart-bar"></i> Generate Report
    </button>
    <button class="btn-email" onclick="openEmailModal()">
        <i class="fas fa-envelope"></i> Send Email to Customers
    </button>
    <button class="btn-export" onclick="exportToExcel()">
        <i class="fas fa-file-excel"></i> Export to Excel
    </button>
    <button class="btn-primary" onclick="openAddModal()">
        <i class="fas fa-plus"></i> Add Customer
    </button>
</div>
            </div>

            <!-- Customers Table -->
            <div class="table-container">
                <div class="table-header">
                    <h3>Customer List</h3>
                    <div class="table-controls">
                        <div class="show-entries">
                            Show <select id="limitSelect">
                                <option value="10" <?php echo $limit == 10 ? 'selected' : ''; ?>>10</option>
                                <option value="25" <?php echo $limit == 25 ? 'selected' : ''; ?>>25</option>
                                <option value="50" <?php echo $limit == 50 ? 'selected' : ''; ?>>50</option>
                                <option value="100" <?php echo $limit == 100 ? 'selected' : ''; ?>>100</option>
                            </select> entries
                        </div>
                    </div>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="customersTableBody">
                        <?php if (mysqli_num_rows($customers_result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($customers_result)): ?>
                                <tr data-id="<?php echo $row['id']; ?>">
                                    <td>
                                        <div class="customer-info">
                                            <div class="customer-avatar">
                                                <?php echo strtoupper(substr($row['full_name'], 0, 2)); ?>
                                            </div>
                                            <div>
                                                <div class="customer-name"><?php echo htmlspecialchars($row['full_name']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td>
                                        <?php 
                                        $status = isset($row['status']) ? $row['status'] : 'Active';
                                        if ($status == 'Active'): ?>
                                            <span class="badge badge-active">Active</span>
                                        <?php elseif ($status == 'VIP'): ?>
                                            <span class="badge badge-vip">VIP</span>
                                        <?php else: ?>
                                            <span class="badge badge-inactive">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('M Y', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="action-btn" onclick="editCustomer(<?php echo $row['id']; ?>)"><i class="fas fa-edit"></i></button>
                                            <button class="action-btn" onclick="deleteCustomer(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['full_name']); ?>')"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">No customers found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="pagination">
                    <div class="pagination-info">
                        Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $limit, $total_records); ?> of <?php echo $total_records; ?> customers
                    </div>
                    <div class="pagination-controls">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page-1; ?>&limit=<?php echo $limit; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                        <?php endif; ?>
                        
                        <?php
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);
                        
                        for ($i = $start_page; $i <= $end_page; $i++):
                        ?>
                            <a href="?page=<?php echo $i; ?>&limit=<?php echo $limit; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>" class="page-btn <?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page+1; ?>&limit=<?php echo $limit; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo urlencode($filter); ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit Customer Modal -->
    <div class="modal" id="customerModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Add New Customer</h3>
                <button class="close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
            </div>
            <form id="customerForm">
                <input type="hidden" id="customerId" value="">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" id="customerName" placeholder="Enter full name" required>
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="customerEmail" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" id="customerPhone" placeholder="Enter phone number" required>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select id="customerStatus">
                        <option>Active</option>
                        <option>Inactive</option>
                        <option>VIP</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" id="customerAddress" placeholder="Enter address">
                </div>
                <div class="modal-actions">
                    <button type="submit" class="btn-save">Save Customer</button>
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Email Customer Modal - NEW -->
<div class="modal" id="emailModal">
    <div class="modal-content email-modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-envelope"></i> Send Email to Customers</h3>
            <button class="close-btn" onclick="closeEmailModal()"><i class="fas fa-times"></i></button>
        </div>
        
        <div class="form-group">
            <label>Select Recipients</label>
            <div class="customer-select">
                <div class="select-all">
                    <input type="checkbox" id="selectAllCustomers" onchange="toggleAllCustomers()">
                    <label for="selectAllCustomers">Select All Customers</label>
                </div>
                <div class="customer-list" id="customerList">
                    <div style="text-align: center; padding: 20px;">Loading customers...</div>
                </div>
            </div>
        </div>
        
        <div class="form-group">
            <label>Email Subject</label>
            <input type="text" id="emailSubject" class="form-control" placeholder="Enter email subject..." style="background: rgba(255,255,255,0.05); color: white; width: 100%; padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);">
        </div>
        
        <div class="form-group">
            <label>Email Message</label>
            <textarea id="emailMessage" rows="6" placeholder="Enter your message here..."></textarea>
        </div>
        
        <div class="form-group">
            <label>Template Suggestions (click to use)</label>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <button type="button" class="filter-btn" onclick="useTemplate('promo')" style="font-size: 0.8rem;">📢 Promotional</button>
                <button type="button" class="filter-btn" onclick="useTemplate('order')" style="font-size: 0.8rem;">📦 Order Update</button>
                <button type="button" class="filter-btn" onclick="useTemplate('thankyou')" style="font-size: 0.8rem;">🙏 Thank You</button>
                <button type="button" class="filter-btn" onclick="useTemplate('reminder')" style="font-size: 0.8rem;">⏰ Reminder</button>
            </div>
        </div>
        
        <div id="emailStatus" class="email-status"></div>
        
        <div class="modal-actions">
            <button type="button" class="btn-save" onclick="sendEmails()">
                <i class="fas fa-paper-plane"></i> Send Emails
            </button>
            <button type="button" class="btn-cancel" onclick="closeEmailModal()">Cancel</button>
        </div>
    </div>
</div>

    <script>
        // Modal functions
        const modal = document.getElementById('customerModal');
        let currentEditId = null;

        function showToast(message, isError = false) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.style.background = isError ? 'linear-gradient(135deg, #EF4444, #DC2626)' : 'linear-gradient(135deg, #6FCF97, #27AE60)';
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }

        // ========== NEW: EXPORT TO EXCEL FUNCTION ==========
        function exportToExcel() {
            // Get current filter and search values
            const currentFilter = new URLSearchParams(window.location.search).get('filter') || '';
            const currentSearch = document.getElementById('searchInput')?.value || '';
            
            // Show loading toast
            showToast('Exporting customers...', false);
            
            // Redirect to export page with current filters
            window.location.href = `export-customers.php?filter=${encodeURIComponent(currentFilter)}&search=${encodeURIComponent(currentSearch)}`;
        }

        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Add New Customer';
            document.getElementById('customerForm').reset();
            document.getElementById('customerId').value = '';
            currentEditId = null;
            modal.classList.add('active');
        }

        function editCustomer(id) {
            // Fetch customer data
            fetch('manage_customers.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=get_customer&id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const customer = data.customer;
                    document.getElementById('modalTitle').textContent = 'Edit Customer';
                    document.getElementById('customerId').value = customer.id;
                    document.getElementById('customerName').value = customer.full_name;
                    document.getElementById('customerEmail').value = customer.email;
                    document.getElementById('customerPhone').value = customer.phone;
                    document.getElementById('customerStatus').value = customer.status || 'Active';
                    document.getElementById('customerAddress').value = customer.address || '';
                    currentEditId = id;
                    modal.classList.add('active');
                } else {
                    showToast('Error loading customer data', true);
                }
            })
            .catch(error => {
                showToast('Error: ' + error, true);
            });
        }

        function deleteCustomer(id, name) {
            if (confirm(`Are you sure you want to delete customer ${name}?`)) {
                fetch('manage_customers.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=delete&id=${id}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message);
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        showToast(data.message, true);
                    }
                })
                .catch(error => {
                    showToast('Error: ' + error, true);
                });
            }
        }

        function closeModal() {
            modal.classList.remove('active');
        }

        // Form submit
        document.getElementById('customerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const id = document.getElementById('customerId').value;
            const name = document.getElementById('customerName').value;
            const email = document.getElementById('customerEmail').value;
            const phone = document.getElementById('customerPhone').value;
            const status = document.getElementById('customerStatus').value;
            const address = document.getElementById('customerAddress').value;
            
            const action = id ? 'update' : 'add';
            
            fetch('manage_customers.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=${action}&id=${id}&name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&status=${encodeURIComponent(status)}&address=${encodeURIComponent(address)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast(data.message);
                    closeModal();
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showToast(data.message, true);
                }
            })
            .catch(error => {
                showToast('Error: ' + error, true);
            });
        });

        // Filter buttons with URL update
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                const url = new URL(window.location.href);
                if (filter === 'All') {
                    url.searchParams.delete('filter');
                } else {
                    url.searchParams.set('filter', filter);
                }
                url.searchParams.set('page', '1');
                window.location.href = url.toString();
            });
        });

        // Search with debounce
        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const search = this.value;
                const url = new URL(window.location.href);
                if (search) {
                    url.searchParams.set('search', search);
                } else {
                    url.searchParams.delete('search');
                }
                url.searchParams.set('page', '1');
                window.location.href = url.toString();
            }, 500);
        });

        // Limit select change
        document.getElementById('limitSelect').addEventListener('change', function() {
            const limit = this.value;
            const url = new URL(window.location.href);
            url.searchParams.set('limit', limit);
            url.searchParams.set('page', '1');
            window.location.href = url.toString();
        });

        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        // ========== EMAIL NOTIFICATION SYSTEM ==========
let customerEmails = [];

function openEmailModal() {
    document.getElementById('emailModal').classList.add('active');
    loadCustomerList();
}

function closeEmailModal() {
    document.getElementById('emailModal').classList.remove('active');
    document.getElementById('emailSubject').value = '';
    document.getElementById('emailMessage').value = '';
    document.getElementById('emailStatus').className = 'email-status';
}

function loadCustomerList() {
    const customerListDiv = document.getElementById('customerList');
    customerListDiv.innerHTML = '<div style="text-align: center; padding: 20px;">Loading customers...</div>';
    
    // Get current filter and search values
    const currentFilter = new URLSearchParams(window.location.search).get('filter') || '';
    const currentSearch = document.getElementById('searchInput')?.value || '';
    
    fetch(`get-customer-emails.php?filter=${encodeURIComponent(currentFilter)}&search=${encodeURIComponent(currentSearch)}`)
        .then(response => response.json())
        .then(data => {
            if (data.success && data.customers.length > 0) {
                customerEmails = data.customers;
                customerListDiv.innerHTML = data.customers.map(customer => `
                    <label>
                        <input type="checkbox" class="customer-checkbox" value="${customer.email}" data-name="${customer.name}">
                        <span><strong>${escapeHtml(customer.name)}</strong> (${customer.email})</span>
                    </label>
                `).join('');
            } else {
                customerListDiv.innerHTML = '<div style="text-align: center; padding: 20px;">No customers found</div>';
            }
        })
        .catch(error => {
            customerListDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #EF4444;">Error loading customers</div>';
        });
}

function toggleAllCustomers() {
    const selectAll = document.getElementById('selectAllCustomers');
    const checkboxes = document.querySelectorAll('.customer-checkbox');
    checkboxes.forEach(cb => cb.checked = selectAll.checked);
}

function useTemplate(type) {
    const subjectField = document.getElementById('emailSubject');
    const messageField = document.getElementById('emailMessage');
    
    if (type === 'promo') {
        subjectField.value = '🎉 Special Offer from Perfect Laundry!';
        messageField.value = 'Dear Customer,\n\nWe have a special promotion just for you! Get 20% off on all laundry services this week.\n\nUse code: LAUNDRY20 at checkout.\n\nThank you for choosing Perfect Laundry!\n\nBest regards,\nPerfect Laundry Team';
    } else if (type === 'order') {
        subjectField.value = '📦 Your Order Update from Perfect Laundry';
        messageField.value = 'Dear Customer,\n\nYour laundry order is being processed and will be delivered soon.\n\nTrack your order status in your account dashboard.\n\nThank you for choosing Perfect Laundry!\n\nBest regards,\nPerfect Laundry Team';
    } else if (type === 'thankyou') {
        subjectField.value = '🙏 Thank You for Choosing Perfect Laundry!';
        messageField.value = 'Dear Customer,\n\nThank you for trusting us with your laundry needs!\n\nWe appreciate your business and look forward to serving you again.\n\nBest regards,\nPerfect Laundry Team';
    } else if (type === 'reminder') {
        subjectField.value = '⏰ Reminder: Your Laundry Pickup Scheduled';
        messageField.value = 'Dear Customer,\n\nThis is a friendly reminder that your laundry pickup is scheduled for today.\n\nPlease ensure your laundry is ready for collection.\n\nThank you,\nPerfect Laundry Team';
    }
}

function sendEmails() {
    const selectedCheckboxes = document.querySelectorAll('.customer-checkbox:checked');
    
    if (selectedCheckboxes.length === 0) {
        showToast('Please select at least one customer', true);
        return;
    }
    
    const subject = document.getElementById('emailSubject').value.trim();
    const message = document.getElementById('emailMessage').value.trim();
    
    if (!subject || !message) {
        showToast('Please enter both subject and message', true);
        return;
    }
    
    const recipients = Array.from(selectedCheckboxes).map(cb => ({
        email: cb.value,
        name: cb.getAttribute('data-name')
    }));
    
    const statusDiv = document.getElementById('emailStatus');
    statusDiv.className = 'email-status loading';
    statusDiv.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Sending emails... Please wait.';
    
    fetch('send-bulk-email.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            recipients: recipients,
            subject: subject,
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            statusDiv.className = 'email-status success';
            statusDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${data.message}`;
            showToast(data.message);
            setTimeout(() => closeEmailModal(), 2000);
        } else {
            statusDiv.className = 'email-status error';
            statusDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${data.message}`;
            showToast(data.message, true);
        }
    })
    .catch(error => {
        statusDiv.className = 'email-status error';
        statusDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error sending emails. Please try again.';
        showToast('Error sending emails', true);
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
// ========== REPORT GENERATION FUNCTION ==========
function generateReport() {
    // Get current filter and search values
    const currentFilter = new URLSearchParams(window.location.search).get('filter') || '';
    const currentSearch = document.getElementById('searchInput')?.value || '';
    
    // Open report in new window
    const reportWindow = window.open(`customer-report.php?filter=${encodeURIComponent(currentFilter)}&search=${encodeURIComponent(currentSearch)}`, '_blank');
    
    if (!reportWindow) {
        showToast('Please allow pop-ups to generate report', true);
    }
}
    </script>
</body>
</html>