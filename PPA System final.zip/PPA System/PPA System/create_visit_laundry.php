<?php
// create_visit_laundry.php - Create new visit laundry order
session_start();
require_once 'visit_db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Get customer info
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : (isset($data['user_id']) ? $data['user_id'] : null);
$customer_name = mysqli_real_escape_string($conn, $data['customer_name'] ?? '');
$phone = mysqli_real_escape_string($conn, $data['phone'] ?? '');
$email = mysqli_real_escape_string($conn, $data['email'] ?? '');
$visit_date = mysqli_real_escape_string($conn, $data['visit_date'] ?? '');
$service_speed = mysqli_real_escape_string($conn, $data['service_speed'] ?? 'normal');
$total_items = intval($data['total_items'] ?? 0);
$notes = mysqli_real_escape_string($conn, $data['notes'] ?? '');
$services_data = mysqli_real_escape_string($conn, json_encode($data['services_data'] ?? []));

// Validation
if (empty($customer_name) || empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Customer name and phone required']);
    exit();
}

try {
    // Generate order ID using PL format (same as pickup/delivery)
    $order_id = generateVisitOrderId($conn);
    
    // Insert order
    $sql = "INSERT INTO visit_laundry_orders (
        order_id, user_id, customer_name, phone, email, 
        visit_date, service_speed, total_items, notes, services_data
    ) VALUES (
        '$order_id', '$user_id', '$customer_name', '$phone', '$email',
        '$visit_date', '$service_speed', '$total_items', '$notes', '$services_data'
    )";
    
    if (mysqli_query($conn, $sql)) {
        // Insert order items
        if (!empty($data['services_data'])) {
            $item_sql = "INSERT INTO visit_laundry_items (order_id, service_type, item_name, quantity) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $item_sql);
            
            foreach ($data['services_data'] as $service) {
                $service_name = $service['service'] ?? '';
                if (!empty($service['items'])) {
                    foreach ($service['items'] as $item) {
                        $item_name = $item['name'] ?? '';
                        $quantity = intval($item['quantity'] ?? 1);
                        if (!empty($item_name)) {
                            mysqli_stmt_bind_param($stmt, 'sssi', $order_id, $service_name, $item_name, $quantity);
                            mysqli_stmt_execute($stmt);
                        }
                    }
                }
            }
            mysqli_stmt_close($stmt);
        }
        
        // Log the creation
        $log_sql = "INSERT INTO visit_laundry_logs (order_id, action, changed_by) 
                    VALUES ('$order_id', 'Created', 'customer')";
        mysqli_query($conn, $log_sql);
        
        echo json_encode([
            'success' => true,
            'message' => 'Visit laundry order created successfully',
            'order_id' => $order_id
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create order: ' . mysqli_error($conn)]);
    }
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Failed to create order: ' . $e->getMessage()]);
}

mysqli_close($conn);
?>