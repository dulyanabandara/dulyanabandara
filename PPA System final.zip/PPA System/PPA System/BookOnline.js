// =====================================================
// BOOK ONLINE JS - COMPLETE WITH PHOTO UPLOAD
// =====================================================

// Initialize AOS
AOS.init({ duration: 600, once: true });

// API Base URL - Update this to your server path
const API_BASE = 'http://localhost/PPA%20System/PPA%20System/';

// Get current user from localStorage (after login)
let currentUser = null;

// Photo upload variables
let uploadedPhotos = [];

function getCurrentUser() {
    const stored = localStorage.getItem('perfect_laundry_user');
    if (stored) {
        currentUser = JSON.parse(stored);
    }
    return currentUser;
}

// Get session token
function getSessionToken() {
    return localStorage.getItem('perfect_laundry_session_token');
}

// Bubble generator
function createBubbles() {
    const container = document.getElementById('bubblesContainer');
    if(!container) return;
    for(let i=0;i<35;i++) {
        const bubble = document.createElement('div');
        bubble.classList.add('bubble');
        const size = Math.random() * 80 + 20;
        bubble.style.width = size + 'px';
        bubble.style.height = size + 'px';
        bubble.style.left = Math.random() * 100 + '%';
        bubble.style.animationDelay = Math.random() * 15 + 's';
        bubble.style.animationDuration = Math.random() * 12 + 8 + 's';
        bubble.style.background = `rgba(255,255,255,${Math.random() * 0.3 + 0.2})`;
        container.appendChild(bubble);
    }
}
createBubbles();

// ---------- STORE LOCATION (Perfect Laundry - Pallikkudawa, Tangalle) ----------
const STORE_LOCATION = {
    lat: 6.0400,
    lng: 80.7900,
    name: "Perfect Laundry",
    address: "Ranga, Pallikkudawa, Tangalle"
};

// ---------- PRICE CONFIGURATION (ACCURATE PICKME-STYLE RATES) ----------
const PRICES = {
    BASE_RATE_PER_KG: 1000,
    EXPRESS_EXTRA_PER_KG: 200,
    SHOE_CLEANING: 1000,
    PRESS_SERVICE: 500,
    DELIVERY: {
        BASE_FARE: 150,
        RATE_PER_KM: 85,
        BOTH_WAYS_MULTIPLIER: 2
    }
};

// ---------- ACCURATE DISTANCES FROM PERFECT LAUNDRY (PALLIKKUDAWA, TANGALLE) ----------
const CITY_DISTANCES = {
    "pallikkudawa": 0,
    "pallikuduwa": 0,
    "ranga": 0.5,
    "kadurupokuna": 1.5,
    "kadurupokuna junction": 1.5,
    "medaketiya": 2.0,
    "tangalle": 3.5,
    "tangalle town": 3.5,
    "tangalla": 3.5,
    "tangalle beach": 4.0,
    "kahandamodara": 4.5,
    "goda kuda": 3.0,
    "kudawella": 5.0,
    "kalametiya": 7.0,
    "mulkirigala": 9.0,
    "beliatta": 9.0,
    "beliatta town": 9.0,
    "hungama": 14.0,
    "ambalantota": 18.0,
    "hambantota": 24.0,
    "matara": 48.0,
    "galle": 78.0,
    "default": 8.0
};

const TANGALLE_ROADS = ["beliatta road", "matara road", "galle road", "hambantota road"];
const TANGALLE_AREAS = ["pallikkudawa", "kadurupokuna", "medaketiya", "tangalle", "kahandamodara", "ranga"];

function calculateDeliveryCharge(distance, deliveryOption) {
    if (!distance || distance <= 0) return 0;
    let charge = distance <= 1 ? PRICES.DELIVERY.BASE_FARE : PRICES.DELIVERY.BASE_FARE + ((distance - 1) * PRICES.DELIVERY.RATE_PER_KM);
    if (deliveryOption === 'both') charge = charge * PRICES.DELIVERY.BOTH_WAYS_MULTIPLIER;
    return Math.round(charge);
}

function extractCityFromAddress(address) {
    if (!address) return "pallikkudawa";
    const lowerAddress = address.toLowerCase();
    for (const area of TANGALLE_AREAS) {
        if (lowerAddress.includes(area)) return area;
    }
    for (const road of TANGALLE_ROADS) {
        if (lowerAddress.includes(road)) return "tangalle";
    }
    for (const city of Object.keys(CITY_DISTANCES)) {
        if (lowerAddress.includes(city)) return city;
    }
    return "default";
}

function getDistanceFromAddress(address) {
    const city = extractCityFromAddress(address);
    let distance = CITY_DISTANCES[city];
    if (distance === undefined) distance = CITY_DISTANCES.default;
    return distance;
}

function getDistanceDisplayText(distance) {
    if (distance === 0) return `<i class="fas fa-store"></i> At our store location (Pallikkudawa)`;
    if (distance < 1) return `<i class="fas fa-location-dot"></i> ${distance.toFixed(1)} km from store`;
    if (distance <= 3) return `<i class="fas fa-location-dot"></i> ${distance.toFixed(1)} km from store (Nearby area)`;
    if (distance <= 10) return `<i class="fas fa-car"></i> ${distance.toFixed(1)} km from store`;
    return `<i class="fas fa-truck"></i> ${distance.toFixed(1)} km from store`;
}

async function updateDeliveryPrice() {
    const addressInput = document.getElementById('addressInput');
    const distanceGroup = document.getElementById('distanceInfoGroup');
    const deliveryPriceGroup = document.getElementById('deliveryPriceGroup');
    const distanceDisplay = document.getElementById('distanceDisplay');
    const deliveryPriceDisplay = document.getElementById('deliveryPriceDisplay');
    
    const address = addressInput?.value.trim();
    const deliveryOption = document.querySelector('input[name="deliveryOption"]:checked')?.value;
    
    if ((deliveryOption === 'pickup_only' || deliveryOption === 'delivery_only' || deliveryOption === 'both') && address && address.length > 3) {
        distanceGroup.style.display = 'block';
        deliveryPriceGroup.style.display = 'block';
        
        const distance = getDistanceFromAddress(address);
        const isExact = CITY_DISTANCES[extractCityFromAddress(address)] !== undefined;
        const deliveryCharge = calculateDeliveryCharge(distance, deliveryOption);
        
        if (distanceDisplay) {
            distanceDisplay.innerHTML = getDistanceDisplayText(distance);
            distanceDisplay.style.background = isExact ? '#F1F5F9' : '#FFF3E0';
        }
        
        if (deliveryPriceDisplay) {
            const bothWaysNote = deliveryOption === 'both' ? ' (Round trip)' : '';
            deliveryPriceDisplay.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span><i class="fas fa-truck-fast"></i> Delivery Charge${bothWaysNote}:</span>
                    <span style="font-weight: 800; color: #27AE60;">LKR ${deliveryCharge.toLocaleString()}</span>
                </div>
                <small>LKR ${PRICES.DELIVERY.BASE_FARE} first km + LKR ${PRICES.DELIVERY.RATE_PER_KM}/km after</small>
            `;
        }
        
        document.getElementById('calculatedDistance').value = distance.toFixed(1);
        document.getElementById('calculatedDeliveryCharge').value = deliveryCharge;
    } else {
        distanceGroup.style.display = 'none';
        deliveryPriceGroup.style.display = 'none';
    }
}

function addHiddenFields() {
    const form = document.getElementById('pickupForm');
    if (form && !document.getElementById('calculatedDistance')) {
        const hiddenDistance = document.createElement('input');
        hiddenDistance.type = 'hidden';
        hiddenDistance.id = 'calculatedDistance';
        hiddenDistance.name = 'calculatedDistance';
        const hiddenDeliveryCharge = document.createElement('input');
        hiddenDeliveryCharge.type = 'hidden';
        hiddenDeliveryCharge.id = 'calculatedDeliveryCharge';
        hiddenDeliveryCharge.name = 'calculatedDeliveryCharge';
        form.appendChild(hiddenDistance);
        form.appendChild(hiddenDeliveryCharge);
    }
}

function initDistanceCalculator() {
    addHiddenFields();
    const addressInput = document.getElementById('addressInput');
    if (addressInput) {
        let debounceTimer;
        addressInput.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(updateDeliveryPrice, 500);
        });
    }
    document.querySelectorAll('input[name="deliveryOption"]').forEach(radio => {
        radio.addEventListener('change', updateDeliveryPrice);
    });
}

function selectSpeed(speed) {
    const normalRadio = document.getElementById('normalSpeed');
    const expressRadio = document.getElementById('expressSpeed');
    if (speed === 'normal') {
        if (normalRadio) normalRadio.checked = true;
        if (normalRadio?.closest('.speed-card')) normalRadio.closest('.speed-card').style.borderColor = 'var(--luminous-green)';
        if (expressRadio?.closest('.speed-card')) expressRadio.closest('.speed-card').style.borderColor = 'rgba(111, 207, 151, 0.2)';
    } else {
        if (expressRadio) expressRadio.checked = true;
        if (expressRadio?.closest('.speed-card')) expressRadio.closest('.speed-card').style.borderColor = 'var(--luminous-green)';
        if (normalRadio?.closest('.speed-card')) normalRadio.closest('.speed-card').style.borderColor = 'rgba(111, 207, 151, 0.2)';
    }
}

function selectSpeedVisit(speed) {
    const normalRadio = document.getElementById('visitNormalSpeed');
    const expressRadio = document.getElementById('visitExpressSpeed');
    if (speed === 'normal') {
        if (normalRadio) normalRadio.checked = true;
        if (normalRadio?.closest('.speed-card')) normalRadio.closest('.speed-card').style.borderColor = 'var(--luminous-green)';
        if (expressRadio?.closest('.speed-card')) expressRadio.closest('.speed-card').style.borderColor = 'rgba(111, 207, 151, 0.2)';
    } else {
        if (expressRadio) expressRadio.checked = true;
        if (expressRadio?.closest('.speed-card')) expressRadio.closest('.speed-card').style.borderColor = 'var(--luminous-green)';
        if (normalRadio?.closest('.speed-card')) normalRadio.closest('.speed-card').style.borderColor = 'rgba(111, 207, 151, 0.2)';
    }
}

function selectDelivery(option) {
    const pickupOnlyRadio = document.getElementById('pickupOnly');
    const deliveryOnlyRadio = document.getElementById('deliveryOnly');
    const bothRadio = document.getElementById('bothPickupDelivery');
    
    if (option === 'pickup_only') {
        if (pickupOnlyRadio) pickupOnlyRadio.checked = true;
        updateDeliveryHighlight('pickup_only');
    } else if (option === 'delivery_only') {
        if (deliveryOnlyRadio) deliveryOnlyRadio.checked = true;
        updateDeliveryHighlight('delivery_only');
    } else if (option === 'both') {
        if (bothRadio) bothRadio.checked = true;
        updateDeliveryHighlight('both');
    }
    
    const pickupDateGroup = document.getElementById('pickupDateGroup');
    if (option === 'pickup_only' || option === 'both') {
        if (pickupDateGroup) pickupDateGroup.style.display = 'block';
    } else {
        if (pickupDateGroup) pickupDateGroup.style.display = 'none';
    }
    updateDeliveryPrice();
}

function updateDeliveryHighlight(selectedOption) {
    const pickupCard = document.getElementById('pickupOnly')?.closest('.delivery-card');
    const deliveryCard = document.getElementById('deliveryOnly')?.closest('.delivery-card');
    const bothCard = document.getElementById('bothPickupDelivery')?.closest('.delivery-card');
    if (pickupCard) pickupCard.style.borderColor = 'rgba(111, 207, 151, 0.2)';
    if (deliveryCard) deliveryCard.style.borderColor = 'rgba(111, 207, 151, 0.2)';
    if (bothCard) bothCard.style.borderColor = 'rgba(111, 207, 151, 0.2)';
    if (selectedOption === 'pickup_only' && pickupCard) pickupCard.style.borderColor = 'var(--luminous-green)';
    else if (selectedOption === 'delivery_only' && deliveryCard) deliveryCard.style.borderColor = 'var(--luminous-green)';
    else if (selectedOption === 'both' && bothCard) bothCard.style.borderColor = 'var(--luminous-green)';
}

// Multi-Service Management Functions
function addServiceItem(containerId) {
    const container = document.getElementById(containerId);
    if(!container) return;
    const serviceId = 'svc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
    const serviceCard = document.createElement('div');
    serviceCard.className = 'service-card';
    serviceCard.setAttribute('data-service-id', serviceId);
    serviceCard.innerHTML = `
        <div class="service-card-header">
            <select class="service-select-modern" onchange="updateServiceSummary('${serviceId}')">
                <option value="Wash & Fold">🧺 Wash & Fold</option>
                <option value="Dry Clean">✨ Dry Clean</option>
                <option value="Stain Removal">🧼 Stain Removal</option>
                <option value="Kilo Wash">⚖️ Kilo Wash</option>
                <option value="Press">👔 Press / Iron</option>
                <option value="Bed Linen">🛏️ Bed Linen</option>
                <option value="Shoe Cleaning">👟 Shoe Cleaning</option>
                <option value="Carpet Cleaning">🧹 Carpet Cleaning</option>
                <option value="Curtain Cleaning">🚪 Curtain Cleaning</option>
                <option value="Car Seats">🚗 Car Seats</option>
                <option value="Bag Cleaning">👜 Bag Cleaning</option>
            </select>
            <button class="remove-service-btn" onclick="removeServiceItem('${serviceId}', '${containerId}')">
                <i class="fas fa-trash-alt"></i>
            </button>
        </div>
        <div class="clothing-section">
            <div class="clothing-header">
                <label><i class="fas fa-tshirt"></i> Items for this service</label>
                <button class="add-cloth-btn-modern" onclick="addClothItemModern('${serviceId}')">
                    <i class="fas fa-plus-circle"></i> Add Item
                </button>
            </div>
            <div class="clothes-grid" id="clothes_${serviceId}"></div>
        </div>
        <div class="service-summary-modern" id="summary_${serviceId}">
            <i class="fas fa-info-circle"></i> No items added yet
        </div>
    `;
    container.appendChild(serviceCard);
    setTimeout(() => addClothItemModern(serviceId), 10);
    updateServiceCount(containerId);
}

function addClothItemModern(serviceId) {
    const container = document.getElementById(`clothes_${serviceId}`);
    if(!container) return;
    const clothId = 'cloth_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
    const clothDiv = document.createElement('div');
    clothDiv.className = 'cloth-item-modern';
    clothDiv.setAttribute('data-cloth-id', clothId);
    clothDiv.innerHTML = `
        <input type="text" class="cloth-name-modern" placeholder="e.g., Blue Cotton Shirt, Black Jeans..." oninput="updateServiceSummary('${serviceId}')">
        <input type="number" class="cloth-quantity-modern" placeholder="Qty" min="1" value="1" oninput="updateServiceSummary('${serviceId}')">
        <button class="remove-cloth-modern" onclick="removeClothItemModern('${clothId}', '${serviceId}')">
            <i class="fas fa-times-circle"></i>
        </button>
    `;
    container.appendChild(clothDiv);
    updateServiceSummary(serviceId);
}

function removeClothItemModern(clothId, serviceId) {
    const clothElement = document.querySelector(`[data-cloth-id="${clothId}"]`);
    if(clothElement) {
        clothElement.remove();
        updateServiceSummary(serviceId);
    }
}

function removeServiceItem(serviceId, containerId) {
    const serviceElement = document.querySelector(`[data-service-id="${serviceId}"]`);
    if(serviceElement) {
        serviceElement.remove();
        updateServiceCount(containerId);
    }
}

function updateServiceSummary(serviceId) {
    const serviceCard = document.querySelector(`[data-service-id="${serviceId}"]`);
    if(!serviceCard) return;
    const serviceName = serviceCard.querySelector('.service-select-modern')?.value || 'Unknown';
    const clothesItems = serviceCard.querySelectorAll('.cloth-item-modern');
    const summaryDiv = document.getElementById(`summary_${serviceId}`);
    if(!summaryDiv) return;
    if(clothesItems.length === 0) {
        summaryDiv.innerHTML = `<i class="fas fa-exclamation-triangle"></i> No items added for ${serviceName}`;
        return;
    }
    let itemsHtml = '';
    let totalQty = 0;
    clothesItems.forEach(item => {
        const name = item.querySelector('.cloth-name-modern')?.value || '';
        const qty = parseInt(item.querySelector('.cloth-quantity-modern')?.value) || 0;
        if(name && qty > 0) {
            const displayName = name.length > 25 ? name.substring(0, 22) + '...' : name;
            itemsHtml += `<span class="item-tag">${qty}x ${displayName}</span>`;
            totalQty += qty;
        }
    });
    if(totalQty > 0) {
        summaryDiv.innerHTML = `<i class="fas fa-clipboard-list"></i> <strong>${serviceName}</strong> • ${totalQty} item(s)<div style="margin-top: 6px;">${itemsHtml}</div>`;
    } else {
        summaryDiv.innerHTML = `<i class="fas fa-edit"></i> Please add items for ${serviceName}`;
    }
}

function updateServiceCount(containerId) {
    const container = document.getElementById(containerId);
    if(!container) return;
    const serviceCards = container.querySelectorAll('.service-card');
    const count = serviceCards.length;
    let badgeId = containerId === 'servicesListPickup' ? 'serviceCountPickup' : 'serviceCountVisit';
    const countSpan = document.getElementById(badgeId);
    if(countSpan) countSpan.textContent = count;
}

function getServicesDataModern(containerId) {
    const container = document.getElementById(containerId);
    if(!container) return [];
    const services = [];
    const serviceCards = container.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        const serviceName = card.querySelector('.service-select-modern')?.value || '';
        const clothes = [];
        const clothItems = card.querySelectorAll('.cloth-item-modern');
        clothItems.forEach(cloth => {
            const name = cloth.querySelector('.cloth-name-modern')?.value || '';
            const quantity = parseInt(cloth.querySelector('.cloth-quantity-modern')?.value) || 0;
            if(name && quantity > 0) clothes.push({ name, quantity });
        });
        if(clothes.length > 0) services.push({ service: serviceName, items: clothes });
    });
    return services;
}

function clearServicesList(containerId) {
    const container = document.getElementById(containerId);
    if(container) {
        container.innerHTML = '';
        updateServiceCount(containerId);
    }
}

// =====================================================
// PHOTO UPLOAD FUNCTIONS - FIXED VERSION
// =====================================================

function handlePhotoUpload(files) {
    if (!files || files.length === 0) return;
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        if (!file.type.startsWith('image/')) {
            alert(`"${file.name}" is not an image file. Please select JPEG, PNG, or GIF files.`);
            continue;
        }
        
        if (file.size > 5 * 1024 * 1024) {
            alert(`"${file.name}" is too large (max 5MB). Please choose a smaller image.`);
            continue;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const photoData = {
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                data: e.target.result,
                name: file.name,
                stainNote: null
            };
            uploadedPhotos.push(photoData);
            renderPhotoGrid();
            updatePhotoInputValue();
        };
        reader.onerror = function() {
            alert(`Failed to read file: ${file.name}`);
        };
        reader.readAsDataURL(file);
    }
}

function renderPhotoGrid() {
    const grid = document.getElementById('photoGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    // Create upload button
    const uploadBtn = document.createElement('div');
    uploadBtn.className = 'photo-upload-btn';
    uploadBtn.onclick = function(e) {
        e.preventDefault();
        const photoInput = document.getElementById('photoInput');
        if (photoInput) {
            photoInput.click();
        }
    };
    uploadBtn.innerHTML = `
        <i class="fas fa-plus-circle"></i>
        <span>Add Photos</span>
    `;
    grid.appendChild(uploadBtn);
    
    // Add uploaded photos
    uploadedPhotos.forEach(photo => {
        const photoCard = document.createElement('div');
        photoCard.className = 'photo-card';
        photoCard.setAttribute('data-photo-id', photo.id);
        photoCard.onclick = (e) => {
            if (!e.target.classList || !e.target.classList.contains('remove-photo')) {
                previewPhoto(photo.data);
            }
        };
        
        photoCard.innerHTML = `
            <img src="${photo.data}" alt="Clothes photo" style="width:100%; height:100%; object-fit:cover;">
            <button class="remove-photo" onclick="event.stopPropagation(); removePhoto('${photo.id}')">
                <i class="fas fa-times"></i>
            </button>
            ${photo.stainNote ? `<div class="stain-badge" title="${escapeHtml(photo.stainNote)}">⚠️ ${photo.stainNote.substring(0, 20)}${photo.stainNote.length > 20 ? '...' : ''}</div>` : ''}
        `;
        
        grid.appendChild(photoCard);
    });
}

function removePhoto(photoId) {
    uploadedPhotos = uploadedPhotos.filter(p => p.id !== photoId);
    renderPhotoGrid();
    updatePhotoInputValue();
}

function previewPhoto(imageSrc) {
    const modal = document.createElement('div');
    modal.className = 'photo-preview-modal';
    modal.onclick = () => modal.remove();
    modal.innerHTML = `<img src="${imageSrc}" alt="Preview" style="max-width:90%; max-height:90%; border-radius:8px;">`;
    document.body.appendChild(modal);
}

function addStainNote() {
    if (uploadedPhotos.length === 0) {
        alert('📸 Please upload a photo first to add a stain note.');
        return;
    }
    
    let photoOptions = '';
    uploadedPhotos.forEach((p, idx) => {
        photoOptions += `${idx + 1}. ${p.name || 'Photo ' + (idx + 1)}${p.stainNote ? ' ✓ (has note)' : ''}\n`;
    });
    
    const selected = prompt(`Select which photo has the stain:\n\n${photoOptions}\n\nEnter number (1-${uploadedPhotos.length}):`);
    
    if (selected && !isNaN(selected) && selected >= 1 && selected <= uploadedPhotos.length) {
        const note = prompt('Describe the stain or damage (e.g., "Coffee stain on white shirt", "Torn pocket", "Button missing"):');
        if (note && note.trim()) {
            uploadedPhotos[selected - 1].stainNote = note.trim();
            renderPhotoGrid();
            updatePhotoInputValue();
            alert('✅ Stain note added successfully! Staff will pay special attention to this item.');
        }
    }
}

function updatePhotoInputValue() {
    const hiddenInput = document.getElementById('clothesPhotos');
    if (hiddenInput) {
        const photoData = uploadedPhotos.map(p => ({
            data: p.data,
            stainNote: p.stainNote,
            name: p.name
        }));
        hiddenInput.value = JSON.stringify(photoData);
    }
}

function initPhotoUpload() {
    const photoInput = document.getElementById('photoInput');
    if (photoInput) {
        const newPhotoInput = photoInput.cloneNode(true);
        photoInput.parentNode.replaceChild(newPhotoInput, photoInput);
        
        newPhotoInput.addEventListener('change', function(e) {
            if (e.target.files && e.target.files.length > 0) {
                handlePhotoUpload(e.target.files);
                e.target.value = '';
            }
        });
    }
    
    // Initial render
    renderPhotoGrid();
}

// =====================================================
// PICKUP/DELIVERY FORM HANDLER
// =====================================================

async function handlePickupSubmit(e) {
    e.preventDefault();
    
    const user = getCurrentUser();
    if (!user) {
        alert("Please login to place an order");
        window.location.href = "login.html";
        return;
    }
    
    const form = e.target;
    const name = form.querySelector('[name="name"]').value.trim();
    const phone = form.querySelector('[name="phone"]').value.trim();
    const email = form.querySelector('[name="email"]').value.trim();
    const address = form.querySelector('[name="address"]').value.trim();
    const calculatedDistance = document.getElementById('calculatedDistance')?.value;
    const calculatedDeliveryCharge = document.getElementById('calculatedDeliveryCharge')?.value;
    
    if(!name || !phone || !email) { alert("Please fill name, phone and email"); return; }
    if(!address) { alert("Please enter your address for pickup/delivery"); return; }
    
    const services = getServicesDataModern('servicesListPickup');
    if(services.length === 0) { alert("Please add at least one service and item to continue."); return; }
    
    let hasItems = false, totalItems = 0;
    services.forEach(s => {
        if(s.items && s.items.length > 0) {
            hasItems = true;
            s.items.forEach(item => totalItems += item.quantity);
        }
    });
    if(!hasItems) { alert("Please add at least one item to your service."); return; }
    
    const serviceSpeed = form.querySelector('input[name="serviceSpeed"]:checked')?.value || 'normal';
    const deliveryOption = form.querySelector('input[name="deliveryOption"]:checked')?.value || 'pickup_only';
    const pickupDate = form.querySelector('[name="pickupDate"]')?.value || '';
    
    let deliveryCharge = 0;
    let distance = 0;
    if ((deliveryOption === 'pickup_only' || deliveryOption === 'delivery_only' || deliveryOption === 'both') && calculatedDeliveryCharge) {
        deliveryCharge = parseFloat(calculatedDeliveryCharge);
        distance = parseFloat(calculatedDistance);
    }
    
    const orderData = {
        user_id: user.id,
        customer_name: name,
        phone: phone,
        email: email,
        address: address,
        service_speed: serviceSpeed,
        delivery_option: deliveryOption,
        order_type: 'pickup',
        total_items: totalItems,
        delivery_distance: distance,
        delivery_charge: deliveryCharge,
        notes: form.querySelector('[name="notes"]').value,
        pickupDate: pickupDate,
        services_data: services
    };
    
    console.log('Sending order data:', orderData);
    
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Placing Order...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch(API_BASE + 'place_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            let deliveryMessage = '';
            if (deliveryCharge > 0) {
                deliveryMessage = `\n🚚 Delivery Charge: LKR ${Math.round(deliveryCharge)} (${distance.toFixed(1)} km)`;
            }
            
            let serviceDetails = '';
            services.forEach((service, index) => {
                let itemCount = 0;
                service.items.forEach(item => itemCount += item.quantity);
                serviceDetails += `\n   ${index + 1}. ${service.service} - ${itemCount} item(s)`;
            });
            
            const alertMessage = `✨ Order placed! Order ID: ${result.order_id}\n📧 Confirmation sent to ${email}\n\n📦 ${services.length} service(s) with ${totalItems} total items${serviceDetails}\n🚚 ${deliveryOption === 'pickup_only' ? 'Pickup Only' : deliveryOption === 'delivery_only' ? 'Delivery Only' : 'Both Pickup & Delivery'}${deliveryMessage}\n⚡ ${serviceSpeed === 'express' ? 'Express Service (6-7 hours)' : 'Normal Service (2-3 days)'}\n\n💰 Package price will be confirmed after weighing.`;
            
            alert(alertMessage);
            
            form.reset();
            clearServicesList('servicesListPickup');
            addServiceItem('servicesListPickup');
            
            window.location.href = `OrderConfirmation.html?id=${result.order_id}`;
            
        } else {
            alert(`Error: ${result.error || 'Failed to place order'}`);
        }
    } catch (error) {
        console.error('Fetch error:', error);
        alert('Network error. Please try again.');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// =====================================================
// VISIT LAUNDRY FORM HANDLER WITH PHOTO UPLOAD - FIXED WITH REDIRECT
// =====================================================

async function handleVisitSubmit(e) {
    e.preventDefault();
    
    const user = getCurrentUser();
    if (!user) {
        alert("Please login to place an order");
        window.location.href = "login.html";
        return;
    }
    
    const form = e.target;
    const name = form.querySelector('[name="name"]').value.trim();
    const phone = form.querySelector('[name="phone"]').value.trim();
    const email = form.querySelector('[name="email"]').value.trim();
    
    if(!name || !phone || !email) { 
        alert("Please fill name, phone and email"); 
        return; 
    }
    
    const services = getServicesDataModern('servicesListVisit');
    if(services.length === 0) { 
        alert("Please add at least one service and item to continue."); 
        return; 
    }
    
    let hasItems = false, totalItems = 0;
    services.forEach(s => {
        if(s.items && s.items.length > 0) {
            hasItems = true;
            s.items.forEach(item => totalItems += item.quantity);
        }
    });
    if(!hasItems) { 
        alert("Please add at least one item to your service."); 
        return; 
    }
    
    const serviceSpeed = form.querySelector('input[name="visitServiceSpeed"]:checked')?.value || 'normal';
    const visitDateTime = form.querySelector('[name="visitDateTime"]')?.value || '';
    
    // Get photo data
    const clothesPhotos = uploadedPhotos.map(p => ({
        data: p.data,
        stainNote: p.stainNote
    }));
    
    const orderData = {
        user_id: user.id,
        customer_name: name,
        phone: phone,
        email: email,
        service_speed: serviceSpeed,
        delivery_option: 'visit',
        order_type: 'visit',
        total_items: totalItems,
        notes: form.querySelector('[name="notes"]').value,
        visit_date: visitDateTime,
        services_data: services,
        clothes_photos: clothesPhotos
    };
    
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Booking...';
    submitBtn.disabled = true;
    
    try {
        const response = await fetch(API_BASE + 'place_order.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            let photoMessage = '';
            if (clothesPhotos.length > 0) {
                photoMessage = `\n📸 ${clothesPhotos.length} photo(s) uploaded for staff reference`;
            }
            
            alert(`🏬 Store visit booked! Order ID: ${result.order_id}\n📧 Confirmation sent to ${email}\n\n📦 ${services.length} service(s) with ${totalItems} total items\n⚡ ${serviceSpeed === 'express' ? 'Express Service (6-7 hours)' : 'Normal Service (2-3 days)'}${photoMessage}\n\n📸 Staff will review your uploaded photos before your arrival.`);
            
            // Reset photos
            uploadedPhotos = [];
            renderPhotoGrid();
            
            form.reset();
            clearServicesList('servicesListVisit');
            addServiceItem('servicesListVisit');
            
            // ✅ REDIRECT TO ORDER CONFIRMATION PAGE
            window.location.href = `OrderConfirmation.html?id=${result.order_id}`;
            
        } else {
            alert(`Error: ${result.error || 'Failed to book visit'}`);
        }
    } catch (error) {
        console.error('Fetch error:', error);
        alert('Network error. Please try again.');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// Tab Switching
function initTabs() {
    const tabs = document.querySelectorAll('.tab-btn');
    const panes = {
        pickup: document.getElementById('pickupPane'),
        visit: document.getElementById('visitPane')
    };
    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            tabs.forEach(t => t.classList.remove('active'));
            btn.classList.add('active');
            Object.values(panes).forEach(pane => pane.classList.remove('active-pane'));
            if(tabId === 'pickup') panes.pickup.classList.add('active-pane');
            else panes.visit.classList.add('active-pane');
            
            // Re-initialize photo grid when visit tab is clicked
            if(tabId === 'visit') {
                setTimeout(renderPhotoGrid, 100);
            }
        });
    });
}

function initMobileMenu() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    if(hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
        });
    }
}

function initHighlights() {
    const normalSpeed = document.getElementById('normalSpeed');
    if(normalSpeed && normalSpeed.checked) {
        const normalCard = normalSpeed.closest('.speed-card');
        if(normalCard) normalCard.style.borderColor = 'var(--luminous-green)';
    }
    const pickupOnly = document.getElementById('pickupOnly');
    if(pickupOnly && pickupOnly.checked) {
        const pickupCard = pickupOnly.closest('.delivery-card');
        if(pickupCard) pickupCard.style.borderColor = 'var(--luminous-green)';
    }
    const visitNormal = document.getElementById('visitNormalSpeed');
    if(visitNormal && visitNormal.checked) {
        const visitCard = visitNormal.closest('.speed-card');
        if(visitCard) visitCard.style.borderColor = 'var(--luminous-green)';
    }
}

function escapeHtml(text) {
    if(!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateUserNav() {
    const user = localStorage.getItem('perfect_laundry_user');
    const navSection = document.getElementById('userNavSection');
    
    if (user) {
        const userData = JSON.parse(user);
        const firstName = userData.full_name ? userData.full_name.split(' ')[0] : 'User';
        
        navSection.innerHTML = `
            <div class="user-profile" style="position: relative;">
                <button class="profile-btn" id="profileBtn" style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border: 1px solid rgba(111,207,151,0.3); padding: 8px 16px; border-radius: 40px; cursor: pointer; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-user-circle" style="font-size: 1.2rem; color: #6FCF97;"></i>
                    <span style="font-weight: 600;">${escapeHtml(firstName)}</span>
                    <i class="fas fa-chevron-down" style="font-size: 0.8rem;"></i>
                </button>
                <div class="profile-dropdown" id="profileDropdown" style="position: absolute; top: 50px; right: 0; width: 200px; background: white; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); overflow: hidden; opacity: 0; visibility: hidden; transform: translateY(-10px); transition: all 0.3s; z-index: 1000;">
                    <div style="padding: 15px; background: #E1F3FE; border-bottom: 1px solid #E2E8F0;">
                        <strong style="display: block; color: #1A2F3F;">${escapeHtml(userData.full_name || userData.name)}</strong>
                        <div style="font-size: 0.75rem; color: #2C3E50; margin-top: 4px;">${escapeHtml(userData.email)}</div>
                    </div>
                    <a href="account.php" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #1A2F3F; text-decoration: none; transition: background 0.2s;">
                        <i class="fas fa-user" style="width: 20px; color: #6FCF97;"></i> 
                        <span>My Account</span>
                    </a>
                    <div style="height: 1px; background: #E2E8F0;"></div>
                    <a href="#" onclick="logout(); return false;" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #e74c3c; text-decoration: none; transition: background 0.2s;">
                        <i class="fas fa-sign-out-alt" style="width: 20px;"></i> 
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        `;
        
        const style = document.createElement('style');
        style.textContent = `
            .profile-dropdown a:hover {
                background: #F7F9FC;
            }
        `;
        document.head.appendChild(style);
        
        const profileBtn = document.getElementById('profileBtn');
        const profileDropdown = document.getElementById('profileDropdown');
        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isVisible = profileDropdown.style.visibility === 'visible';
                profileDropdown.style.opacity = isVisible ? '0' : '1';
                profileDropdown.style.visibility = isVisible ? 'hidden' : 'visible';
                profileDropdown.style.transform = isVisible ? 'translateY(-10px)' : 'translateY(0)';
            });
            
            document.addEventListener('click', (e) => {
                if (profileBtn && profileDropdown && !profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                    profileDropdown.style.opacity = '0';
                    profileDropdown.style.visibility = 'hidden';
                    profileDropdown.style.transform = 'translateY(-10px)';
                }
            });
        }
    } else {
        navSection.innerHTML = `
            <a href="login.html" class="btn-login" id="loginBtn">
                <i class="fas fa-user-circle"></i> Log In
            </a>
        `;
    }
}

function logout() {
    localStorage.removeItem('perfect_laundry_user');
    localStorage.removeItem('perfect_laundry_session_token');
    window.location.href = 'home.php';
}

function handlePhotoUpload(files) {
    if (!files || files.length === 0) return;
    
    // Allowed file types
    const allowedTypes = [
        'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 
        'image/webp', 'image/bmp', 'image/svg+xml'
    ];
    
    // Allowed extensions
    const allowedExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'];
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // Get file extension
        const fileName = file.name.toLowerCase();
        const fileExtension = fileName.substring(fileName.lastIndexOf('.'));
        
        // Check if file type is allowed
        const isTypeAllowed = allowedTypes.includes(file.type);
        const isExtensionAllowed = allowedExtensions.includes(fileExtension);
        
        if (!isTypeAllowed && !isExtensionAllowed) {
            alert(`"${file.name}" is not an image file.\n\nPlease select: JPEG, PNG, GIF, WebP, or BMP files only.`);
            console.log('Rejected file:', file.name, 'Type:', file.type, 'Extension:', fileExtension);
            continue;
        }
        
        // Check file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert(`"${file.name}" is too large (max 5MB). Please choose a smaller image.`);
            console.log('Rejected - too large:', file.size);
            continue;
        }
        
        const reader = new FileReader();
        reader.onload = function(e) {
            const photoData = {
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 6),
                data: e.target.result,
                name: file.name,
                stainNote: null
            };
            uploadedPhotos.push(photoData);
            renderPhotoGrid();
            updatePhotoInputValue();
        };
        reader.onerror = function() {
            alert(`Failed to read file: ${file.name}`);
        };
        reader.readAsDataURL(file);
    }
}

// =====================================================
// INITIALIZE EVERYTHING
// =====================================================

document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initMobileMenu();
    initDistanceCalculator();
    updateUserNav();
    initPhotoUpload();
    
    setTimeout(() => {
        if(document.getElementById('servicesListPickup')) addServiceItem('servicesListPickup');
        if(document.getElementById('servicesListVisit')) addServiceItem('servicesListVisit');
        initHighlights();
    }, 100);
    
    const pickupForm = document.getElementById('pickupForm');
    const visitForm = document.getElementById('visitForm');
    if(pickupForm) pickupForm.addEventListener('submit', handlePickupSubmit);
    if(visitForm) visitForm.addEventListener('submit', handleVisitSubmit);
});