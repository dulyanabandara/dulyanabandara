<?php
// Review Management Database Configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'perfect_laundry';

// Create connection
$conn_review = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check connection
if (!$conn_review) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($conn_review, "utf8mb4");
?>