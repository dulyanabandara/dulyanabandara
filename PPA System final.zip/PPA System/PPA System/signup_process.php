<?php
// Include the database connection
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password = $_POST['password'];
    
    // Validate inputs
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        echo "<script>alert('All fields are required!'); window.location.href='signup.html';</script>";
        exit();
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!'); window.location.href='signup.html';</script>";
        exit();
    }
    
    // Validate phone (Sri Lankan format - 10 digits)
    if (!preg_match('/^[0-9]{10}$/', $phone)) {
        echo "<script>alert('Invalid phone number! Please enter 10 digits.'); window.location.href='signup.html';</script>";
        exit();
    }
    
    // Validate password length
    if (strlen($password) < 6) {
        echo "<script>alert('Password must be at least 6 characters!'); window.location.href='signup.html';</script>";
        exit();
    }
    
    // 1. Check if email already exists
    $checkEmail = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $checkEmail);
    
    if (mysqli_num_rows($result) > 0) {
        echo "<script>alert('Email already registered! Please login.'); window.location.href='login.html';</script>";
        exit();
    }
    
    // 2. Check if phone already exists
    $checkPhone = "SELECT * FROM users WHERE phone = '$phone'";
    $resultPhone = mysqli_query($conn, $checkPhone);
    
    if (mysqli_num_rows($resultPhone) > 0) {
        echo "<script>alert('Phone number already registered! Please login.'); window.location.href='login.html';</script>";
        exit();
    }
    
    // 3. Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // 4. Insert user into database
    $sql = "INSERT INTO users (full_name, email, phone, password, role) 
            VALUES ('$full_name', '$email', '$phone', '$hashed_password', 'Customer')";
    
    if (mysqli_query($conn, $sql)) {
        // Get the newly created user ID
        $new_user_id = mysqli_insert_id($conn);
        
        // Use the ID as user_id (convert to string format for consistency)
        $user_id = 'USR' . str_pad($new_user_id, 6, '0', STR_PAD_LEFT);
        
        // Prepare user data for localStorage
        $userData = [
            'user_id' => $user_id,
            'id' => $new_user_id,
            'full_name' => $full_name,
            'email' => $email,
            'phone' => $phone,
            'role' => 'Customer'
        ];
        
        $session_token = bin2hex(random_bytes(32));
        
        // Set session variables
        session_start();
        $_SESSION['user_id'] = $new_user_id;
        $_SESSION['user_name'] = $full_name;
        $_SESSION['role'] = 'Customer';
        $_SESSION['logged_in'] = true;
        
        // Auto-login and redirect to home page
        echo "<!DOCTYPE html>
        <html>
        <head>
            <script>
                localStorage.setItem('perfect_laundry_user', '" . json_encode($userData) . "');
                localStorage.setItem('perfect_laundry_session_token', '" . $session_token . "');
                alert('Registration Successful! Welcome " . addslashes($full_name) . "!');
                window.location.href = 'home.php';
            </script>
        </head>
        <body>
            <p>Redirecting to your dashboard...</p>
        </body>
        </html>";
        exit();
    } else {
        // Display specific error
        $error = mysqli_error($conn);
        if (strpos($error, 'Duplicate') !== false) {
            echo "<script>alert('Email or phone already registered!'); window.location.href='signup.html';</script>";
        } else {
            echo "<script>alert('Registration failed: " . addslashes($error) . "'); window.location.href='signup.html';</script>";
        }
    }
}

mysqli_close($conn);
?>