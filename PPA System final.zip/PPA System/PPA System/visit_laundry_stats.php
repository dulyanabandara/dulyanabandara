<?php
// visit_laundry_stats.php - Get dashboard statistics
session_start();
require_once 'visit_db.php';

// Check if user is admin
$is_admin = false;
if (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin') {
    $is_admin = true;
}

if (!$is_admin) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}

try {
    $stats = [];
    
    // Total orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM visit_laundry_orders");
    $stats['total'] = mysqli_fetch_assoc($result)['total'];
    
    // Pending orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as pending FROM visit_laundry_orders WHERE status = 'Pending'");
    $stats['pending'] = mysqli_fetch_assoc($result)['pending'];
    
    // Confirmed orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as confirmed FROM visit_laundry_orders WHERE status = 'Confirmed'");
    $stats['confirmed'] = mysqli_fetch_assoc($result)['confirmed'];
    
    // Processing orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as processing FROM visit_laundry_orders WHERE status = 'Processing'");
    $stats['processing'] = mysqli_fetch_assoc($result)['processing'];
    
    // Ready orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as ready FROM visit_laundry_orders WHERE status = 'Ready'");
    $stats['ready'] = mysqli_fetch_assoc($result)['ready'];
    
    // Completed this month
    $result = mysqli_query($conn, "SELECT COUNT(*) as completed_this_month FROM visit_laundry_orders 
                                   WHERE status = 'Completed' AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                                   AND YEAR(created_at) = YEAR(CURRENT_DATE())");
    $stats['completed_this_month'] = mysqli_fetch_assoc($result)['completed_this_month'];
    
    // Recent orders (last 10)
    $result = mysqli_query($conn, "SELECT * FROM visit_laundry_orders ORDER BY created_at DESC LIMIT 10");
    $recent_orders = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $recent_orders[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'recent_orders' => $recent_orders
    ]);
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>