<?php
// export_visit_report_excel.php - Export visit laundry report to Excel
session_start();
require_once 'visit_db.php';

// Check if user is admin
$is_admin = false;
if (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin') {
    $is_admin = true;
}

if (!$is_admin) {
    die('Unauthorized access');
}

$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
$report_type = isset($_GET['report_type']) ? mysqli_real_escape_string($conn, $_GET['report_type']) : 'orders';

$where_conditions = [];

if ($date_from && $date_to) {
    $where_conditions[] = "DATE(created_at) BETWEEN '$date_from' AND '$date_to'";
} elseif ($date_from) {
    $where_conditions[] = "DATE(created_at) >= '$date_from'";
} elseif ($date_to) {
    $where_conditions[] = "DATE(created_at) <= '$date_to'";
}

if ($status !== 'all') {
    $where_conditions[] = "status = '$status'";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

$sql = "SELECT * FROM visit_laundry_orders $where_clause ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="visit_laundry_report_' . date('Y-m-d') . '.xls"');

echo '<html>';
echo '<head>';
echo '<meta charset="UTF-8">';
echo '<title>Visit Laundry Report</title>';
echo '<style>';
echo 'th { background-color: #4CAF50; color: white; padding: 8px; }';
echo 'td { padding: 6px; border: 1px solid #ddd; }';
echo '</style>';
echo '</head>';
echo '<body>';

if ($report_type === 'orders') {
    echo '<h2>Visit Laundry Orders Report</h2>';
    echo '<p>Generated on: ' . date('Y-m-d H:i:s') . '</p>';
    echo '<p>Date Range: ' . ($date_from ? $date_from : 'All') . ' to ' . ($date_to ? $date_to : 'All') . '</p>';
    echo '<p>Status Filter: ' . ($status !== 'all' ? $status : 'All') . '</p>';
    
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr>';
    echo '<th>Order ID</th>';
    echo '<th>Customer Name</th>';
    echo '<th>Phone</th>';
    echo '<th>Email</th>';
    echo '<th>Visit Date</th>';
    echo '<th>Service Speed</th>';
    echo '<th>Total Items</th>';
    echo '<th>Weight (kg)</th>';
    echo '<th>Package Price</th>';
    echo '<th>Total Price</th>';
    echo '<th>Status</th>';
    echo '<th>Payment Status</th>';
    echo '<th>Created Date</th>';
    echo '</tr>';
    
    $total_revenue = 0;
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['order_id'] . '</td>';
        echo '<td>' . $row['customer_name'] . '</td>';
        echo '<td>' . $row['phone'] . '</td>';
        echo '<td>' . $row['email'] . '</td>';
        echo '<td>' . ($row['visit_date'] ? date('Y-m-d H:i', strtotime($row['visit_date'])) : 'N/A') . '</td>';
        echo '<td>' . ucfirst($row['service_speed']) . '</td>';
        echo '<td>' . ($row['total_items'] ?: 0) . '</td>';
        echo '<td>' . ($row['weight'] ?: 'N/A') . '</td>';
        echo '<td>' . ($row['package_price'] ? 'LKR ' . number_format($row['package_price'], 2) : 'N/A') . '</td>';
        echo '<td><strong>' . ($row['total_price'] ? 'LKR ' . number_format($row['total_price'], 2) : 'Pending') . '</strong></td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '<td>' . ucfirst($row['payment_status']) . '</td>';
        echo '<td>' . date('Y-m-d H:i', strtotime($row['created_at'])) . '</td>';
        echo '</tr>';
        
        if ($row['total_price']) {
            $total_revenue += floatval($row['total_price']);
        }
    }
    
    echo '<tr style="background-color: #f0f0f0;">';
    echo '<td colspan="9"><strong>Total Revenue</strong></td>';
    echo '<td colspan="4"><strong>LKR ' . number_format($total_revenue, 2) . '</strong></td>';
    echo '</tr>';
    
    echo '</table>';
    
} elseif ($report_type === 'financial') {
    echo '<h2>Financial Summary Report</h2>';
    echo '<p>Generated on: ' . date('Y-m-d H:i:s') . '</p>';
    
    // Calculate financial stats
    $total_orders = mysqli_num_rows($result);
    $total_revenue = 0;
    $completed_orders = 0;
    $cancelled_orders = 0;
    $paid_orders = 0;
    
    while ($row = mysqli_fetch_assoc($result)) {
        if ($row['total_price']) {
            $total_revenue += floatval($row['total_price']);
        }
        if ($row['status'] === 'Completed') $completed_orders++;
        if ($row['status'] === 'Cancelled') $cancelled_orders++;
        if ($row['payment_status'] === 'paid') $paid_orders++;
    }
    
    $avg_order_value = $total_orders > 0 ? $total_revenue / $total_orders : 0;
    
    echo '<table border="1" cellpadding="10" cellspacing="0">';
    echo '<tr><th>Metric</th><th>Value</th></tr>';
    echo '<tr><td>Total Orders</td><td>' . $total_orders . '</td></tr>';
    echo '<tr><td>Total Revenue</td><td>LKR ' . number_format($total_revenue, 2) . '</td></tr>';
    echo '<tr><td>Average Order Value</td><td>LKR ' . number_format($avg_order_value, 2) . '</td></tr>';
    echo '<tr><td>Completed Orders</td><td>' . $completed_orders . '</td></tr>';
    echo '<tr><td>Cancelled Orders</td><td>' . $cancelled_orders . '</td></tr>';
    echo '<tr><td>Paid Orders</td><td>' . $paid_orders . '</td></tr>';
    echo '<tr><td>Pending Payment</td><td>' . ($total_orders - $paid_orders) . '</td></tr>';
    echo '</table>';
    
} elseif ($report_type === 'status') {
    echo '<h2>Order Status Summary Report</h2>';
    echo '<p>Generated on: ' . date('Y-m-d H:i:s') . '</p>';
    
    $status_counts = [
        'Pending' => 0, 'Confirmed' => 0, 'Processing' => 0,
        'Ready' => 0, 'Completed' => 0, 'Cancelled' => 0
    ];
    
    while ($row = mysqli_fetch_assoc($result)) {
        if (isset($status_counts[$row['status']])) {
            $status_counts[$row['status']]++;
        }
    }
    
    echo '<table border="1" cellpadding="10" cellspacing="0">';
    echo '<tr><th>Order Status</th><th>Number of Orders</th><th>Percentage</th></tr>';
    
    $total = array_sum($status_counts);
    foreach ($status_counts as $status_name => $count) {
        if ($count > 0) {
            $percentage = $total > 0 ? round(($count / $total) * 100, 2) : 0;
            echo '<tr>';
            echo '<td>' . $status_name . '</td>';
            echo '<td>' . $count . '</td>';
            echo '<td>' . $percentage . '%</td>';
            echo '</tr>';
        }
    }
    
    echo '<tr style="background-color: #f0f0f0;">';
    echo '<td><strong>Total</strong></td>';
    echo '<td colspan="2"><strong>' . $total . '</strong></td>';
    echo '</tr>';
    echo '</table>';
}

// Add order details for all report types
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    echo '<br><br>';
    echo '<h3>Order Details</h3>';
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr>';
    echo '<th>Order ID</th><th>Customer</th><th>Date</th><th>Total Price</th><th>Status</th>';
    echo '</tr>';
    
    mysqli_data_seek($result, 0);
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['order_id'] . '</td>';
        echo '<td>' . $row['customer_name'] . '</td>';
        echo '<td>' . date('Y-m-d', strtotime($row['created_at'])) . '</td>';
        echo '<td>' . ($row['total_price'] ? 'LKR ' . number_format($row['total_price'], 2) : 'Pending') . '</td>';
        echo '<td>' . $row['status'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';
}

echo '</body>';
echo '</html>';

mysqli_close($conn);
?>