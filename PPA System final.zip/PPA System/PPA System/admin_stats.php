<?php
// admin_stats.php - Get dashboard statistics (Admin only)
session_start();
require_once 'db.php';

// Check if user is admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit();
}

try {
    $stats = [];
    
    // Total orders
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders");
    $stats['total'] = mysqli_fetch_assoc($result)['total'];
    
    // Pending review
    $result = mysqli_query($conn, "SELECT COUNT(*) as pending FROM orders WHERE status = 'Pending Review'");
    $stats['pending'] = mysqli_fetch_assoc($result)['pending'];
    
    // Price confirmed
    $result = mysqli_query($conn, "SELECT COUNT(*) as confirmed FROM orders WHERE status = 'Price Confirmed'");
    $stats['confirmed'] = mysqli_fetch_assoc($result)['confirmed'];
    
    // Ready for delivery
    $result = mysqli_query($conn, "SELECT COUNT(*) as ready FROM orders WHERE status IN ('Ready for Delivery', 'Out for Delivery')");
    $stats['ready'] = mysqli_fetch_assoc($result)['ready'];
    
    // Recent orders (last 10)
    $result = mysqli_query($conn, "SELECT * FROM orders ORDER BY created_at DESC LIMIT 10");
    $recent_orders = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $recent_orders[] = $row;
    }
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'recent_orders' => $recent_orders
    ]);
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>