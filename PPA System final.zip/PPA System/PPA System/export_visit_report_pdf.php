<?php
// export_visit_report_print.php - Printable version of visit laundry report (Save as PDF from browser)
session_start();
require_once 'visit_db.php';

// Check if user is admin
$is_admin = false;
if (isset($_SESSION['role']) && $_SESSION['role'] === 'Admin') {
    $is_admin = true;
}

if (!$is_admin) {
    die('Unauthorized access');
}

$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn, $_GET['date_to']) : '';
$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'all';
$report_type = isset($_GET['report_type']) ? mysqli_real_escape_string($conn, $_GET['report_type']) : 'orders';

$where_conditions = [];

if ($date_from && $date_to) {
    $where_conditions[] = "DATE(created_at) BETWEEN '$date_from' AND '$date_to'";
} elseif ($date_from) {
    $where_conditions[] = "DATE(created_at) >= '$date_from'";
} elseif ($date_to) {
    $where_conditions[] = "DATE(created_at) <= '$date_to'";
}

if ($status !== 'all') {
    $where_conditions[] = "status = '$status'";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

$sql = "SELECT * FROM visit_laundry_orders $where_clause ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);

// Get all orders for calculations
$orders = [];
$total_revenue = 0;
$status_counts = [
    'Pending' => 0, 'Confirmed' => 0, 'Processing' => 0,
    'Ready' => 0, 'Completed' => 0, 'Cancelled' => 0
];

while ($row = mysqli_fetch_assoc($result)) {
    if ($row['services_data']) {
        $row['items'] = json_decode($row['services_data'], true);
    }
    $orders[] = $row;
    
    if ($row['total_price'] && $row['total_price'] > 0) {
        $total_revenue += floatval($row['total_price']);
    }
    
    if (isset($status_counts[$row['status']])) {
        $status_counts[$row['status']]++;
    }
}

$total_orders = count($orders);
$avg_order_value = $total_orders > 0 ? round($total_revenue / $total_orders, 2) : 0;

// Calculate financial stats
$completed_orders = 0;
$cancelled_orders = 0;
$paid_orders = 0;
$revenue_by_status = [];

foreach ($orders as $order) {
    if ($order['status'] === 'Completed') $completed_orders++;
    if ($order['status'] === 'Cancelled') $cancelled_orders++;
    if ($order['payment_status'] === 'paid') $paid_orders++;
    
    $status_name = $order['status'];
    if (!isset($revenue_by_status[$status_name])) {
        $revenue_by_status[$status_name] = 0;
    }
    if ($order['total_price']) {
        $revenue_by_status[$status_name] += floatval($order['total_price']);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visit Laundry Report - Perfect Laundry</title>
    <style>
        @media print {
            body {
                margin: 0;
                padding: 20px;
            }
            .no-print {
                display: none;
            }
            .page-break {
                page-break-before: always;
            }
            .status-badge {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .report-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 30px;
        }
        
        .no-print {
            text-align: center;
            margin-bottom: 20px;
            position: sticky;
            top: 0;
            background: white;
            padding: 10px;
            z-index: 100;
            border-bottom: 2px solid #4CAF50;
        }
        
        .no-print button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 25px;
            cursor: pointer;
            border-radius: 5px;
            margin: 0 5px;
            font-size: 14px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .no-print button:hover {
            background: #45a049;
            transform: translateY(-2px);
        }
        
        .no-print .btn-close {
            background: #dc3545;
        }
        
        .no-print .btn-close:hover {
            background: #c82333;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #4CAF50;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header .subtitle {
            color: #7f8c8d;
            font-size: 14px;
        }
        
        .report-info {
            background: #e8f5e9;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            border-left: 4px solid #4CAF50;
        }
        
        .report-info p {
            margin: 5px 0;
            font-size: 14px;
        }
        
        .summary-box {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            border: 1px solid #dee2e6;
        }
        
        .summary-box h3 {
            color: #4CAF50;
            margin-bottom: 15px;
            border-left: 3px solid #4CAF50;
            padding-left: 10px;
        }
        
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .stat-item {
            background: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            border: 1px solid #dee2e6;
        }
        
        .stat-label {
            font-size: 11px;
            color: #6c757d;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .stat-value {
            font-size: 22px;
            font-weight: bold;
            color: #4CAF50;
        }
        
        h2 {
            color: #2c3e50;
            margin: 25px 0 15px 0;
            font-size: 18px;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 8px;
        }
        
        .table-responsive {
            overflow-x: auto;
            margin-bottom: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
            min-width: 900px;
        }
        
        th {
            background: #4CAF50;
            color: white;
            padding: 10px 8px;
            text-align: left;
            font-weight: 600;
            font-size: 11px;
        }
        
        td {
            border: 1px solid #dee2e6;
            padding: 8px;
            vertical-align: top;
        }
        
        tr:nth-child(even) {
            background: #f8f9fa;
        }
        
        .status-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: bold;
        }
        
        .status-pending { background: #fff3cd; color: #856404; }
        .status-confirmed { background: #d4edda; color: #155724; }
        .status-processing { background: #cce5ff; color: #004085; }
        .status-ready { background: #d1ecf1; color: #0c5460; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #dee2e6;
            font-size: 10px;
            color: #6c757d;
        }
        
        .progress-bar-container {
            background: #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
            margin: 5px 0;
        }
        
        .progress-bar {
            background: #4CAF50;
            height: 15px;
            border-radius: 10px;
        }
        
        @media (max-width: 768px) {
            .report-container {
                padding: 15px;
            }
            .summary-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="no-print">
        <button onclick="window.print()">🖨️ Print / Save as PDF</button>
        <button onclick="window.close()" class="btn-close">❌ Close</button>
    </div>
    
    <div class="report-container">
        <div class="header">
            <h1>🏬 Perfect Laundry</h1>
            <h2>Visit Laundry Report</h2>
            <div class="subtitle">Generated on: <?php echo date('F d, Y h:i A'); ?></div>
        </div>
        
        <div class="report-info">
            <p><strong>📅 Date Range:</strong> <?php echo ($date_from ? $date_from : 'All'); ?> to <?php echo ($date_to ? $date_to : 'All'); ?></p>
            <p><strong>📊 Status Filter:</strong> <?php echo ($status !== 'all' ? $status : 'All'); ?></p>
            <p><strong>📝 Report Type:</strong> <?php echo ucfirst($report_type); ?></p>
            <p><strong>👤 Generated By:</strong> <?php echo isset($_SESSION['username']) ? $_SESSION['username'] : 'Admin'; ?></p>
            <p><strong>📈 Total Orders Found:</strong> <?php echo $total_orders; ?></p>
        </div>
        
        <?php if ($report_type === 'orders'): ?>
            <!-- ORDERS REPORT -->
            <div class="summary-box">
                <h3>📈 Executive Summary</h3>
                <div class="summary-stats">
                    <div class="stat-item">
                        <div class="stat-label">Total Orders</div>
                        <div class="stat-value"><?php echo $total_orders; ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Total Revenue</div>
                        <div class="stat-value">LKR <?php echo number_format($total_revenue, 2); ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Average Order Value</div>
                        <div class="stat-value">LKR <?php echo number_format($avg_order_value, 2); ?></div>
                    </div>
                </div>
            </div>
            
            <h2>📋 Order Details</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            <th>Phone</th>
                            <th>Visit Date</th>
                            <th>Service Speed</th>
                            <th>Items</th>
                            <th>Weight</th>
                            <th>Total Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($orders)): ?>
                            <tr>
                                <td colspan="9" style="text-align: center;">No orders found for the selected criteria</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><strong><?php echo $order['order_id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                    <td><?php echo $order['phone']; ?></td>
                                    <td><?php echo $order['visit_date'] ? date('Y-m-d H:i', strtotime($order['visit_date'])) : 'N/A'; ?></td>
                                    <td><?php echo ucfirst($order['service_speed']); ?></td>
                                    <td style="text-align: center;"><?php echo $order['total_items'] ?: 0; ?></td>
                                    <td><?php echo $order['weight'] ? number_format($order['weight'], 2) . ' kg' : 'N/A'; ?></td>
                                    <td><strong><?php echo $order['total_price'] ? 'LKR ' . number_format($order['total_price'], 2) : 'Pending'; ?></strong></td>
                                    <td><span class="status-badge status-<?php echo strtolower($order['status']); ?>"><?php echo $order['status']; ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
        <?php elseif ($report_type === 'financial'): ?>
            <!-- FINANCIAL REPORT -->
            <div class="summary-box">
                <h3>💰 Financial Summary</h3>
                <div class="summary-stats">
                    <div class="stat-item">
                        <div class="stat-label">Total Orders</div>
                        <div class="stat-value"><?php echo $total_orders; ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Total Revenue</div>
                        <div class="stat-value">LKR <?php echo number_format($total_revenue, 2); ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Average Order Value</div>
                        <div class="stat-value">LKR <?php echo number_format($avg_order_value, 2); ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Completed Orders</div>
                        <div class="stat-value"><?php echo $completed_orders; ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Cancelled Orders</div>
                        <div class="stat-value"><?php echo $cancelled_orders; ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Paid Orders</div>
                        <div class="stat-value"><?php echo $paid_orders; ?></div>
                    </div>
                </div>
            </div>
            
            <h2>💰 Transaction Details</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            <th>Phone</th>
                            <th>Date</th>
                            <th>Total Price</th>
                            <th>Payment Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo $order['order_id']; ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo $order['phone']; ?></td>
                                <td><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></td>
                                <td><?php echo $order['total_price'] ? 'LKR ' . number_format($order['total_price'], 2) : 'Pending'; ?></td>
                                <td><?php echo $order['payment_status'] === 'paid' ? '✅ Paid' : '⏳ Pending'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
        <?php elseif ($report_type === 'status'): ?>
            <!-- STATUS REPORT -->
            <div class="summary-box">
                <h3>📊 Order Status Distribution</h3>
                <div class="summary-stats">
                    <?php foreach ($status_counts as $status_name => $count): ?>
                        <?php if ($count > 0): ?>
                            <div class="stat-item">
                                <div class="stat-label"><?php echo $status_name; ?></div>
                                <div class="stat-value"><?php echo $count; ?></div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <h2>📈 Status Distribution Details</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order Status</th>
                            <th>Number of Orders</th>
                            <th>Percentage</th>
                            <th>Visual</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($status_counts as $status_name => $count): ?>
                            <?php if ($count > 0): ?>
                                <?php $percentage = $total_orders > 0 ? round(($count / $total_orders) * 100, 2) : 0; ?>
                                <tr>
                                    <td><?php echo $status_name; ?></td>
                                    <td style="text-align: center;"><?php echo $count; ?></td>
                                    <td><?php echo $percentage; ?>%</td>
                                    <td style="width: 200px;">
                                        <div class="progress-bar-container">
                                            <div class="progress-bar" style="width: <?php echo min($percentage, 100); ?>%;"></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <tr style="background: #f0f0f0; font-weight: bold;">
                            <td>Total</td>
                            <td style="text-align: center;"><?php echo $total_orders; ?></td>
                            <td>100%</td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <h2>📋 All Orders by Status</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            <th>Phone</th>
                            <th>Visit Date</th>
                            <th>Total Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo $order['order_id']; ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo $order['phone']; ?></td>
                                <td><?php echo $order['visit_date'] ? date('Y-m-d', strtotime($order['visit_date'])) : 'N/A'; ?></td>
                                <td><?php echo $order['total_price'] ? 'LKR ' . number_format($order['total_price'], 2) : 'Pending'; ?></td>
                                <td><span class="status-badge status-<?php echo strtolower($order['status']); ?>"><?php echo $order['status']; ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <div class="footer">
            <p>Perfect Laundry System - Visit Laundry Report</p>
            <p>This report was generated automatically. For questions, please contact the administrator.</p>
            <p>Printed on: <?php echo date('F d, Y h:i A'); ?></p>
        </div>
    </div>
</body>
</html>

<?php mysqli_close($conn); ?>