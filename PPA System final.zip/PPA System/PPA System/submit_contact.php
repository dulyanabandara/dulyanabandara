<?php
// Turn on error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set content type
header('Content-Type: application/json');

// Create a log file to track errors
$log_file = 'debug_log.txt';
file_put_contents($log_file, date('Y-m-d H:i:s') . " - Request received\n", FILE_APPEND);

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'perfect_laundry';

// Create connection
$conn_review = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check connection
if (!$conn_review) {
    $error = mysqli_connect_error();
    file_put_contents($log_file, "Connection failed: $error\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $error]);
    exit;
}

file_put_contents($log_file, "Database connected successfully\n", FILE_APPEND);

// Get POST data
$input = file_get_contents('php://input');
file_put_contents($log_file, "Raw input: $input\n", FILE_APPEND);

$data = json_decode($input, true);

if (!$data) {
    file_put_contents($log_file, "Invalid JSON data\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Invalid data format']);
    exit;
}

$name = mysqli_real_escape_string($conn_review, trim($data['name'] ?? ''));
$email = mysqli_real_escape_string($conn_review, trim($data['email'] ?? ''));
$phone = mysqli_real_escape_string($conn_review, trim($data['phone'] ?? ''));
$message = mysqli_real_escape_string($conn_review, trim($data['message'] ?? ''));

file_put_contents($log_file, "Processed data - Name: $name, Email: $email\n", FILE_APPEND);

// Validate
if (empty($name) || empty($email) || empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Please fill in all required fields']);
    exit;
}

// Check if table exists
$table_check = mysqli_query($conn_review, "SHOW TABLES LIKE 'feedback'");
if (mysqli_num_rows($table_check) == 0) {
    file_put_contents($log_file, "Feedback table does not exist!\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Database table not found. Please run the SQL setup.']);
    exit;
}

// Insert into database
$query = "INSERT INTO feedback (customer_name, customer_email, phone, message, type, status, created_at) 
          VALUES ('$name', '$email', '$phone', '$message', 'inquiry', 'pending', NOW())";

file_put_contents($log_file, "Query: $query\n", FILE_APPEND);

if (mysqli_query($conn_review, $query)) {
    file_put_contents($log_file, "Insert successful\n", FILE_APPEND);
    echo json_encode(['success' => true, 'message' => 'Thank you for your message! We will get back to you soon.']);
} else {
    $error = mysqli_error($conn_review);
    file_put_contents($log_file, "Insert failed: $error\n", FILE_APPEND);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $error]);
}

mysqli_close($conn_review);
?>