<?php
session_start();
require_once 'config_review.php';

// Get statistics with null handling
$total_reviews = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT COUNT(*) as count FROM feedback WHERE type='review'"))['count'] ?? 0;

$avg_rating_result = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT AVG(rating) as avg FROM feedback WHERE type='review' AND rating IS NOT NULL AND status='approved'"));
$avg_rating = isset($avg_rating_result['avg']) && $avg_rating_result['avg'] !== null ? round((float)$avg_rating_result['avg'], 1) : 0;

$pending_count = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT COUNT(*) as count FROM feedback WHERE status='pending'"))['count'] ?? 0;
$five_star_count = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT COUNT(*) as count FROM feedback WHERE rating=5 AND type='review'"))['count'] ?? 0;
$new_this_month = mysqli_fetch_assoc(mysqli_query($conn_review, "SELECT COUNT(*) as count FROM feedback WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())"))['count'] ?? 0;
$five_star_percent = $total_reviews > 0 ? round(($five_star_count / $total_reviews) * 100) : 0;

// Get filter parameters
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn_review, $_GET['search']) : '';
$status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn_review, $_GET['status']) : '';
$rating_filter = isset($_GET['rating']) ? intval($_GET['rating']) : 0;
$date_from = isset($_GET['date_from']) ? mysqli_real_escape_string($conn_review, $_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? mysqli_real_escape_string($conn_review, $_GET['date_to']) : '';

// Build query
$where_conditions = [];
if (!empty($search)) {
    $where_conditions[] = "(customer_name LIKE '%$search%' OR message LIKE '%$search%')";
}
if (!empty($status_filter) && $status_filter != 'all') {
    $where_conditions[] = "status='$status_filter'";
}
if ($rating_filter > 0) {
    $where_conditions[] = "rating=$rating_filter";
}
if (!empty($date_from)) {
    $where_conditions[] = "DATE(created_at) >= '$date_from'";
}
if (!empty($date_to)) {
    $where_conditions[] = "DATE(created_at) <= '$date_to'";
}
$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// Get reviews
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$total_query = "SELECT COUNT(*) as count FROM feedback $where_clause";
$total_result = mysqli_query($conn_review, $total_query);
$total_records = mysqli_fetch_assoc($total_result)['count'] ?? 0;
$total_pages = $total_records > 0 ? ceil($total_records / $limit) : 1;

$query = "SELECT * FROM feedback $where_clause ORDER BY created_at DESC LIMIT $offset, $limit";
$reviews_result = mysqli_query($conn_review, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reviews - Perfect Laundry Admin</title>
    <link rel="stylesheet" href="admin_dashboard.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== REVIEW MANAGEMENT STYLES ===== */
        
        /* Reviews Header */
        .reviews-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .reviews-title h2 {
            font-size: 22px;
            color: white;
            margin-bottom: 5px;
            position: relative;
            display: inline-block;
        }
        
        .reviews-title h2::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--gradient-green);
            border-radius: 2px;
        }
        
        .reviews-title p {
            color: var(--text-muted);
            font-size: 14px;
            margin-top: 10px;
        }
        
        /* Buttons */
        .btn-primary {
            background: var(--gradient-green);
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            font-size: 14px;
            box-shadow: 0 4px 15px rgba(111, 207, 151, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(39, 174, 96, 0.4);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 10px 20px;
            border-radius: 30px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: rgba(239, 68, 68, 0.8);
            border: none;
            padding: 10px 20px;
            border-radius: 30px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .btn-danger:hover {
            background: #EF4444;
            transform: translateY(-2px);
        }
        
        /* Filter Bar - Updated for better alignment */
.filter-bar {
    background: rgba(16, 42, 65, 0.5);
    border-radius: 15px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    padding: 20px;
    margin-bottom: 25px;
}

.filter-row {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: center;
    margin-bottom: 20px;
}

.action-row {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    align-items: center;
    justify-content: flex-end;
    padding-top: 15px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.search-box {
    flex: 2;
    min-width: 200px;
    display: flex;
    align-items: center;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
    padding: 0 15px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.3s;
}

.search-box:focus-within {
    border-color: var(--luminous-green);
    background: rgba(255, 255, 255, 0.1);
}

.search-box i {
    color: var(--text-muted);
    margin-right: 10px;
}

.search-box input {
    background: transparent;
    border: none;
    padding: 12px 0;
    color: white;
    width: 100%;
    outline: none;
    font-family: 'Poppins', sans-serif;
}

.search-box input::placeholder {
    color: var(--text-muted);
}

.filter-select {
    flex: 1;
    min-width: 140px;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    padding: 12px 15px;
    color: white;
    outline: none;
    cursor: pointer;
    font-family: 'Poppins', sans-serif;
    transition: all 0.3s;
}

.filter-select:hover, .filter-select:focus {
    border-color: var(--luminous-green);
    background: rgba(255, 255, 255, 0.1);
}

.filter-select option {
    background: var(--bg-dark-light);
    color: white;
}

.date-range {
    flex: 1;
    min-width: 260px;
    display: flex;
    align-items: center;
    gap: 10px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
    padding: 0 15px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

.date-input {
    flex: 1;
    background: transparent;
    border: none;
    padding: 12px 0;
    color: white;
    outline: none;
    font-family: 'Poppins', sans-serif;
    font-size: 13px;
    cursor: pointer;
}

.date-input::-webkit-calendar-picker-indicator {
    filter: invert(1);
    cursor: pointer;
}

.date-arrow {
    color: var(--text-muted);
    font-size: 14px;
}

.clear-filters {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    padding: 12px 18px;
    color: var(--text-muted);
    cursor: pointer;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Poppins', sans-serif;
}

.clear-filters:hover {
    background: rgba(255, 255, 255, 0.15);
    color: white;
    border-color: var(--luminous-green);
}

/* Buttons */
.btn-primary, .btn-secondary, .btn-danger {
    padding: 10px 24px;
    border-radius: 30px;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
    font-size: 14px;
    font-family: 'Poppins', sans-serif;
}

.btn-primary {
    background: var(--gradient-green);
    border: none;
    color: white;
    box-shadow: 0 4px 15px rgba(111, 207, 151, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(39, 174, 96, 0.4);
}

.btn-secondary {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    color: white;
}

.btn-secondary:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
}

        
        /* Rating Stars */
        .rating-stars {
            color: #FFB800;
            font-size: 13px;
            white-space: nowrap;
        }
        
        .rating-stars i {
            margin-right: 2px;
        }
        
        .rating-number {
            margin-left: 5px;
            color: var(--text-muted);
            font-size: 11px;
        }
        
        /* Status Badges */
        .status-approved {
            background: rgba(111, 207, 151, 0.2);
            color: var(--luminous-green);
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            white-space: nowrap;
        }
        
        .status-pending {
            background: rgba(245, 158, 11, 0.2);
            color: #F59E0B;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            white-space: nowrap;
        }
        
        .status-rejected {
            background: rgba(239, 68, 68, 0.2);
            color: #EF4444;
            padding: 5px 12px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
            white-space: nowrap;
        }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: nowrap;
        }
        
        .action-btn {
            width: 30px;
            height: 30px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 12px;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
        }
        
        .action-btn.approve:hover {
            background: var(--luminous-green);
            border-color: var(--luminous-green);
        }
        
        .action-btn.reject:hover {
            background: #EF4444;
            border-color: #EF4444;
        }
        
        .action-btn.delete:hover {
            background: #dc2626;
            border-color: #dc2626;
        }
        
        .action-btn.view:hover {
            background: #3B82F6;
            border-color: #3B82F6;
        }
        
        .action-btn.reply:hover {
            background: #8B5CF6;
            border-color: #8B5CF6;
        }
        
        /* Review Summary Cards */
        .review-summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background: rgba(16, 42, 65, 0.5);
            backdrop-filter: blur(10px);
            padding: 20px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transition: all 0.3s;
        }
        
        .summary-card:hover {
            transform: translateY(-5px);
            border-color: rgba(111, 207, 151, 0.3);
        }
        
        .summary-card h4 {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 10px;
            font-weight: 400;
        }
        
        .summary-card .number {
            font-size: 32px;
            font-weight: 700;
            background: var(--gradient-green);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1.2;
        }
        
        .summary-card .sub-text {
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 5px;
        }
        
        /* Average Rating Display */
        .avg-rating {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 5px;
        }
        
        .avg-rating .stars {
            color: #FFB800;
            font-size: 14px;
        }
        
        .avg-rating .score {
            font-size: 24px;
            font-weight: 600;
            color: white;
        }
        
        /* Customer Info */
        .customer-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .customer-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--gradient-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 12px;
            flex-shrink: 0;
        }
        
        .customer-details {
            line-height: 1.2;
        }
        
        .customer-name {
            font-weight: 500;
            color: white;
            font-size: 13px;
        }
        
        .customer-email {
            font-size: 10px;
            color: var(--text-muted);
        }
        
        /* Review Content */
        .review-content {
            max-width: 200px;
        }
        
        .review-content p {
            margin: 0;
            color: var(--text-muted);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 13px;
        }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: flex-end;
            gap: 5px;
            margin-top: 20px;
        }
        
        .page-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            cursor: pointer;
            transition: all 0.2s;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            text-decoration: none;
        }
        
        .page-btn:hover,
        .page-btn.active {
            background: var(--gradient-green);
            color: white;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: var(--bg-dark-light);
            border-radius: 20px;
            padding: 25px;
            max-width: 450px;
            width: 90%;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .modal-header h3 {
            color: white;
            margin: 0;
            font-size: 18px;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 24px;
            cursor: pointer;
            line-height: 1;
        }
        
        .modal-close:hover {
            color: white;
        }
        
        .review-detail {
            background: rgba(0, 0, 0, 0.3);
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 15px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .review-detail .rating {
            color: #FFB800;
            margin-bottom: 8px;
            font-size: 14px;
        }
        
        .review-detail .comment {
            color: white;
            line-height: 1.5;
            font-size: 13px;
            margin-bottom: 8px;
        }
        
        .review-detail .customer {
            color: var(--text-muted);
            font-size: 12px;
        }
        
        .reply-input {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
            font-family: 'Poppins', sans-serif;
            resize: vertical;
            outline: none;
            font-size: 13px;
        }
        
        .reply-input:focus {
            border-color: var(--luminous-green);
        }
        
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            margin-top: 15px;
        }
        
        .modal-footer button {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
        }
        
        .btn-cancel {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .btn-cancel:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .btn-send {
            background: var(--gradient-green);
            color: white;
        }
        
        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(111, 207, 151, 0.3);
        }
        
        /* Checkbox styling */
        input[type="checkbox"] {
            width: 16px;
            height: 16px;
            cursor: pointer;
            accent-color: var(--luminous-green);
        }
        
        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table th, table td {
            padding: 12px 10px;
            font-size: 13px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        table th {
            text-align: left;
            color: var(--text-muted);
            font-weight: 500;
        }
        
        table tr:hover {
            background: rgba(255, 255, 255, 0.02);
        }
        
        /* Toast notification */
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--gradient-green);
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 1001;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        /* Report Modal Styles */
        .report-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(8px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }
        
        .report-modal.active {
            display: flex;
        }
        
        .report-modal-content {
            background: var(--bg-dark-light);
            border-radius: 25px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            border: 1px solid rgba(255, 255, 255, 0.15);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
        }
        
        .report-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .report-modal-header h3 {
            color: white;
            font-size: 1.5rem;
            margin: 0;
        }
        
        .report-modal-header h3 i {
            background: var(--gradient-green);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-right: 10px;
        }
        
        .close-report-modal {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 28px;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .close-report-modal:hover {
            color: white;
        }
        
        .report-form-group {
            margin-bottom: 20px;
        }
        
        .report-form-group label {
            display: block;
            color: white;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
        }
        
        .report-form-group select,
        .report-form-group input {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            color: white;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            outline: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .report-form-group select:focus,
        .report-form-group input:focus {
            border-color: var(--luminous-green);
        }
        
        .report-form-group option {
            background: var(--bg-dark-light);
        }
        
        .date-range-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .report-type-buttons {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }
        
        .report-type-btn {
            flex: 1;
            padding: 12px;
            background: rgba(255, 255, 255, 0.08);
            border: 2px solid rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-family: 'Poppins', sans-serif;
        }
        
        .report-type-btn i {
            font-size: 18px;
        }
        
        .report-type-btn.active {
            background: var(--gradient-green);
            border-color: var(--luminous-green);
            box-shadow: 0 5px 15px rgba(111, 207, 151, 0.3);
        }
        
        .report-type-btn:hover:not(.active) {
            background: rgba(255, 255, 255, 0.15);
        }
        
        .report-buttons {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }
        
        .btn-generate {
            flex: 2;
            background: var(--gradient-green);
            border: none;
            padding: 14px;
            border-radius: 12px;
            color: white;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .btn-generate:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(111, 207, 151, 0.4);
        }
        
        .btn-cancel-report {
            flex: 1;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 14px;
            border-radius: 12px;
            color: white;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-cancel-report:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        /* Loading Spinner */
        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 0.6s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-state i {
            font-size: 64px;
            color: var(--text-muted);
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            color: white;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: var(--text-muted);
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .review-summary-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 992px) {
            .filter-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-box, .filter-select, .date-range {
                width: 100%;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 900px;
            }
        }
        
        @media (max-width: 768px) {
            .review-summary-grid {
                grid-template-columns: 1fr;
            }
            
            .reviews-header {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .reviews-actions {
                width: 100%;
                display: flex;
                gap: 10px;
            }
            
            .btn-primary, .btn-secondary, .btn-danger {
                flex: 1;
                justify-content: center;
                padding: 10px 15px;
                font-size: 13px;
            }
        }
        
        @media (max-width: 480px) {
            .reviews-actions {
                flex-direction: column;
            }
            
            .report-type-buttons {
                flex-direction: column;
            }
            
            .date-range-group {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Perfect Laundry</h2>
                <p>Admin Panel</p>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="admin-dashboard.html"><span class="icon"><i class="fas fa-chart-pie"></i></span> Dashboard</a></li>
                    <li><a href="manage_products.php"><span class="icon"><i class="fas fa-box"></i></span> Manage Products</a></li>
                    <li><a href="visit_admin.html"><span class="icon"><i class="fas fa-shopping-cart"></i></span> Manage Orders</a></li>
                    <li><a href="manage_customers.php"><span class="icon"><i class="fas fa-users"></i></span> Manage Customers</a></li>
                    <li><a href="DeliveryAdmin.html"><span class="icon"><i class="fas fa-clock"></i></span> Delivery Status</a></li>
                    <li><a href="manage_reviews.php" class="active"><span class="icon"><i class="fas fa-star"></i></span> Manage Reviews</a></li>
                    <li><a href="settings.php"><span class="icon"><i class="fas fa-cog"></i></span> Settings</a></li>
                    <li><a href="logout.php"><span class="icon"><i class="fas fa-sign-out-alt"></i></span> Logout</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main-content">
            <header class="main-header">
                <h1>Manage Customer Reviews</h1>
                <div class="logo-container">
                    <div class="dashboard-logo">
                        <i class="fas fa-star"></i> Reviews
                    </div>
                </div>
            </header>

            <!-- Review Summary Cards -->
            <div class="review-summary-grid">
                <div class="summary-card">
                    <h4><i class="fas fa-comments"></i> Total Reviews</h4>
                    <div class="number"><?php echo number_format($total_reviews); ?></div>
                    <div class="sub-text"><i class="fas fa-calendar-alt"></i> +<?php echo $new_this_month; ?> this month</div>
                </div>
                <div class="summary-card">
                    <h4><i class="fas fa-star"></i> Average Rating</h4>
                    <div class="avg-rating">
                        <span class="score"><?php echo $avg_rating; ?></span>
                        <span class="stars">
                            <?php
                            $full_stars = floor($avg_rating);
                            $half_star = ($avg_rating - $full_stars) >= 0.5;
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $full_stars) {
                                    echo '<i class="fas fa-star"></i>';
                                } elseif ($half_star && $i == $full_stars + 1) {
                                    echo '<i class="fas fa-star-half-alt"></i>';
                                    $half_star = false;
                                } else {
                                    echo '<i class="far fa-star"></i>';
                                }
                            }
                            ?>
                        </span>
                    </div>
                    <div class="sub-text">out of 5 stars</div>
                </div>
                <div class="summary-card">
                    <h4><i class="fas fa-clock"></i> Pending Approval</h4>
                    <div class="number"><?php echo $pending_count; ?></div>
                    <div class="sub-text">reviews awaiting moderation</div>
                </div>
                <div class="summary-card">
                    <h4><i class="fas fa-trophy"></i> 5-Star Reviews</h4>
                    <div class="number"><?php echo number_format($five_star_count); ?></div>
                    <div class="sub-text"><?php echo $five_star_percent; ?>% of total reviews</div>
                </div>
            </div>

            <!-- Reviews Management Section -->
            <section class="content-card">
                <div class="reviews-header">
                    <div class="reviews-title">
                        <h2>All Customer Reviews</h2>
                        <p>Manage, approve, and respond to customer feedback</p>
                    </div>
                    <div class="reviews-actions">
                        <button class="btn-secondary" onclick="openReportModal()">
                            <i class="fas fa-chart-line"></i> Generate Report
                        </button>
                        <button class="btn-primary" onclick="bulkApprove()">
                            <i class="fas fa-check-double"></i> Bulk Approve
                        </button>
                    </div>
                </div>

               <!-- Filter Bar -->
<div class="filter-bar">
    <div class="filter-row">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Search by customer name or review..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        
        <select class="filter-select" id="statusFilter">
            <option value="all" <?php echo $status_filter == '' || $status_filter == 'all' ? 'selected' : ''; ?>>📋 All Status</option>
            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>⏳ Pending</option>
            <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>✅ Approved</option>
            <option value="rejected" <?php echo $status_filter == 'rejected' ? 'selected' : ''; ?>>❌ Rejected</option>
        </select>
        
        <select class="filter-select" id="ratingFilter">
            <option value="0" <?php echo $rating_filter == 0 ? 'selected' : ''; ?>>⭐ All Ratings</option>
            <option value="5" <?php echo $rating_filter == 5 ? 'selected' : ''; ?>>⭐⭐⭐⭐⭐ 5 Stars</option>
            <option value="4" <?php echo $rating_filter == 4 ? 'selected' : ''; ?>>⭐⭐⭐⭐ 4 Stars</option>
            <option value="3" <?php echo $rating_filter == 3 ? 'selected' : ''; ?>>⭐⭐⭐ 3 Stars</option>
            <option value="2" <?php echo $rating_filter == 2 ? 'selected' : ''; ?>>⭐⭐ 2 Stars</option>
            <option value="1" <?php echo $rating_filter == 1 ? 'selected' : ''; ?>>⭐ 1 Star</option>
        </select>
        
        <div class="date-range">
            <input type="date" class="date-input" id="dateFrom" value="<?php echo htmlspecialchars($date_from); ?>">
            <span class="date-arrow">→</span>
            <input type="date" class="date-input" id="dateTo" value="<?php echo htmlspecialchars($date_to); ?>">
        </div>
        
        <button class="clear-filters" onclick="clearAllFilters()" title="Clear all filters">
            <i class="fas fa-times-circle"></i> Clear
        </button>
    </div>
    
 
                <!-- Reviews Table -->
                <div class="table-container">
                    <?php if (mysqli_num_rows($reviews_result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th>Customer</th>
                                <th>Rating</th>
                                <th>Review</th>
                                <th>Date</th>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($reviews_result)): ?>
                                <tr data-id="<?php echo $row['id']; ?>">
                                    <td><input type="checkbox" class="review-checkbox" value="<?php echo $row['id']; ?>"></td>
                                    <td>
                                        <div class="customer-info">
                                            <div class="customer-avatar">
                                                <?php echo strtoupper(substr($row['customer_name'], 0, 2)); ?>
                                            </div>
                                            <div class="customer-details">
                                                <div class="customer-name"><?php echo htmlspecialchars($row['customer_name']); ?></div>
                                                <div class="customer-email"><?php echo htmlspecialchars($row['customer_email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="rating-stars">
                                            <?php
                                            $rating = intval($row['rating']);
                                            for ($i = 1; $i <= 5; $i++) {
                                                if ($i <= $rating) {
                                                    echo '<i class="fas fa-star"></i>';
                                                } else {
                                                    echo '<i class="far fa-star"></i>';
                                                }
                                            }
                                            ?>
                                            <span class="rating-number"><?php echo $rating; ?>.0</span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="review-content">
                                            <p title="<?php echo htmlspecialchars($row['message']); ?>">
                                                <?php echo htmlspecialchars(substr($row['message'], 0, 60)); ?><?php echo strlen($row['message']) > 60 ? '...' : ''; ?>
                                            </p>
                                        </div>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['service_type'] ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if ($row['status'] == 'approved'): ?>
                                            <span class="status-approved"><i class="fas fa-check-circle"></i> Approved</span>
                                        <?php elseif ($row['status'] == 'pending'): ?>
                                            <span class="status-pending"><i class="fas fa-hourglass-half"></i> Pending</span>
                                        <?php else: ?>
                                            <span class="status-rejected"><i class="fas fa-times-circle"></i> Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="action-btn view" title="View Details" onclick="viewReview(<?php echo $row['id']; ?>)"><i class="fas fa-eye"></i></button>
                                            <button class="action-btn reply" title="Reply to Customer" onclick="replyToReview(<?php echo $row['id']; ?>)"><i class="fas fa-reply"></i></button>
                                            <?php if ($row['status'] != 'approved'): ?>
                                                <button class="action-btn approve" title="Approve Review" onclick="approveReview(<?php echo $row['id']; ?>)"><i class="fas fa-check"></i></button>
                                            <?php endif; ?>
                                            <?php if ($row['status'] != 'rejected'): ?>
                                                <button class="action-btn reject" title="Reject Review" onclick="rejectReview(<?php echo $row['id']; ?>)"><i class="fas fa-times"></i></button>
                                            <?php endif; ?>
                                            <button class="action-btn delete" title="Delete Permanently" onclick="deleteReview(<?php echo $row['id']; ?>)"><i class="fas fa-trash"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Reviews Found</h3>
                        <p>No reviews match your current filters. Try adjusting your search criteria.</p>
                        <button class="btn-secondary" onclick="clearAllFilters()" style="margin-top: 15px;">
                            <i class="fas fa-eraser"></i> Clear All Filters
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if ($total_records > 0): ?>
                <div class="pagination">
                    <div class="pagination-info" style="color: var(--text-muted); font-size: 12px; margin-right: auto;">
                        <i class="fas fa-list"></i> Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $limit, $total_records); ?> of <?php echo $total_records; ?> reviews
                    </div>
                    <div class="pagination-controls" style="display: flex; gap: 5px;">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page-1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&rating=<?php echo $rating_filter; ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
                        <?php endif; ?>
                        
                        <?php
                        $start_page = max(1, $page - 2);
                        $end_page = min($total_pages, $page + 2);
                        for ($i = $start_page; $i <= $end_page; $i++):
                        ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&rating=<?php echo $rating_filter; ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>" class="page-btn <?php echo $page == $i ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page+1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>&rating=<?php echo $rating_filter; ?>&date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <!-- Reply Modal -->
    <div class="modal" id="replyModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-reply-all"></i> Reply to Review</h3>
                <button class="modal-close" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <div class="review-detail" id="reviewDetail"></div>
                <textarea class="reply-input" id="replyText" rows="4" placeholder="Type your reply here... The customer will receive your response via email."></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn-cancel" onclick="closeModal()">Cancel</button>
                <button class="btn-send" onclick="sendReply()"><i class="fas fa-paper-plane"></i> Send Reply</button>
            </div>
        </div>
    </div>

    <!-- Report Generation Modal -->
    <div class="report-modal" id="reportModal">
        <div class="report-modal-content">
            <div class="report-modal-header">
                <h3><i class="fas fa-chart-line"></i> Generate Report</h3>
                <button class="close-report-modal" onclick="closeReportModal()">&times;</button>
            </div>
            
            <div class="report-form-group">
                <label><i class="fas fa-file-alt"></i> Report Type</label>
                <div class="report-type-buttons">
                    <button type="button" class="report-type-btn active" data-type="summary" onclick="selectReportType('summary')">
                        <i class="fas fa-chart-pie"></i> Summary
                    </button>
                    <button type="button" class="report-type-btn" data-type="detailed" onclick="selectReportType('detailed')">
                        <i class="fas fa-table-list"></i> Detailed
                    </button>
                    <button type="button" class="report-type-btn" data-type="rating" onclick="selectReportType('rating')">
                        <i class="fas fa-star"></i> Analysis
                    </button>
                </div>
            </div>
            
            <div class="report-form-group">
                <label><i class="fas fa-calendar-alt"></i> Date Range</label>
                <div class="date-range-group">
                    <input type="date" id="report_date_from" placeholder="From Date">
                    <input type="date" id="report_date_to" placeholder="To Date">
                </div>
            </div>
            
            <div class="report-form-group">
                <label><i class="fas fa-star"></i> Rating Filter (Optional)</label>
                <select id="report_rating_filter">
                    <option value="0">All Ratings</option>
                    <option value="5">⭐⭐⭐⭐⭐ 5 Stars Only</option>
                    <option value="4">⭐⭐⭐⭐ 4 Stars Only</option>
                    <option value="3">⭐⭐⭐ 3 Stars Only</option>
                    <option value="2">⭐⭐ 2 Stars Only</option>
                    <option value="1">⭐ 1 Star Only</option>
                </select>
            </div>
            
            <div class="report-form-group">
                <label><i class="fas fa-filter"></i> Status Filter</label>
                <select id="report_status_filter">
                    <option value="all">All Status</option>
                    <option value="approved">✅ Approved Only</option>
                    <option value="pending">⏳ Pending Only</option>
                    <option value="rejected">❌ Rejected Only</option>
                </select>
            </div>
            
            <div class="report-buttons">
                <button class="btn-cancel-report" onclick="closeReportModal()">Cancel</button>
                <button class="btn-generate" onclick="generateReport()">
                    <i class="fas fa-download"></i> Generate & Download
                </button>
            </div>
        </div>
    </div>

    <script>
        let currentReviewId = null;
        
        function showToast(message, isError = false) {
            // Remove existing toast
            const existingToast = document.querySelector('.toast');
            if (existingToast) existingToast.remove();
            
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.style.background = isError ? 'linear-gradient(135deg, #EF4444, #DC2626)' : 'linear-gradient(135deg, #6FCF97, #27AE60)';
            toast.innerHTML = `<i class="fas ${isError ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i> ${message}`;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }
        
        function viewReview(id) {
            showToast('Loading review details...');
            fetch('review_actions.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_review&id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const r = data.review;
                    let stars = '';
                    for (let i = 1; i <= 5; i++) {
                        stars += i <= r.rating ? '★' : '☆';
                    }
                    alert(`📝 REVIEW DETAILS\n\n👤 Customer: ${r.customer_name}\n📧 Email: ${r.customer_email}\n⭐ Rating: ${stars} (${r.rating}/5)\n📅 Date: ${r.created_at}\n🛠️ Service: ${r.service_type || 'N/A'}\n📋 Status: ${r.status}\n\n💬 Review:\n"${r.message}"\n\n${r.admin_reply ? `📨 Admin Reply:\n"${r.admin_reply}"` : 'No admin reply yet.'}`);
                } else {
                    showToast('Error loading review details', true);
                }
            })
            .catch(() => showToast('Failed to load review', true));
        }
        
        function replyToReview(id) {
            currentReviewId = id;
            fetch('review_actions.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=get_review&id=${id}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const r = data.review;
                    let stars = '';
                    for (let i = 1; i <= 5; i++) {
                        stars += i <= r.rating ? '★' : '☆';
                    }
                    document.getElementById('reviewDetail').innerHTML = `
                        <div class="rating">${stars} (${r.rating}/5)</div>
                        <div class="comment">"${escapeHtml(r.message)}"</div>
                        <div class="customer">— ${escapeHtml(r.customer_name)} • ${r.created_at}</div>
                    `;
                    document.getElementById('replyModal').classList.add('active');
                    document.getElementById('replyText').focus();
                } else {
                    showToast('Error loading review', true);
                }
            })
            .catch(() => showToast('Failed to load review', true));
        }
        
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function closeModal() {
            document.getElementById('replyModal').classList.remove('active');
            document.getElementById('replyText').value = '';
            currentReviewId = null;
        }
        
        function sendReply() {
            const reply = document.getElementById('replyText').value.trim();
            if (!reply) {
                showToast('Please enter a reply message', true);
                document.getElementById('replyText').focus();
                return;
            }
            
            const sendBtn = document.querySelector('#replyModal .btn-send');
            const originalText = sendBtn.innerHTML;
            sendBtn.innerHTML = '<span class="loading-spinner"></span> Sending...';
            sendBtn.disabled = true;
            
            fetch('review_actions.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=reply&id=${currentReviewId}&reply=${encodeURIComponent(reply)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('✅ Reply sent successfully!');
                    closeModal();
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showToast(data.message || 'Failed to send reply', true);
                }
            })
            .catch(() => showToast('Error sending reply', true))
            .finally(() => {
                sendBtn.innerHTML = originalText;
                sendBtn.disabled = false;
            });
        }
        
        function approveReview(id) {
            if (confirm('✅ Approve this review?\n\nApproved reviews will be visible on the website.')) {
                const btn = event.target.closest('.action-btn');
                if (btn) {
                    btn.style.opacity = '0.5';
                    btn.disabled = true;
                }
                
                fetch('review_actions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=approve&id=${id}`
                })
                .then(response => response.json())
                .then(data => {
                    showToast(data.message);
                    setTimeout(() => location.reload(), 800);
                })
                .catch(() => showToast('Error approving review', true));
            }
        }
        
        function rejectReview(id) {
            if (confirm('❌ Reject this review?\n\nRejected reviews will not be shown on the website.')) {
                fetch('review_actions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=reject&id=${id}`
                })
                .then(response => response.json())
                .then(data => {
                    showToast(data.message);
                    setTimeout(() => location.reload(), 800);
                })
                .catch(() => showToast('Error rejecting review', true));
            }
        }
        
        function deleteReview(id) {
            if (confirm('⚠️ PERMANENT DELETE ⚠️\n\nAre you absolutely sure you want to delete this review permanently?\nThis action cannot be undone!')) {
                fetch('review_actions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=delete&id=${id}`
                })
                .then(response => response.json())
                .then(data => {
                    showToast(data.message);
                    setTimeout(() => location.reload(), 800);
                })
                .catch(() => showToast('Error deleting review', true));
            }
        }
        
        function bulkApprove() {
            const selected = document.querySelectorAll('.review-checkbox:checked');
            if (selected.length === 0) {
                showToast('Please select at least one review to approve', true);
                return;
            }
            if (confirm(`Approve ${selected.length} selected review${selected.length > 1 ? 's' : ''}?`)) {
                const ids = Array.from(selected).map(cb => cb.value);
                
                const approveBtn = document.querySelector('.btn-primary');
                const originalText = approveBtn.innerHTML;
                approveBtn.innerHTML = '<span class="loading-spinner"></span> Approving...';
                approveBtn.disabled = true;
                
                fetch('review_actions.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=bulk_approve&ids=${JSON.stringify(ids)}`
                })
                .then(response => response.json())
                .then(data => {
                    showToast(data.message);
                    setTimeout(() => location.reload(), 1000);
                })
                .catch(() => showToast('Error approving reviews', true))
                .finally(() => {
                    approveBtn.innerHTML = originalText;
                    approveBtn.disabled = false;
                });
            }
        }
        
        function clearAllFilters() {
            window.location.href = window.location.pathname;
        }
        
        // Select All checkbox
        document.getElementById('selectAll')?.addEventListener('change', function(e) {
            document.querySelectorAll('.review-checkbox').forEach(cb => cb.checked = e.target.checked);
        });
        
        // Filter with debounce
        let filterTimeout;
        function applyFilters() {
            const search = document.getElementById('searchInput').value;
            const status = document.getElementById('statusFilter').value;
            const rating = document.getElementById('ratingFilter').value;
            const dateFrom = document.getElementById('dateFrom').value;
            const dateTo = document.getElementById('dateTo').value;
            
            const url = new URL(window.location.href);
            if (search) url.searchParams.set('search', search);
            else url.searchParams.delete('search');
            if (status !== 'all') url.searchParams.set('status', status);
            else url.searchParams.delete('status');
            if (rating != 0) url.searchParams.set('rating', rating);
            else url.searchParams.delete('rating');
            if (dateFrom) url.searchParams.set('date_from', dateFrom);
            else url.searchParams.delete('date_from');
            if (dateTo) url.searchParams.set('date_to', dateTo);
            else url.searchParams.delete('date_to');
            url.searchParams.set('page', '1');
            window.location.href = url.toString();
        }
        
        document.getElementById('searchInput')?.addEventListener('input', function() {
            clearTimeout(filterTimeout);
            filterTimeout = setTimeout(applyFilters, 500);
        });
        document.getElementById('statusFilter')?.addEventListener('change', applyFilters);
        document.getElementById('ratingFilter')?.addEventListener('change', applyFilters);
        document.getElementById('dateFrom')?.addEventListener('change', applyFilters);
        document.getElementById('dateTo')?.addEventListener('change', applyFilters);
        
        // Close modals on outside click
        window.onclick = function(event) {
            const replyModal = document.getElementById('replyModal');
            if (event.target === replyModal) closeModal();
            
            const reportModal = document.getElementById('reportModal');
            if (event.target === reportModal) closeReportModal();
        }
        
        // Report Generation Functions
        let currentReportType = 'summary';
        
        function openReportModal() {
            document.getElementById('reportModal').classList.add('active');
            const today = new Date();
            const thirtyDaysAgo = new Date();
            thirtyDaysAgo.setDate(today.getDate() - 30);
            
            document.getElementById('report_date_to').value = today.toISOString().split('T')[0];
            document.getElementById('report_date_from').value = thirtyDaysAgo.toISOString().split('T')[0];
        }
        
        function closeReportModal() {
            document.getElementById('reportModal').classList.remove('active');
        }
        
        function selectReportType(type) {
            currentReportType = type;
            document.querySelectorAll('.report-type-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`.report-type-btn[data-type="${type}"]`).classList.add('active');
        }
        
        function generateReport() {
            const dateFrom = document.getElementById('report_date_from').value;
            const dateTo = document.getElementById('report_date_to').value;
            const ratingFilter = document.getElementById('report_rating_filter').value;
            const statusFilter = document.getElementById('report_status_filter').value;
            
            if (!dateFrom || !dateTo) {
                showToast('Please select date range', true);
                return;
            }
            
            const generateBtn = document.querySelector('.btn-generate');
            const originalText = generateBtn.innerHTML;
            generateBtn.innerHTML = '<span class="loading-spinner"></span> Generating...';
            generateBtn.disabled = true;
            
            fetch('generate_report.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `type=${currentReportType}&date_from=${dateFrom}&date_to=${dateTo}&rating=${ratingFilter}&status=${statusFilter}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    downloadReport(data.content, data.filename, data.type);
                    showToast('Report generated successfully!');
                    closeReportModal();
                } else {
                    showToast(data.message || 'Failed to generate report', true);
                }
            })
            .catch(error => {
                console.error('Report error:', error);
                showToast('Error generating report. Check console for details.', true);
            })
            .finally(() => {
                generateBtn.innerHTML = originalText;
                generateBtn.disabled = false;
            });
        }
        
        function downloadReport(content, filename, type) {
            if (type === 'html') {
                const blob = new Blob([content], { type: 'text/html' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = filename;
                link.click();
                URL.revokeObjectURL(link.href);
            } else if (type === 'csv') {
                const blob = new Blob([content], { type: 'text/csv' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = filename;
                link.click();
                URL.revokeObjectURL(link.href);
            }
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Press 'R' to open report modal
            if (e.key === 'r' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                openReportModal();
            }
            // Press 'F' to focus search
            if (e.key === 'f' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                document.getElementById('searchInput')?.focus();
            }
        });
    </script>
</body>
</html>