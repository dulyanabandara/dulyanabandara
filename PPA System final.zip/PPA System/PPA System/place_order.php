<?php
// place_order.php - Insert new order with status history and photo upload
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'error' => 'No data received']);
    exit();
}

// Get customer info
$user_id = isset($data['user_id']) ? intval($data['user_id']) : null;
$customer_name = mysqli_real_escape_string($conn, $data['customer_name'] ?? '');
$phone = mysqli_real_escape_string($conn, $data['phone'] ?? '');
$email = mysqli_real_escape_string($conn, $data['email'] ?? '');
$address = mysqli_real_escape_string($conn, $data['address'] ?? '');
$service_speed = mysqli_real_escape_string($conn, $data['service_speed'] ?? 'normal');
$delivery_option = mysqli_real_escape_string($conn, $data['delivery_option'] ?? 'pickup_only');
$order_type = mysqli_real_escape_string($conn, $data['order_type'] ?? 'pickup');
$total_items = intval($data['total_items'] ?? 0);
$delivery_distance = floatval($data['delivery_distance'] ?? 0);
$notes = mysqli_real_escape_string($conn, $data['notes'] ?? '');
$services_data = mysqli_real_escape_string($conn, json_encode($data['services_data'] ?? []));

// Get clothes photos if any (for visit orders)
$clothes_photos = isset($data['clothes_photos']) ? $data['clothes_photos'] : [];

// Validation
if (empty($customer_name) || empty($phone)) {
    echo json_encode(['success' => false, 'error' => 'Customer name and phone required']);
    exit();
}

// Function to calculate delivery charge
function calculateDeliveryCharge($distance, $deliveryOption) {
    $MIN_FARE = 150;
    $RATE_PER_KM = 85;
    
    if (!$distance || $distance <= 0) return 0;
    
    $charge = 0;
    if ($distance <= 1) {
        $charge = $MIN_FARE;
    } else {
        $charge = $MIN_FARE + (($distance - 1) * $RATE_PER_KM);
    }
    
    if ($deliveryOption === 'both') {
        $charge = $charge * 2;
    }
    
    return round($charge);
}

// Function to generate order ID
function generateOrderId($conn) {
    $result = mysqli_query($conn, "SELECT MAX(CAST(SUBSTRING(order_id, 3) AS UNSIGNED)) as last_num FROM orders");
    $row = mysqli_fetch_assoc($result);
    $lastNum = $row['last_num'] ? $row['last_num'] : 0;
    return 'PL' . str_pad($lastNum + 1, 6, '0', STR_PAD_LEFT);
}

// Function to create order_photos table if not exists
function createOrderPhotosTable($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS order_photos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id VARCHAR(20) NOT NULL,
        photo_data LONGTEXT,
        stain_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_order_id (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    return mysqli_query($conn, $sql);
}

try {
    // Calculate delivery charge
    $delivery_charge = 0;
    if ($delivery_option !== 'visit') {
        $delivery_charge = calculateDeliveryCharge($delivery_distance, $delivery_option);
    }
    
    // Generate order ID
    $order_id = generateOrderId($conn);
    
    // Set pickup date if provided
    $pickup_date = null;
    if (isset($data['pickupDate']) && !empty($data['pickupDate'])) {
        $pickup_date = mysqli_real_escape_string($conn, $data['pickupDate']);
    }
    
    // Set visit date if provided
    $visit_date = null;
    if ($order_type === 'visit' && isset($data['visit_date']) && !empty($data['visit_date'])) {
        $visit_date = mysqli_real_escape_string($conn, $data['visit_date']);
    } elseif (isset($data['visit_date']) && !empty($data['visit_date'])) {
        $visit_date = mysqli_real_escape_string($conn, $data['visit_date']);
    }
    
    // =============================================
    // 1. INSERT INTO orders table (main orders table)
    // =============================================
    $sql = "INSERT INTO orders (
        order_id, user_id, customer_name, phone, email, address, 
        service_speed, delivery_option, order_type, total_items, 
        delivery_distance, delivery_charge, notes, services_data,
        pickup_date, visit_date, status, created_at
    ) VALUES (
        '$order_id', " . ($user_id ? "'$user_id'" : "NULL") . ", '$customer_name', '$phone', " . ($email ? "'$email'" : "NULL") . ", " . ($address ? "'$address'" : "NULL") . ",
        '$service_speed', '$delivery_option', '$order_type', '$total_items',
        '$delivery_distance', '$delivery_charge', " . ($notes ? "'$notes'" : "NULL") . ", '$services_data',
        " . ($pickup_date ? "'$pickup_date'" : "NULL") . ", " . ($visit_date ? "'$visit_date'" : "NULL") . ", 'Pending Review', NOW()
    )";
    
    if (!mysqli_query($conn, $sql)) {
        throw new Exception("Failed to insert order: " . mysqli_error($conn));
    }
    
    // =============================================
    // 2. INSERT INTO order_items table
    // =============================================
    if (!empty($data['services_data'])) {
        $item_sql = "INSERT INTO order_items (order_id, service_type, item_name, quantity) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $item_sql);
        
        if ($stmt) {
            foreach ($data['services_data'] as $service) {
                $service_name = $service['service'] ?? '';
                if (!empty($service['items'])) {
                    foreach ($service['items'] as $item) {
                        $item_name = $item['name'] ?? '';
                        $quantity = intval($item['quantity'] ?? 1);
                        if (!empty($item_name)) {
                            mysqli_stmt_bind_param($stmt, 'sssi', $order_id, $service_name, $item_name, $quantity);
                            mysqli_stmt_execute($stmt);
                        }
                    }
                }
            }
            mysqli_stmt_close($stmt);
        }
    }
    
    // =============================================
    // 3. INSERT INTO visit-specific tables (for visit orders only)
    // =============================================
    if ($order_type === 'visit') {
        
        // STEP A: Insert into visit_laundry_orders FIRST (parent table)
        $visit_sql = "INSERT INTO visit_laundry_orders (
            order_id, user_id, customer_name, phone, email, 
            visit_date, service_speed, total_items, notes, services_data, status
        ) VALUES (
            '$order_id', 
            " . ($user_id ? "'$user_id'" : "NULL") . ", 
            '$customer_name', 
            '$phone', 
            " . ($email ? "'$email'" : "NULL") . ",
            " . ($visit_date ? "'$visit_date'" : "NULL") . ", 
            '$service_speed', 
            '$total_items', 
            " . ($notes ? "'$notes'" : "NULL") . ", 
            '$services_data', 
            'Pending'
        )";
        
        if (!mysqli_query($conn, $visit_sql)) {
            throw new Exception("Failed to insert into visit_laundry_orders: " . mysqli_error($conn));
        }
        
        // STEP B: Insert into visit_laundry_items table
        if (!empty($data['services_data'])) {
            $visit_item_sql = "INSERT INTO visit_laundry_items (order_id, service_type, item_name, quantity) VALUES (?, ?, ?, ?)";
            $visit_stmt = mysqli_prepare($conn, $visit_item_sql);
            
            if ($visit_stmt) {
                foreach ($data['services_data'] as $service) {
                    $service_name = $service['service'] ?? '';
                    if (!empty($service['items'])) {
                        foreach ($service['items'] as $item) {
                            $item_name = $item['name'] ?? '';
                            $quantity = intval($item['quantity'] ?? 1);
                            if (!empty($item_name)) {
                                mysqli_stmt_bind_param($visit_stmt, 'sssi', $order_id, $service_name, $item_name, $quantity);
                                mysqli_stmt_execute($visit_stmt);
                            }
                        }
                    }
                }
                mysqli_stmt_close($visit_stmt);
            }
        }
        
        // STEP C: Insert into visit_laundry_logs LAST (child table with foreign key)
        $log_sql = "INSERT INTO visit_laundry_logs (order_id, action, old_value, new_value, changed_by, created_at) 
                    VALUES ('$order_id', 'Created', NULL, '{\"status\":\"Pending\"}', 'customer', NOW())";
        
        if (!mysqli_query($conn, $log_sql)) {
            error_log("Failed to insert visit laundry log: " . mysqli_error($conn));
        }
        
    } else {
        // For pickup/delivery orders - use delivery_logs table
        $log_sql = "INSERT INTO delivery_logs (order_id, old_status, new_status, updated_by, notes, created_at) 
                    VALUES ('$order_id', NULL, 'Pending Review', 'system', 'Order created', NOW())";
        
        if (!mysqli_query($conn, $log_sql)) {
            error_log("Failed to insert delivery log: " . mysqli_error($conn));
        }
    }
    
    // =============================================
    // 4. INSERT INTO order_photos table (for visit orders with photos)
    // =============================================
    if (!empty($clothes_photos) && is_array($clothes_photos) && count($clothes_photos) > 0) {
        // Create the table if it doesn't exist
        createOrderPhotosTable($conn);
        
        $photo_sql = "INSERT INTO order_photos (order_id, photo_data, stain_note) VALUES (?, ?, ?)";
        $photo_stmt = mysqli_prepare($conn, $photo_sql);
        
        if ($photo_stmt) {
            $photo_count = 0;
            foreach ($clothes_photos as $photo) {
                // Only store if photo data exists and is not too large
                if (isset($photo['data']) && !empty($photo['data']) && strlen($photo['data']) < 5000000) {
                    $photo_data = mysqli_real_escape_string($conn, $photo['data']);
                    $stain_note = isset($photo['stainNote']) ? mysqli_real_escape_string($conn, $photo['stainNote']) : '';
                    
                    mysqli_stmt_bind_param($photo_stmt, 'sss', $order_id, $photo_data, $stain_note);
                    if (mysqli_stmt_execute($photo_stmt)) {
                        $photo_count++;
                    } else {
                        error_log("Failed to insert photo: " . mysqli_error($conn));
                    }
                }
            }
            mysqli_stmt_close($photo_stmt);
            
            if ($photo_count > 0) {
                error_log("Uploaded $photo_count photos for order $order_id");
            }
        }
    }
    
    // =============================================
    // Success response
    // =============================================
    $photo_message = '';
    if (!empty($clothes_photos)) {
        $photo_message = ', ' . count($clothes_photos) . ' photos uploaded';
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Order placed successfully' . $photo_message,
        'order_id' => $order_id,
        'delivery_charge' => $delivery_charge,
        'total_items' => $total_items,
        'photos_uploaded' => count($clothes_photos),
        'order_type' => $order_type
    ]);
    
} catch(Exception $e) {
    error_log("Place order error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>