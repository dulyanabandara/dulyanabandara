<?php
session_start();
header('Content-Type: application/json');
require_once 'config_review.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $response = ['success' => false, 'message' => 'Unknown error'];
    
    if ($action === 'approve') {
        $id = intval($_POST['id']);
        $query = "UPDATE feedback SET status='approved' WHERE id=$id";
        if (mysqli_query($conn_review, $query)) {
            $response = ['success' => true, 'message' => 'Review approved successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
        }
    }
    elseif ($action === 'reject') {
        $id = intval($_POST['id']);
        $query = "UPDATE feedback SET status='rejected' WHERE id=$id";
        if (mysqli_query($conn_review, $query)) {
            $response = ['success' => true, 'message' => 'Review rejected'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
        }
    }
    elseif ($action === 'delete') {
        $id = intval($_POST['id']);
        $query = "DELETE FROM feedback WHERE id=$id";
        if (mysqli_query($conn_review, $query)) {
            $response = ['success' => true, 'message' => 'Review deleted successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
        }
    }
    elseif ($action === 'reply') {
        $id = intval($_POST['id']);
        $reply = mysqli_real_escape_string($conn_review, $_POST['reply']);
        $query = "UPDATE feedback SET admin_reply='$reply' WHERE id=$id";
        if (mysqli_query($conn_review, $query)) {
            $response = ['success' => true, 'message' => 'Reply sent successfully'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
        }
    }
    elseif ($action === 'bulk_approve') {
        $ids = $_POST['ids'];
        $id_list = implode(',', array_map('intval', $ids));
        $query = "UPDATE feedback SET status='approved' WHERE id IN ($id_list)";
        if (mysqli_query($conn_review, $query)) {
            $response = ['success' => true, 'message' => count($ids) . ' reviews approved'];
        } else {
            $response = ['success' => false, 'message' => 'Database error: ' . mysqli_error($conn_review)];
        }
    }
    elseif ($action === 'get_review') {
        $id = intval($_POST['id']);
        $query = "SELECT * FROM feedback WHERE id=$id";
        $result = mysqli_query($conn_review, $query);
        if ($row = mysqli_fetch_assoc($result)) {
            $response = ['success' => true, 'review' => $row];
        } else {
            $response = ['success' => false, 'message' => 'Review not found'];
        }
    }
    
    echo json_encode($response);
    exit;
}
?>