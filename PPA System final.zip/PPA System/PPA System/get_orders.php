<?php
// get_orders.php - Fetch orders with proper error handling
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once 'db.php';

$order_id = isset($_GET['order_id']) ? mysqli_real_escape_string($conn, $_GET['order_id']) : null;

try {
    if ($order_id) {
        // Get single order by ID
        $sql = "SELECT * FROM orders WHERE order_id = '$order_id'";
        $result = mysqli_query($conn, $sql);
        
        if (!$result) {
            echo json_encode(['success' => false, 'error' => 'Database query failed: ' . mysqli_error($conn)]);
            exit();
        }
        
        $order = mysqli_fetch_assoc($result);
        
        if ($order) {
            // Get order items
            $items_sql = "SELECT * FROM order_items WHERE order_id = '$order_id'";
            $items_result = mysqli_query($conn, $items_sql);
            $items = [];
            if ($items_result) {
                while ($item = mysqli_fetch_assoc($items_result)) {
                    $items[] = $item;
                }
            }
            $order['items'] = $items;
            
            echo json_encode(['success' => true, 'order' => $order]);
        } else {
            echo json_encode(['success' => false, 'error' => "Order $order_id not found in database"]);
        }
    } else {
        // Get all orders
        $sql = "SELECT * FROM orders ORDER BY created_at DESC";
        $result = mysqli_query($conn, $sql);
        
        if (!$result) {
            echo json_encode(['success' => false, 'error' => 'Database query failed: ' . mysqli_error($conn)]);
            exit();
        }
        
        $orders = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $orders[] = $row;
        }
        echo json_encode(['success' => true, 'orders' => $orders]);
    }
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>