<?php
// get_order_photos.php - Get photos for a specific order (Admin/Staff only)
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

// Check if user is logged in (optional - remove for testing)
// if (!isset($_SESSION['user_id'])) {
//     echo json_encode(['success' => false, 'error' => 'Unauthorized']);
//     exit();
// }

$order_id = isset($_GET['order_id']) ? mysqli_real_escape_string($conn, $_GET['order_id']) : '';

if (empty($order_id)) {
    echo json_encode(['success' => false, 'error' => 'Order ID required']);
    exit();
}

try {
    $sql = "SELECT id, photo_data, stain_note, created_at FROM order_photos WHERE order_id = '$order_id' ORDER BY created_at ASC";
    $result = mysqli_query($conn, $sql);
    
    $photos = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $photos[] = [
            'id' => $row['id'],
            'photo_data' => $row['photo_data'],
            'stain_note' => $row['stain_note'],
            'created_at' => $row['created_at']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'order_id' => $order_id,
        'photos' => $photos,
        'total_photos' => count($photos)
    ]);
    
} catch(Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>