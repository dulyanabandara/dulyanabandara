<?php
session_start();
require_once 'config_customers.php';

header('Content-Type: application/json');

// Check if admin is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authorized']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['recipients']) || !isset($data['subject']) || !isset($data['message'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$recipients = $data['recipients'];
$subject = $data['subject'];
$message = $data['message'];

if (empty($recipients)) {
    echo json_encode(['success' => false, 'message' => 'No recipients selected']);
    exit;
}

// Email headers
$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
$headers .= "From: Perfect Laundry <noreply@perfectlaundry.lk>\r\n";
$headers .= "Reply-To: support@perfectlaundry.lk\r\n";

$successCount = 0;
$failCount = 0;

foreach ($recipients as $recipient) {
    $to = $recipient['email'];
    $name = $recipient['name'];
    
    // Personalize message
    $personalizedMessage = str_replace('Dear Customer', "Dear $name", $message);
    $htmlMessage = nl2br(htmlspecialchars($personalizedMessage));
    
    $fullMessage = "
    <html>
    <head>
        <title>$subject</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #2C7AA0, #1E5A7A); color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 10px 10px; }
            .footer { text-align: center; padding: 15px; font-size: 12px; color: #888; }
            .btn { display: inline-block; background: #6FCF97; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Perfect Laundry</h2>
                <p>Freshness Delivered</p>
            </div>
            <div class='content'>
                $htmlMessage
                <br><br>
                <hr>
                <p style='font-size: 12px; color: #888;'>This is an automated message from Perfect Laundry. Please do not reply to this email.</p>
            </div>
            <div class='footer'>
                &copy; 2026 Perfect Laundry. All rights reserved.
            </div>
        </div>
    </body>
    </html>
    ";
    
    if (mail($to, $subject, $fullMessage, $headers)) {
        $successCount++;
    } else {
        $failCount++;
    }
    
    // Small delay to prevent overwhelming the mail server
    usleep(100000);
}

echo json_encode([
    'success' => true,
    'message' => "Emails sent: $successCount successful, $failCount failed"
]);
?>