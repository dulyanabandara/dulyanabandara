<?php
// generate_delivery_report.php - Generate delivery reports (Admin only)
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'db.php';

// Temporarily disable admin check for testing - REMOVE THIS AFTER TESTING
// if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
//     http_response_code(403);
//     echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
//     exit();
// }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed. Use POST.']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$report_type = $data['report_type'] ?? 'delivery_summary';
$start_date = $data['start_date'] ?? '';
$end_date = $data['end_date'] ?? '';

// Debug log
error_log("Report request - Type: $report_type, Start: $start_date, End: $end_date");

try {
    $response = ['success' => true, 'data' => [], 'summary' => []];
    
    switch ($report_type) {
        case 'delivery_summary':
            // Daily delivery summary - FIXED to count all delivery orders correctly
            $sql = "SELECT 
                        DATE(created_at) as date,
                        COUNT(*) as total_deliveries,
                        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as completed,
                        SUM(CASE WHEN status IN ('Ready for Delivery', 'Out for Delivery', 'Price Confirmed') THEN 1 ELSE 0 END) as in_progress,
                        SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled,
                        COALESCE(SUM(delivery_charge), 0) as total_fees,
                        COALESCE(AVG(delivery_distance), 0) as avg_distance
                    FROM orders
                    WHERE delivery_option IN ('delivery_only', 'both') ";
            
            if (!empty($start_date) && !empty($end_date)) {
                $sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $sql .= "GROUP BY DATE(created_at) ORDER BY date DESC";
            
            $result = mysqli_query($conn, $sql);
            if (!$result) {
                throw new Exception(mysqli_error($conn));
            }
            
            $data_rows = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data_rows[] = $row;
            }
            $response['data'] = $data_rows;
            
            // Summary totals - FIXED to show correct counts
            $summary_sql = "SELECT 
                                COUNT(*) as total_deliveries,
                                SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as completed,
                                SUM(CASE WHEN status IN ('Ready for Delivery', 'Out for Delivery', 'Price Confirmed') THEN 1 ELSE 0 END) as in_progress,
                                COALESCE(SUM(delivery_charge), 0) as total_revenue,
                                COALESCE(AVG(delivery_distance), 0) as avg_distance
                            FROM orders
                            WHERE delivery_option IN ('delivery_only', 'both') ";
            if (!empty($start_date) && !empty($end_date)) {
                $summary_sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $summary_result = mysqli_query($conn, $summary_sql);
            if ($summary_result && mysqli_num_rows($summary_result) > 0) {
                $response['summary'] = mysqli_fetch_assoc($summary_result);
            } else {
                $response['summary'] = [
                    'total_deliveries' => 0,
                    'completed' => 0,
                    'in_progress' => 0,
                    'total_revenue' => 0,
                    'avg_distance' => 0
                ];
            }
            break;
            
        case 'delivery_performance':
            // Performance by delivery option
            $sql = "SELECT 
                        delivery_option,
                        COUNT(*) as total_orders,
                        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as completed,
                        ROUND(SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 2) as completion_rate,
                        COALESCE(AVG(delivery_charge), 0) as avg_charge,
                        COALESCE(AVG(delivery_distance), 0) as avg_distance
                    FROM orders
                    WHERE delivery_option IN ('delivery_only', 'both') ";
            if (!empty($start_date) && !empty($end_date)) {
                $sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $sql .= "GROUP BY delivery_option";
            
            $result = mysqli_query($conn, $sql);
            if (!$result) {
                throw new Exception(mysqli_error($conn));
            }
            
            $data_rows = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data_rows[] = $row;
            }
            $response['data'] = $data_rows;
            break;
            
        case 'revenue_report':
            // Revenue from delivery orders
            $sql = "SELECT 
                        order_id,
                        customer_name,
                        DATE(created_at) as created_at,
                        delivery_option,
                        delivery_charge,
                        package_price,
                        total_price,
                        status
                    FROM orders
                    WHERE delivery_option IN ('delivery_only', 'both') ";
            if (!empty($start_date) && !empty($end_date)) {
                $sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $sql .= "ORDER BY created_at DESC";
            
            $result = mysqli_query($conn, $sql);
            if (!$result) {
                throw new Exception(mysqli_error($conn));
            }
            
            $data_rows = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data_rows[] = $row;
            }
            $response['data'] = $data_rows;
            
            // Revenue summary
            $summary_sql = "SELECT 
                                COUNT(*) as total_orders,
                                COALESCE(SUM(delivery_charge), 0) as total_delivery_revenue,
                                COALESCE(SUM(package_price), 0) as total_package_revenue,
                                COALESCE(SUM(total_price), 0) as total_revenue,
                                COALESCE(AVG(total_price), 0) as avg_order_value
                            FROM orders
                            WHERE delivery_option IN ('delivery_only', 'both')
                            AND total_price IS NOT NULL ";
            if (!empty($start_date) && !empty($end_date)) {
                $summary_sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $summary_result = mysqli_query($conn, $summary_sql);
            if ($summary_result && mysqli_num_rows($summary_result) > 0) {
                $response['summary'] = mysqli_fetch_assoc($summary_result);
            } else {
                $response['summary'] = [
                    'total_orders' => 0,
                    'total_delivery_revenue' => 0,
                    'total_package_revenue' => 0,
                    'total_revenue' => 0,
                    'avg_order_value' => 0
                ];
            }
            break;
            
        case 'delivery_timeline':
            // Daily timeline of deliveries
            $sql = "SELECT 
                        DATE(created_at) as date,
                        COUNT(*) as total_orders,
                        SUM(CASE WHEN status IN ('Ready for Delivery', 'Out for Delivery', 'Price Confirmed') THEN 1 ELSE 0 END) as pending,
                        SUM(CASE WHEN status = 'Delivered' THEN 1 ELSE 0 END) as delivered,
                        SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled
                    FROM orders
                    WHERE delivery_option IN ('delivery_only', 'both') ";
            if (!empty($start_date) && !empty($end_date)) {
                $sql .= "AND DATE(created_at) BETWEEN '$start_date' AND '$end_date' ";
            }
            $sql .= "GROUP BY DATE(created_at) ORDER BY date DESC";
            
            $result = mysqli_query($conn, $sql);
            if (!$result) {
                throw new Exception(mysqli_error($conn));
            }
            
            $data_rows = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $data_rows[] = $row;
            }
            $response['data'] = $data_rows;
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid report type: ' . $report_type]);
            exit();
    }
    
    echo json_encode($response);
    
} catch(Exception $e) {
    error_log("Report generation error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

mysqli_close($conn);
?>